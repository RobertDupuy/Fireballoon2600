# Fireballoon 2600 — v0.8

Created by **Mark2006**. Three buildings, four street layouts, twenty calls.

**32 KiB, standard Atari F4 banking, NTSC, 262 scanlines.** Native 6507, TIA
and RIOT RAM. No cartridge RAM or extra processor.

## Changes in this version

- Fires now have an unmistakably oversized final stage, extending above their
  windows. This stage is still extinguishable.
- When an unchecked fire destroys a building, **every real window in that
  building erupts for 90 frames (1.5 seconds)**, followed by a floor-by-floor
  collapse. Only that building disappears. The sequence is entirely visual,
  with native TIA sound; no fire warning message is displayed.
- Other causes of losing a life no longer make the buildings collapse.
- Jumping residents begin on **call 3**, with recurring arrivals throughout
  each call. Calls 3–6 have three residents, calls 7–12 have four, and calls
  13–20 have five. At most two are active at once.
- Residents wait **384 active frames (about 6.4 seconds)** before jumping.
  Faster waving and an audible warning mark the last 128 frames. A balloon
  can rescue them at the window throughout that delay. Falling masonry or
  another airborne resident may extend the wait. A catch gives any other
  urgent resident at least two more seconds before jumping.
- **Hold DOWN to catch:** the player crouches with a wide blue blanket and
  cannot move left or right, including diagonal joystick input. Release DOWN
  to move again. A resident reaching the ground costs one life and retries
  the same call.

The three buildings, four street layouts, twenty calls, warned masonry, wind,
striped character, white road markings, title and native TIA sound remain.
Rooftop reservoirs and flying embers remain removed.

## Play

Open `Fireballoon2600-v0.8-NTSC.bin` in Stella, or use a cartridge supporting
standard **F4**, without Superchip RAM. Use the left joystick.

| Input | Action |
| --- | --- |
| Left / right | Move |
| Hold DOWN | Stop and open the catching blanket; release DOWN to move |
| Tap FIRE | Pick up and throw one water balloon |
| Release FIRE | Rearm for the next throw |
| SELECT | Pause / resume |
| RESET | Start a new game |

One tap during recovery queues a throw. Holding FIRE does not repeat. The bucket
holds eight balloons and refills automatically in **60 frames**. Refilling
continues while catching. DOWN is for catching, not refilling. The bar shows water and refill progress. White digits show
score; blue pairs show call, seconds and lives. The arrow indicates wind.

Residents wave faster in their final warning period. Rescue them at the window
with a balloon, or move underneath them after they jump and **hold DOWN**. Keep
the center of the blanket underneath the falling resident. You cannot move or
start another throw while holding DOWN. An already-started pickup waits until
DOWN is released. New residents keep appearing until the call’s quota is met.

Clear the fires, residents and remaining outbreaks before time runs out.
Occupied lower windows intercept balloons aimed at higher ones. An unchecked oversized
fire, timeout, a masonry hit or a missed catch costs one of three
lives and retries the current call. Masonry gives a 45-frame audible warning
and falls in three pieces; move into the gaps.

| Action | Points |
| --- | --- |
| Weaken a fire | 20 |
| Extinguish a fire | 100, plus a 10–90-point streak bonus |
| Rescue a resident at a window | 250 |
| Catch a falling resident | 500 |
| Clear a call | 10 per remaining second |

A missed balloon breaks the extinguishing streak. `design.json` contains all
20 authored call configurations and unlocks.

## Build

Install Python 3 and DASM, then run:

```sh
python3 build.py
```

Set `DASM` to its executable path if needed. The output is
`build/Fireballoon2600-NTSC.bin`, with symbols and an assembly listing.

`art_v08.py` generates the sprites and levels. `street_design.py` defines the
four building profiles. `make_facade.py`, `make_street.py` and `make_position.py`
generate the timed native display code. `src/engine.asm` and `src/features.asm`
contain the game rules. All generated assembly is included.

## Renderer and memory

The game uses eight 4-KiB banks. Bank 0 holds the simulation; banks 1 and 4–6
hold the four facades; bank 2 contains the title; bank 3 contains the loader,
HUD and street; bank 7 contains endings and the shared positioning routines.

Each window is a 16-by-16 sprite formed by P0 and P1. Six timed writes produce
three independent windows on each scanline. The 64 window rows run at exactly
76 CPU cycles each; floors remain 28 scanlines apart. The restored roof and floor
bands provide time to draw a foreground resident continuously between windows.

HUD bytes are reused after their digits have been drawn. Foreground sprites stay
on screen while a cycle-balanced positioning routine moves the balloon or street
object. The resident transfers from P0 to P1 at street level, freeing P0 for the player
and the double-width catching pose. Fine motion finishes
before its registers are cleared. Unrelated windows retain their normal artwork.
All lettering uses sprites rather than playfield text.

Game state still occupies **118 bytes**, leaving ten bytes for the stack. All
eight banks retain matching reset vectors and switching gates.

## Verification

The reports in `validation/` identify the exact ROM SHA-256. They use native
Stella 7.0_pre/libretro, pinned to commit
`ba52c43b9eda950eb0c0eec69cda9b17dee8c39b`, with the supplied observation patch.

```sh
python3 -m pip install numpy pillow
python3 tests/build_stella.py
python3 tests/verify_core.py
python3 tests/verify_streets.py
python3 tests/verify_features.py
python3 tests/verify_escalation.py
python3 tests/expert_player.py
python3 tests/replay.py
```

`STELLA_CORE` may point to an existing patched core. Fixtures write RAM to isolate
individual mechanics. The foreground checks inspect all 44 resident pixels at
every one of 122 descent heights, in all three columns and all four layouts:
**1,464 rendered frames**. Roof, window, timing, balloon and street-object checks
cover the other changed paths. Escalation checks compare native flame size,
verify the 90-frame eruption, and check every building in all four layouts:
only the affected building disappears. All tested paths retain 262 scanlines.

The complete campaign and independent input replay use only joystick inputs,
with no state writes, rewinds or saves. They complete all twenty calls. The included validation summary records the
catch count and remaining lives. This establishes a winning route; it does not
establish the difficulty for a human player.

The accompanying movie uses native Stella video and TIA audio at normal speed.
It includes the resident warning, full descent, stationary blanket catch, giant
fire stage, building-wide eruption, collapse and late play. Recreate it
with `python3 tests/record_movie.py` after the campaign; FFmpeg is required.

Physical-console testing and PAL testing have not been performed. Human play
remains the measure of difficulty and fun.

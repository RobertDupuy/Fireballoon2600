from pathlib import Path
import subprocess,os,sys,shutil
ROOT=Path(__file__).resolve().parent
from art_v08 import generate
generate()
for name in ['make_position.py','make_facade.py','make_street.py','make_title.py']:subprocess.run([sys.executable,str(ROOT/name)],check=True)
(ROOT/'build').mkdir(exist_ok=True)
dasm=os.environ.get('DASM') or shutil.which('dasm') or str(ROOT.parent/'tools/dasm/bin/dasm')
r=subprocess.run([dasm,'src/main.asm','-f3','-obuild/Fireballoon2600-NTSC.bin','-lbuild/Fireballoon2600.lst','-sbuild/Fireballoon2600.sym'],cwd=ROOT)
sys.exit(r.returncode)

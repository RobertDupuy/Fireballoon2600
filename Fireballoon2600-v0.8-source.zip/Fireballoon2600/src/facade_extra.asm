    ORG $4000
    RORG $F000
FloorsKernel
    SUBROUTINE
    lda mode
    cmp #3
    bne .normal
    lda lossCause
    cmp #3
    bcs .normal
    lda transition
    cmp #151
    bcs .normal
    jmp CollapseFacadeKernel
.normal
    lda #>BrickMask
    sta ballPtr+1
    sta colorPtr+1
    sta spritePtr+1
    ldx artIndex
    lda ArtCap,x
    sta ballPtr
    ldx artIndex+1
    lda ArtCap,x
    sta colorPtr
    ldx artIndex+2
    lda ArtCap,x
    sta spritePtr
    lda #$2E
    sta COLUP0
    lda #0
    sta floor
    sta GRP1
    sta ENABL
    sta ENAM1
    ldy #11
    sta WSYNC
    REPEAT 8
    nop
    REPEND
    lda (ballPtr),y
    sta GRP0
    REPEAT 3
    nop
    REPEND
    lda (colorPtr),y
    sta GRP0
    REPEAT 3
    nop
    REPEND
    lda (spritePtr),y
    sta GRP0
    ldx #0
    jmp Gap0Finish
NextFloor
    inx
    stx floor
    lda hud,x
    sta ballPtr
    ldy #11
    lda (ballPtr),y
    sta GRP0
    lda hud+4,x
    sta colorPtr
    lda (colorPtr),y
    sta GRP0
    lda hud+8,x
    sta spritePtr
    lda (spritePtr),y
    sta GRP0
Gap0Finish
    lda SkyPF1,x
    sta PF1
    lda SkyPF2,x
    sta PF2
    sta WSYNC
    ; Gap 1: next window's pointers; foreground writes at 25/40/55.
    ldx floor
    lda FloorFirst0,x
    tax
    lda artIndex,x
    tax
    ldy #10
    lda (ballPtr),y
    sta GRP0
    lda ArtLeftLo,x
    sta p0
    lda (colorPtr),y
    sta GRP0
    lda ArtRightLo,x
    sta p1
    lda (spritePtr),y
    sta GRP0
    lda ArtPage,x
    sta p0+1
    sta p1+1
    lda #0
    sta ENABL
    sta ENAM1
    sta HMCLR
    ; Gap 2: next window's pointers; foreground writes at 25/40/55.
    ldx floor
    lda FloorFirst1,x
    tax
    lda artIndex,x
    tax
    ldy #9
    lda (ballPtr),y
    sta GRP0
    lda ArtLeftLo,x
    sta p2
    lda (colorPtr),y
    sta GRP0
    lda ArtRightLo,x
    sta p3
    lda (spritePtr),y
    sta GRP0
    lda ArtPage,x
    sta p2+1
    sta p3+1
    lda #$2E
    sta COLUP0
    sta WSYNC
    ; Gap 3: next window's pointers; foreground writes at 25/40/55.
    ldx floor
    lda FloorFirst2,x
    tax
    lda artIndex,x
    tax
    ldy #8
    lda (ballPtr),y
    sta GRP0
    lda ArtLeftLo,x
    sta p4
    lda (colorPtr),y
    sta GRP0
    lda ArtRightLo,x
    sta p5
    lda (spritePtr),y
    sta GRP0
    lda ArtPage,x
    sta p4+1
    sta p5+1
    sta WSYNC
    ; Gap 4: pointer offset, folded into the zero-padded half-page.
    ldy floor
    lda brickY
    sec
    sbc KJumpOffset,y
    tax
    lda KJumpClamp,x
    sta waterMask
    ldy #7
    lda (ballPtr),y
    sta GRP0
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    lda eventType
    beq .noJumpOverlay
    lda waterMask
    beq .noJumpOverlay
    ldx brickWarn
    sta p0,x
    lda #>BrickMask
    sta p0+1,x
.noJumpOverlay
    sta WSYNC
    ; Gap 5: masonry membership, separate from the resident overlay.
    ldx brickY
    lda KBrickBand,x
    eor floor
    ora eventType
    sta waterMask
    ldy #6
    lda (ballPtr),y
    sta GRP0
    nop
    nop
    nop
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    ldx waterMask
    beq .masonryMask
    lda #0
    sta waterMask
    beq .maskDone
.masonryMask
    ldy floor
    lda brickY
    sec
    sbc KMasonryOffset,y
    sta waterMask
.maskDone
    sta WSYNC
    ; Gap 6: select a cycle-balanced horizontal positioning scanline.
    ldy floor
    lda ballBandX,y
    pha
    and #15
    tax
    lda KGapPosLo,x
    sta tmp
    ldy #5
    lda (ballPtr),y
    sta GRP0
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    lda KGapPosHi,x
    sta tmp2
    pla
    and #$F0
    sta HMBL
    ldy floor
    lda SolidPF1,y
    sta PF1
    ; Gap 7: keep all three foreground bytes for the positioning row.
    ldy #1
    lda (ballPtr),y
    sta row
    lda (colorPtr),y
    sta anim
    ldy #4
    lda (ballPtr),y
    sta GRP0
    bit frame
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    ldy #1
    lda (spritePtr),y
    sta warn
    ldy floor
    lda SolidPF2,y
    sta PF2
    sta WSYNC
    ; Gap 8 begins at c0 without WSYNC; roof coping now crosses all buildings.
    ldy floor
    lda ballBandLo,y
    sta ballPtr
    lda #>BallMask
    sta ballPtr+1
    ldx hud,y
    lda BrickMask+3,x
    sta GRP0
    lda waterMask
    sta colorPtr
    ldx hud+4,y
    lda BrickMask+3,x
    sta GRP0
    ldx hud+8,y
    lda BrickMask+3,x
    sta GRP0
    lda #>BallMask
    sta colorPtr+1
    lda #$08
    sta COLUPF
    sta WSYNC
    ; Gap 9: fixed timing into the banked positioning routine.
    ldy floor
    lda BodyPF1,y
    sta PF1
    lda BodyPF2,y
    sta PF2
    ldx hud,y
    lda BrickMask+2,x
    sta GRP0
    nop
    nop
    ldx hud+4,y
    lda BrickMask+2,x
    sta GRP0
    ldx hud+8,y
    lda BrickMask+2,x
    sta GRP0
    ldx #4
    REPEAT 4
    nop
    REPEND
    jmp ToGapPosition
GapAfterPosition
    ; Gap 11: return at c14, apply fine positioning, then enter the facade.
    ldy floor
    bit frame
    nop
    ldx hud,y
    lda BrickMask,x
    sta GRP0
    ldx hud+4,y
    lda BrickMask,x
    sta GRP0
    ldx hud+8,y
    lda BrickMask,x
    sta GRP0
    lda #$06
    sta COLUP0
    sta COLUP1
    ldy #15
    lda (p5),y
    tax
    lda #$28
    sta COLUPF
    nop
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$28
    sta COLUPF
    lda #$04
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$28
    sta COLUPF
    lda #$36
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$26
    sta COLUPF
    lda #$38
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$28
    sta COLUPF
    lda #$38
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$28
    sta COLUPF
    lda #$2A
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$24
    sta COLUPF
    lda #$2C
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$28
    sta COLUPF
    lda #$2C
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$28
    sta COLUPF
    lda #$2E
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$26
    sta COLUPF
    lda #$2E
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$28
    sta COLUPF
    lda #$1A
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$28
    sta COLUPF
    lda #$1C
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$24
    sta COLUPF
    lda #$1C
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$28
    sta COLUPF
    lda #$1E
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$28
    sta COLUPF
    lda #$0E
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$26
    sta COLUPF
    lda #$1A
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    lda #0
    sta GRP1
    lda #>BrickMask
    sta ballPtr+1
    sta colorPtr+1
    ldx floor
    cpx #3
    beq .street
    jmp NextFloor
.street
    jmp ToStreet
CollapseFacadeKernel
    SUBROUTINE
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta ENAM1
    sta PF0
    sta floor
    lda #1
    sta CTRLPF
.floor
    ; Two preparation rows plus 10 solid and 16 window rows = 28 lines.
    sta WSYNC
    lda #0
    sta PF1
    sta PF2
    ldx floor
    lda SolidPF1,x
    sta p0
    sta p1
    lda SolidPF2,x
    sta p0+1
    sta p1+1
    ldy lossCause
    lda transition
    cmp CollapseTimeK,x
    bcs .leftReady
    lda p0
    and CollapseLeft1,y
    sta p0
    lda p0+1
    and CollapseLeft2,y
    sta p0+1
.leftReady
    sta WSYNC
    bcs .rightReady
    lda p1
    and CollapseRight1,y
    sta p1
    lda p1+1
    and CollapseRight2,y
    sta p1+1
.rightReady
    lda p0
    and #$0C
    sta p2
    lda p0+1
    and #$2C
    sta p2+1
    lda p1
    and #$0C
    sta p3
    lda p1+1
    and #$2C
    sta p3+1
    ldy #10
.solid
    sta WSYNC
    lda p0
    sta PF1
    lda p0+1
    sta PF2
    lda #$28
    sta COLUPF
    REPEAT 9
    nop
    REPEND
    lda p1
    sta PF1
    lda p1+1
    nop
    sta PF2
    dey
    bne .solid
    ldy #16
.windows
    sta WSYNC
    lda p2
    sta PF1
    lda p2+1
    sta PF2
    lda #$26
    sta COLUPF
    REPEAT 9
    nop
    REPEND
    lda p3
    sta PF1
    lda p3+1
    nop
    sta PF2
    dey
    bne .windows
    inc floor
    lda floor
    cmp #4
    bcs .finished
    jmp .floor
.finished
    jmp ToStreet
CollapseLeft1 byte $F0,$FF,$FF
CollapseLeft2 byte $F0,$1F,$FF
CollapseRight1 byte $FF,$FF,$F0
CollapseRight2 byte $FF,$1F,$F0
SkyPF1 byte $00,$0F,$0F,$0F
SkyPF2 byte $00,$0F,$0F,$EF
SolidPF1 byte $0F,$0F,$0F,$0F
SolidPF2 byte $0F,$0F,$EF,$EF
BodyPF1 byte $0C,$0C,$0C,$0C
BodyPF2 byte $0C,$0C,$2C,$2C

FloorFirst0 byte 0,3,6,9
FloorFirst1 byte 1,4,7,10
FloorFirst2 byte 2,5,8,11
KJumpOffset byte 249,21,49,77
KMasonryOffset byte 153,181,209,237
CollapseTimeK byte 120,90,60,30
KGapPosLo byte <GapPos0,<GapPos1,<GapPos2,<GapPos3,<GapPos4,<GapPos5,<GapPos6,<GapPos7,<GapPos8,<GapPos9,<GapPos10
KGapPosHi byte >GapPos0,>GapPos1,>GapPos2,>GapPos3,>GapPos4,>GapPos5,>GapPos6,>GapPos7,>GapPos8,>GapPos9,>GapPos10
KBrickBand
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 255,255,1,1,1,1,1,1,1,1,1,1,1,1,1,1
    byte 1,1,1,1,1,1,1,1,1,1,1,1,255,255,2,2
    byte 2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2
    byte 2,2,2,2,2,2,2,2,255,255,3,3,3,3,3,3
    byte 3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3
    byte 3,3,3,3,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
KJumpClamp
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63
    byte 64,65,66,67,68,69,70,71,72,73,74,75,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    include "src/flames.inc"
    echo "Facade code/art:",(*-$F000)
    ORG $4D00
    RORG $FD00
BallMask
    ds 64,1
    byte $03,$13,$33,$33,$33,$13,$03,$01
    ds 56,1
    byte $03,$13,$23,$23,$13,$03
    ds 26,1
    byte 2,2,2,2
    ds 92,1
BrickMask
    ds 16,0
    byte $FF,$FF,$FF,$FE,$FC,$FE,$7E,$5E,$7C,$78,$38,$10
    ds 4,0
    byte $FF,$FF,$FE,$FC,$FE,$7E,$7C,$7C,$3C,$1C,$18,$08
    ds 20,0
    byte $66,$24,$24,$3C,$3C,$7E,$DB,$99,$18,$3C,$3C,$18
    ds 180,0
    ORG $4FA0
    GAPGATES GapAfterPosition
    ORG $4FB0
    GATES
    ORG $4FFA
    RORG $FFFA
    word ResetGate,ResetGate,ResetGate

    ORG $5000
    RORG $F000
FloorsKernel
    SUBROUTINE
    lda mode
    cmp #3
    bne .normal
    lda lossCause
    cmp #3
    bcs .normal
    lda transition
    cmp #151
    bcs .normal
    jmp CollapseFacadeKernel
.normal
    lda #>BrickMask
    sta ballPtr+1
    sta colorPtr+1
    sta spritePtr+1
    ldx artIndex
    lda ArtCap,x
    sta ballPtr
    ldx artIndex+1
    lda ArtCap,x
    sta colorPtr
    ldx artIndex+2
    lda ArtCap,x
    sta spritePtr
    lda #$2E
    sta COLUP0
    lda #0
    sta floor
    sta GRP1
    sta ENABL
    sta ENAM1
    ldy #11
    sta WSYNC
    REPEAT 8
    nop
    REPEND
    lda (ballPtr),y
    sta GRP0
    REPEAT 3
    nop
    REPEND
    lda (colorPtr),y
    sta GRP0
    REPEAT 3
    nop
    REPEND
    lda (spritePtr),y
    sta GRP0
    ldx #0
    jmp Gap0Finish
NextFloor
    inx
    stx floor
    lda hud,x
    sta ballPtr
    ldy #11
    lda (ballPtr),y
    sta GRP0
    lda hud+4,x
    sta colorPtr
    lda (colorPtr),y
    sta GRP0
    lda hud+8,x
    sta spritePtr
    lda (spritePtr),y
    sta GRP0
Gap0Finish
    lda SkyPF1,x
    sta PF1
    lda SkyPF2,x
    sta PF2
    sta WSYNC
    ; Gap 1: next window's pointers; foreground writes at 25/40/55.
    ldx floor
    lda FloorFirst0,x
    tax
    lda artIndex,x
    tax
    ldy #10
    lda (ballPtr),y
    sta GRP0
    lda ArtLeftLo,x
    sta p0
    lda (colorPtr),y
    sta GRP0
    lda ArtRightLo,x
    sta p1
    lda (spritePtr),y
    sta GRP0
    lda ArtPage,x
    sta p0+1
    sta p1+1
    lda #0
    sta ENABL
    sta ENAM1
    sta HMCLR
    ; Gap 2: next window's pointers; foreground writes at 25/40/55.
    ldx floor
    lda FloorFirst1,x
    tax
    lda artIndex,x
    tax
    ldy #9
    lda (ballPtr),y
    sta GRP0
    lda ArtLeftLo,x
    sta p2
    lda (colorPtr),y
    sta GRP0
    lda ArtRightLo,x
    sta p3
    lda (spritePtr),y
    sta GRP0
    lda ArtPage,x
    sta p2+1
    sta p3+1
    lda #$2E
    sta COLUP0
    sta WSYNC
    ; Gap 3: next window's pointers; foreground writes at 25/40/55.
    ldx floor
    lda FloorFirst2,x
    tax
    lda artIndex,x
    tax
    ldy #8
    lda (ballPtr),y
    sta GRP0
    lda ArtLeftLo,x
    sta p4
    lda (colorPtr),y
    sta GRP0
    lda ArtRightLo,x
    sta p5
    lda (spritePtr),y
    sta GRP0
    lda ArtPage,x
    sta p4+1
    sta p5+1
    sta WSYNC
    ; Gap 4: pointer offset, folded into the zero-padded half-page.
    ldy floor
    lda brickY
    sec
    sbc KJumpOffset,y
    tax
    lda KJumpClamp,x
    sta waterMask
    ldy #7
    lda (ballPtr),y
    sta GRP0
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    lda eventType
    beq .noJumpOverlay
    lda waterMask
    beq .noJumpOverlay
    ldx brickWarn
    sta p0,x
    lda #>BrickMask
    sta p0+1,x
.noJumpOverlay
    sta WSYNC
    ; Gap 5: masonry membership, separate from the resident overlay.
    ldx brickY
    lda KBrickBand,x
    eor floor
    ora eventType
    sta waterMask
    ldy #6
    lda (ballPtr),y
    sta GRP0
    nop
    nop
    nop
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    ldx waterMask
    beq .masonryMask
    lda #0
    sta waterMask
    beq .maskDone
.masonryMask
    ldy floor
    lda brickY
    sec
    sbc KMasonryOffset,y
    sta waterMask
.maskDone
    sta WSYNC
    ; Gap 6: select a cycle-balanced horizontal positioning scanline.
    ldy floor
    lda ballBandX,y
    pha
    and #15
    tax
    lda KGapPosLo,x
    sta tmp
    ldy #5
    lda (ballPtr),y
    sta GRP0
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    lda KGapPosHi,x
    sta tmp2
    pla
    and #$F0
    sta HMBL
    ldy floor
    lda SolidPF1,y
    sta PF1
    ; Gap 7: keep all three foreground bytes for the positioning row.
    ldy #1
    lda (ballPtr),y
    sta row
    lda (colorPtr),y
    sta anim
    ldy #4
    lda (ballPtr),y
    sta GRP0
    bit frame
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    ldy #1
    lda (spritePtr),y
    sta warn
    ldy floor
    lda SolidPF2,y
    sta PF2
    sta WSYNC
    ; Gap 8 begins at c0 without WSYNC; roof coping now crosses all buildings.
    ldy floor
    lda ballBandLo,y
    sta ballPtr
    lda #>BallMask
    sta ballPtr+1
    ldx hud,y
    lda BrickMask+3,x
    sta GRP0
    lda waterMask
    sta colorPtr
    ldx hud+4,y
    lda BrickMask+3,x
    sta GRP0
    ldx hud+8,y
    lda BrickMask+3,x
    sta GRP0
    lda #>BallMask
    sta colorPtr+1
    lda #$08
    sta COLUPF
    sta WSYNC
    ; Gap 9: fixed timing into the banked positioning routine.
    ldy floor
    lda BodyPF1,y
    sta PF1
    lda BodyPF2,y
    sta PF2
    ldx hud,y
    lda BrickMask+2,x
    sta GRP0
    nop
    nop
    ldx hud+4,y
    lda BrickMask+2,x
    sta GRP0
    ldx hud+8,y
    lda BrickMask+2,x
    sta GRP0
    ldx #4
    REPEAT 4
    nop
    REPEND
    jmp ToGapPosition
GapAfterPosition
    ; Gap 11: return at c14, apply fine positioning, then enter the facade.
    ldy floor
    bit frame
    nop
    ldx hud,y
    lda BrickMask,x
    sta GRP0
    ldx hud+4,y
    lda BrickMask,x
    sta GRP0
    ldx hud+8,y
    lda BrickMask,x
    sta GRP0
    lda #$06
    sta COLUP0
    sta COLUP1
    ldy #15
    lda (p5),y
    tax
    lda #$98
    sta COLUPF
    nop
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$98
    sta COLUPF
    lda #$04
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$98
    sta COLUPF
    lda #$36
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$96
    sta COLUPF
    lda #$38
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$98
    sta COLUPF
    lda #$38
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$98
    sta COLUPF
    lda #$2A
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$94
    sta COLUPF
    lda #$2C
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$98
    sta COLUPF
    lda #$2C
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$98
    sta COLUPF
    lda #$2E
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$96
    sta COLUPF
    lda #$2E
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$98
    sta COLUPF
    lda #$1A
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$98
    sta COLUPF
    lda #$1C
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$94
    sta COLUPF
    lda #$1C
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$98
    sta COLUPF
    lda #$1E
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$98
    sta COLUPF
    lda #$0E
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$96
    sta COLUPF
    lda #$1A
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    lda #0
    sta GRP1
    lda #>BrickMask
    sta ballPtr+1
    sta colorPtr+1
    ldx floor
    cpx #3
    beq .street
    jmp NextFloor
.street
    jmp ToStreet
CollapseFacadeKernel
    SUBROUTINE
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta ENAM1
    sta PF0
    sta floor
    lda #1
    sta CTRLPF
.floor
    ; Two preparation rows plus 10 solid and 16 window rows = 28 lines.
    sta WSYNC
    lda #0
    sta PF1
    sta PF2
    ldx floor
    lda SolidPF1,x
    sta p0
    sta p1
    lda SolidPF2,x
    sta p0+1
    sta p1+1
    ldy lossCause
    lda transition
    cmp CollapseTimeK,x
    bcs .leftReady
    lda p0
    and CollapseLeft1,y
    sta p0
    lda p0+1
    and CollapseLeft2,y
    sta p0+1
.leftReady
    sta WSYNC
    bcs .rightReady
    lda p1
    and CollapseRight1,y
    sta p1
    lda p1+1
    and CollapseRight2,y
    sta p1+1
.rightReady
    lda p0
    and #$0C
    sta p2
    lda p0+1
    and #$2C
    sta p2+1
    lda p1
    and #$0C
    sta p3
    lda p1+1
    and #$2C
    sta p3+1
    ldy #10
.solid
    sta WSYNC
    lda p0
    sta PF1
    lda p0+1
    sta PF2
    lda #$98
    sta COLUPF
    REPEAT 9
    nop
    REPEND
    lda p1
    sta PF1
    lda p1+1
    nop
    sta PF2
    dey
    bne .solid
    ldy #16
.windows
    sta WSYNC
    lda p2
    sta PF1
    lda p2+1
    sta PF2
    lda #$96
    sta COLUPF
    REPEAT 9
    nop
    REPEND
    lda p3
    sta PF1
    lda p3+1
    nop
    sta PF2
    dey
    bne .windows
    inc floor
    lda floor
    cmp #4
    bcs .finished
    jmp .floor
.finished
    jmp ToStreet
CollapseLeft1 byte $F0,$FF,$FF
CollapseLeft2 byte $F0,$1F,$FF
CollapseRight1 byte $FF,$FF,$F0
CollapseRight2 byte $FF,$1F,$F0
SkyPF1 byte $00,$00,$00,$0F
SkyPF2 byte $00,$E0,$E0,$EF
SolidPF1 byte $00,$00,$0F,$0F
SolidPF2 byte $E0,$E0,$EF,$EF
BodyPF1 byte $00,$00,$0C,$0C
BodyPF2 byte $20,$20,$2C,$2C

FloorFirst0 byte 0,3,6,9
FloorFirst1 byte 1,4,7,10
FloorFirst2 byte 2,5,8,11
KJumpOffset byte 249,21,49,77
KMasonryOffset byte 153,181,209,237
CollapseTimeK byte 120,90,60,30
KGapPosLo byte <GapPos0,<GapPos1,<GapPos2,<GapPos3,<GapPos4,<GapPos5,<GapPos6,<GapPos7,<GapPos8,<GapPos9,<GapPos10
KGapPosHi byte >GapPos0,>GapPos1,>GapPos2,>GapPos3,>GapPos4,>GapPos5,>GapPos6,>GapPos7,>GapPos8,>GapPos9,>GapPos10
KBrickBand
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 255,255,1,1,1,1,1,1,1,1,1,1,1,1,1,1
    byte 1,1,1,1,1,1,1,1,1,1,1,1,255,255,2,2
    byte 2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2
    byte 2,2,2,2,2,2,2,2,255,255,3,3,3,3,3,3
    byte 3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3
    byte 3,3,3,3,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
KJumpClamp
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63
    byte 64,65,66,67,68,69,70,71,72,73,74,75,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    include "src/flames.inc"
    echo "Facade code/art:",(*-$F000)
    ORG $5D00
    RORG $FD00
BallMask
    ds 64,1
    byte $03,$13,$33,$33,$33,$13,$03,$01
    ds 56,1
    byte $03,$13,$23,$23,$13,$03
    ds 26,1
    byte 2,2,2,2
    ds 92,1
BrickMask
    ds 16,0
    byte $FF,$FF,$FF,$FE,$FC,$FE,$7E,$5E,$7C,$78,$38,$10
    ds 4,0
    byte $FF,$FF,$FE,$FC,$FE,$7E,$7C,$7C,$3C,$1C,$18,$08
    ds 20,0
    byte $66,$24,$24,$3C,$3C,$7E,$DB,$99,$18,$3C,$3C,$18
    ds 180,0
    ORG $5FA0
    GAPGATES GapAfterPosition
    ORG $5FB0
    GATES
    ORG $5FFA
    RORG $FFFA
    word ResetGate,ResetGate,ResetGate

    ORG $6000
    RORG $F000
FloorsKernel
    SUBROUTINE
    lda mode
    cmp #3
    bne .normal
    lda lossCause
    cmp #3
    bcs .normal
    lda transition
    cmp #151
    bcs .normal
    jmp CollapseFacadeKernel
.normal
    lda #>BrickMask
    sta ballPtr+1
    sta colorPtr+1
    sta spritePtr+1
    ldx artIndex
    lda ArtCap,x
    sta ballPtr
    ldx artIndex+1
    lda ArtCap,x
    sta colorPtr
    ldx artIndex+2
    lda ArtCap,x
    sta spritePtr
    lda #$2E
    sta COLUP0
    lda #0
    sta floor
    sta GRP1
    sta ENABL
    sta ENAM1
    ldy #11
    sta WSYNC
    REPEAT 8
    nop
    REPEND
    lda (ballPtr),y
    sta GRP0
    REPEAT 3
    nop
    REPEND
    lda (colorPtr),y
    sta GRP0
    REPEAT 3
    nop
    REPEND
    lda (spritePtr),y
    sta GRP0
    ldx #0
    jmp Gap0Finish
NextFloor
    inx
    stx floor
    lda hud,x
    sta ballPtr
    ldy #11
    lda (ballPtr),y
    sta GRP0
    lda hud+4,x
    sta colorPtr
    lda (colorPtr),y
    sta GRP0
    lda hud+8,x
    sta spritePtr
    lda (spritePtr),y
    sta GRP0
Gap0Finish
    lda SkyPF1,x
    sta PF1
    lda SkyPF2,x
    sta PF2
    sta WSYNC
    ; Gap 1: next window's pointers; foreground writes at 25/40/55.
    ldx floor
    lda FloorFirst0,x
    tax
    lda artIndex,x
    tax
    ldy #10
    lda (ballPtr),y
    sta GRP0
    lda ArtLeftLo,x
    sta p0
    lda (colorPtr),y
    sta GRP0
    lda ArtRightLo,x
    sta p1
    lda (spritePtr),y
    sta GRP0
    lda ArtPage,x
    sta p0+1
    sta p1+1
    lda #0
    sta ENABL
    sta ENAM1
    sta HMCLR
    ; Gap 2: next window's pointers; foreground writes at 25/40/55.
    ldx floor
    lda FloorFirst1,x
    tax
    lda artIndex,x
    tax
    ldy #9
    lda (ballPtr),y
    sta GRP0
    lda ArtLeftLo,x
    sta p2
    lda (colorPtr),y
    sta GRP0
    lda ArtRightLo,x
    sta p3
    lda (spritePtr),y
    sta GRP0
    lda ArtPage,x
    sta p2+1
    sta p3+1
    lda #$2E
    sta COLUP0
    sta WSYNC
    ; Gap 3: next window's pointers; foreground writes at 25/40/55.
    ldx floor
    lda FloorFirst2,x
    tax
    lda artIndex,x
    tax
    ldy #8
    lda (ballPtr),y
    sta GRP0
    lda ArtLeftLo,x
    sta p4
    lda (colorPtr),y
    sta GRP0
    lda ArtRightLo,x
    sta p5
    lda (spritePtr),y
    sta GRP0
    lda ArtPage,x
    sta p4+1
    sta p5+1
    sta WSYNC
    ; Gap 4: pointer offset, folded into the zero-padded half-page.
    ldy floor
    lda brickY
    sec
    sbc KJumpOffset,y
    tax
    lda KJumpClamp,x
    sta waterMask
    ldy #7
    lda (ballPtr),y
    sta GRP0
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    lda eventType
    beq .noJumpOverlay
    lda waterMask
    beq .noJumpOverlay
    ldx brickWarn
    sta p0,x
    lda #>BrickMask
    sta p0+1,x
.noJumpOverlay
    sta WSYNC
    ; Gap 5: masonry membership, separate from the resident overlay.
    ldx brickY
    lda KBrickBand,x
    eor floor
    ora eventType
    sta waterMask
    ldy #6
    lda (ballPtr),y
    sta GRP0
    nop
    nop
    nop
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    ldx waterMask
    beq .masonryMask
    lda #0
    sta waterMask
    beq .maskDone
.masonryMask
    ldy floor
    lda brickY
    sec
    sbc KMasonryOffset,y
    sta waterMask
.maskDone
    sta WSYNC
    ; Gap 6: select a cycle-balanced horizontal positioning scanline.
    ldy floor
    lda ballBandX,y
    pha
    and #15
    tax
    lda KGapPosLo,x
    sta tmp
    ldy #5
    lda (ballPtr),y
    sta GRP0
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    lda KGapPosHi,x
    sta tmp2
    pla
    and #$F0
    sta HMBL
    ldy floor
    lda SolidPF1,y
    sta PF1
    ; Gap 7: keep all three foreground bytes for the positioning row.
    ldy #1
    lda (ballPtr),y
    sta row
    lda (colorPtr),y
    sta anim
    ldy #4
    lda (ballPtr),y
    sta GRP0
    bit frame
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    ldy #1
    lda (spritePtr),y
    sta warn
    ldy floor
    lda SolidPF2,y
    sta PF2
    sta WSYNC
    ; Gap 8 begins at c0 without WSYNC; roof coping now crosses all buildings.
    ldy floor
    lda ballBandLo,y
    sta ballPtr
    lda #>BallMask
    sta ballPtr+1
    ldx hud,y
    lda BrickMask+3,x
    sta GRP0
    lda waterMask
    sta colorPtr
    ldx hud+4,y
    lda BrickMask+3,x
    sta GRP0
    ldx hud+8,y
    lda BrickMask+3,x
    sta GRP0
    lda #>BallMask
    sta colorPtr+1
    lda #$08
    sta COLUPF
    sta WSYNC
    ; Gap 9: fixed timing into the banked positioning routine.
    ldy floor
    lda BodyPF1,y
    sta PF1
    lda BodyPF2,y
    sta PF2
    ldx hud,y
    lda BrickMask+2,x
    sta GRP0
    nop
    nop
    ldx hud+4,y
    lda BrickMask+2,x
    sta GRP0
    ldx hud+8,y
    lda BrickMask+2,x
    sta GRP0
    ldx #4
    REPEAT 4
    nop
    REPEND
    jmp ToGapPosition
GapAfterPosition
    ; Gap 11: return at c14, apply fine positioning, then enter the facade.
    ldy floor
    bit frame
    nop
    ldx hud,y
    lda BrickMask,x
    sta GRP0
    ldx hud+4,y
    lda BrickMask,x
    sta GRP0
    ldx hud+8,y
    lda BrickMask,x
    sta GRP0
    lda #$06
    sta COLUP0
    sta COLUP1
    ldy #15
    lda (p5),y
    tax
    lda #$48
    sta COLUPF
    nop
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$48
    sta COLUPF
    lda #$04
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$48
    sta COLUPF
    lda #$36
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$46
    sta COLUPF
    lda #$38
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$48
    sta COLUPF
    lda #$38
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$48
    sta COLUPF
    lda #$2A
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$44
    sta COLUPF
    lda #$2C
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$48
    sta COLUPF
    lda #$2C
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$48
    sta COLUPF
    lda #$2E
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$46
    sta COLUPF
    lda #$2E
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$48
    sta COLUPF
    lda #$1A
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$48
    sta COLUPF
    lda #$1C
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$44
    sta COLUPF
    lda #$1C
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$48
    sta COLUPF
    lda #$1E
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$48
    sta COLUPF
    lda #$0E
    nop
    nop
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    lda (p5),y
    tax
    lda #$46
    sta COLUPF
    lda #$1A
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (colorPtr),y
    sta ENAM1
    bit frame
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    lda #0
    sta GRP1
    lda #>BrickMask
    sta ballPtr+1
    sta colorPtr+1
    ldx floor
    cpx #3
    beq .street
    jmp NextFloor
.street
    jmp ToStreet
CollapseFacadeKernel
    SUBROUTINE
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta ENAM1
    sta PF0
    sta floor
    lda #1
    sta CTRLPF
.floor
    ; Two preparation rows plus 10 solid and 16 window rows = 28 lines.
    sta WSYNC
    lda #0
    sta PF1
    sta PF2
    ldx floor
    lda SolidPF1,x
    sta p0
    sta p1
    lda SolidPF2,x
    sta p0+1
    sta p1+1
    ldy lossCause
    lda transition
    cmp CollapseTimeK,x
    bcs .leftReady
    lda p0
    and CollapseLeft1,y
    sta p0
    lda p0+1
    and CollapseLeft2,y
    sta p0+1
.leftReady
    sta WSYNC
    bcs .rightReady
    lda p1
    and CollapseRight1,y
    sta p1
    lda p1+1
    and CollapseRight2,y
    sta p1+1
.rightReady
    lda p0
    and #$0C
    sta p2
    lda p0+1
    and #$2C
    sta p2+1
    lda p1
    and #$0C
    sta p3
    lda p1+1
    and #$2C
    sta p3+1
    ldy #10
.solid
    sta WSYNC
    lda p0
    sta PF1
    lda p0+1
    sta PF2
    lda #$48
    sta COLUPF
    REPEAT 9
    nop
    REPEND
    lda p1
    sta PF1
    lda p1+1
    nop
    sta PF2
    dey
    bne .solid
    ldy #16
.windows
    sta WSYNC
    lda p2
    sta PF1
    lda p2+1
    sta PF2
    lda #$46
    sta COLUPF
    REPEAT 9
    nop
    REPEND
    lda p3
    sta PF1
    lda p3+1
    nop
    sta PF2
    dey
    bne .windows
    inc floor
    lda floor
    cmp #4
    bcs .finished
    jmp .floor
.finished
    jmp ToStreet
CollapseLeft1 byte $F0,$FF,$FF
CollapseLeft2 byte $F0,$1F,$FF
CollapseRight1 byte $FF,$FF,$F0
CollapseRight2 byte $FF,$1F,$F0
SkyPF1 byte $00,$0F,$0F,$0F
SkyPF2 byte $00,$0F,$EF,$EF
SolidPF1 byte $0F,$0F,$0F,$0F
SolidPF2 byte $0F,$EF,$EF,$EF
BodyPF1 byte $0C,$0C,$0C,$0C
BodyPF2 byte $0C,$2C,$2C,$2C

FloorFirst0 byte 0,3,6,9
FloorFirst1 byte 1,4,7,10
FloorFirst2 byte 2,5,8,11
KJumpOffset byte 249,21,49,77
KMasonryOffset byte 153,181,209,237
CollapseTimeK byte 120,90,60,30
KGapPosLo byte <GapPos0,<GapPos1,<GapPos2,<GapPos3,<GapPos4,<GapPos5,<GapPos6,<GapPos7,<GapPos8,<GapPos9,<GapPos10
KGapPosHi byte >GapPos0,>GapPos1,>GapPos2,>GapPos3,>GapPos4,>GapPos5,>GapPos6,>GapPos7,>GapPos8,>GapPos9,>GapPos10
KBrickBand
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 255,255,1,1,1,1,1,1,1,1,1,1,1,1,1,1
    byte 1,1,1,1,1,1,1,1,1,1,1,1,255,255,2,2
    byte 2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2
    byte 2,2,2,2,2,2,2,2,255,255,3,3,3,3,3,3
    byte 3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3
    byte 3,3,3,3,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
    byte 255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255
KJumpClamp
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63
    byte 64,65,66,67,68,69,70,71,72,73,74,75,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
    include "src/flames.inc"
    echo "Facade code/art:",(*-$F000)
    ORG $6D00
    RORG $FD00
BallMask
    ds 64,1
    byte $03,$13,$33,$33,$33,$13,$03,$01
    ds 56,1
    byte $03,$13,$23,$23,$13,$03
    ds 26,1
    byte 2,2,2,2
    ds 92,1
BrickMask
    ds 16,0
    byte $FF,$FF,$FF,$FE,$FC,$FE,$7E,$5E,$7C,$78,$38,$10
    ds 4,0
    byte $FF,$FF,$FE,$FC,$FE,$7E,$7C,$7C,$3C,$1C,$18,$08
    ds 20,0
    byte $66,$24,$24,$3C,$3C,$7E,$DB,$99,$18,$3C,$3C,$18
    ds 180,0
    ORG $6FA0
    GAPGATES GapAfterPosition
    ORG $6FB0
    GATES
    ORG $6FFA
    RORG $FFFA
    word ResetGate,ResetGate,ResetGate

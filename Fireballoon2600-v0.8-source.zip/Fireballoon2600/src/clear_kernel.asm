CallClearKernel
    SUBROUTINE
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta ENAM1
    sta PF0
    sta PF1
    sta PF2
    sta CTRLPF
    lda #$80
    sta COLUBK
    lda #3
    sta NUSIZ0
    sta NUSIZ1
    lda #1
    sta VDELP0
    sta VDELP1
    lda #55
    ldx #0
    jsr CallClearKernelPosition
    lda #63
    ldx #1
    jsr CallClearKernelPosition
    sta WSYNC
    sta HMOVE
    ldx #25
.space
    sta WSYNC
    dex
    bne .space
    lda #5
    sta row
.row4_0
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_0
    lda #4
    sta row
.row4_1
    sta WSYNC
    lda #$CA
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$1E
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$60
    ldx #$60
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_1
    lda #4
    sta row
.row4_2
    sta WSYNC
    lda #$CA
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$60
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$60
    ldx #$60
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_2
    lda #4
    sta row
.row4_3
    sta WSYNC
    lda #$CA
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$60
    sta GRP1                   ; c18
    lda #$7E
    sta GRP0                   ; c23
    lda #$60
    ldx #$60
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_3
    lda #4
    sta row
.row4_4
    sta WSYNC
    lda #$CA
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$60
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$60
    ldx #$60
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_4
    lda #4
    sta row
.row4_5
    sta WSYNC
    lda #$CA
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$1E
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$7E
    ldx #$7E
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_5
    lda #4
    sta row
.row4_6
    sta WSYNC
    lda #$CA
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_6
    lda #4
    sta row
.row4_7
    sta WSYNC
    lda #$CE
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$01
    sta GRP0                   ; c13
    lda #$E6
    sta GRP1                   ; c18
    lda #$07
    sta GRP0                   ; c23
    lda #$E1
    ldx #$87
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_7
    lda #4
    sta row
.row4_8
    sta WSYNC
    lda #$CE
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$06
    sta GRP0                   ; c13
    lda #$06
    sta GRP1                   ; c18
    lda #$06
    sta GRP0                   ; c23
    lda #$06
    ldx #$66
    ldy #$60             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_8
    lda #4
    sta row
.row4_9
    sta WSYNC
    lda #$CE
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$06
    sta GRP0                   ; c13
    lda #$06
    sta GRP1                   ; c18
    lda #$07
    sta GRP0                   ; c23
    lda #$87
    ldx #$E7
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_9
    lda #4
    sta row
.row4_10
    sta WSYNC
    lda #$CE
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$06
    sta GRP0                   ; c13
    lda #$06
    sta GRP1                   ; c18
    lda #$06
    sta GRP0                   ; c23
    lda #$06
    ldx #$66
    ldy #$60             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_10
    lda #4
    sta row
.row4_11
    sta WSYNC
    lda #$CE
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$01
    sta GRP0                   ; c13
    lda #$E7
    sta GRP1                   ; c18
    lda #$E7
    sta GRP0                   ; c23
    lda #$E6
    ldx #$66
    ldy #$60             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_11
    lda #12
    sta row
.row4_12
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_12
    lda #2
    sta row
.row4_13
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$0E
    sta GRP0                   ; c13
    lda #$EA
    sta GRP1                   ; c18
    lda #$E0
    sta GRP0                   ; c23
    lda #$C4
    ldx #$AA
    ldy #$60             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_13
    lda #2
    sta row
.row4_14
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$04
    sta GRP0                   ; c13
    lda #$4E
    sta GRP1                   ; c18
    lda #$80
    sta GRP0                   ; c23
    lda #$AA
    ldx #$EA
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_14
    lda #2
    sta row
.row4_15
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$04
    sta GRP0                   ; c13
    lda #$4E
    sta GRP1                   ; c18
    lda #$C0
    sta GRP0                   ; c23
    lda #$CA
    ldx #$EA
    ldy #$40             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_15
    lda #2
    sta row
.row4_16
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$04
    sta GRP0                   ; c13
    lda #$4A
    sta GRP1                   ; c18
    lda #$80
    sta GRP0                   ; c23
    lda #$AA
    ldx #$EA
    ldy #$20             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_16
    lda #2
    sta row
.row4_17
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$04
    sta GRP0                   ; c13
    lda #$EA
    sta GRP1                   ; c18
    lda #$E0
    sta GRP0                   ; c23
    lda #$C4
    ldx #$AE
    ldy #$C0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_17
    lda #9
    sta row
.row4_18
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row4_18
CallClearKernelDone
    SUBROUTINE
    sta WSYNC
    lda #0
    sta GRP0
    sta GRP1
    sta VDELP0
    sta VDELP1
.wait
    lda INTIM
    bne .wait
    jmp ToLogic
CallClearKernelPosition
    SUBROUTINE
    sec
    sbc #3
    sta WSYNC
    sec
.loop
    sbc #15
    bcs .loop
    eor #7
    asl
    asl
    asl
    asl
    sta HMP0,x
    sta RESP0,x
    rts

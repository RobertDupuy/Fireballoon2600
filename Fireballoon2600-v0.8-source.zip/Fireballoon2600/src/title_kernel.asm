; ================= BANK 2: colored, native 48-pixel title ===============
    ORG $2000
    RORG $F000
TitleKernel
    SUBROUTINE
    lda mode
    cmp #4
    bcs .ending
    jmp MainTitle
.ending
    lda $1FFB
    jmp EndingKernel
MainTitle
    SUBROUTINE
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta ENAM1
    sta PF0
    sta PF1
    sta PF2
    sta CTRLPF
    lda #$80
    sta COLUBK
    lda #3
    sta NUSIZ0
    sta NUSIZ1
    lda #1
    sta VDELP0
    sta VDELP1
    lda #55
    ldx #0
    jsr MainTitlePosition
    lda #63
    ldx #1
    jsr MainTitlePosition
    sta WSYNC
    sta HMOVE
    ldx #25
.space
    sta WSYNC
    dex
    bne .space
    lda #2
    sta row
.row0_0
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_0
    lda #4
    sta row
.row0_1
    sta WSYNC
    lda #$46
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$7F
    sta GRP0                   ; c13
    lda #$C7
    sta GRP1                   ; c18
    lda #$FC
    sta GRP0                   ; c23
    lda #$7E
    ldx #$07
    ldy #$FC             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_1
    lda #4
    sta row
.row0_2
    sta WSYNC
    lda #$48
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$70
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$E0
    sta GRP0                   ; c23
    lda #$71
    ldx #$C7
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_2
    lda #4
    sta row
.row0_3
    sta WSYNC
    lda #$2A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$7E
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$E0
    sta GRP0                   ; c23
    lda #$7E
    ldx #$07
    ldy #$E0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_3
    lda #4
    sta row
.row0_4
    sta WSYNC
    lda #$2C
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$70
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$E0
    sta GRP0                   ; c23
    lda #$71
    ldx #$C7
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_4
    lda #4
    sta row
.row0_5
    sta WSYNC
    lda #$1E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$70
    sta GRP0                   ; c13
    lda #$07
    sta GRP1                   ; c18
    lda #$FC
    sta GRP0                   ; c23
    lda #$71
    ldx #$C7
    ldy #$FC             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_5
    lda #5
    sta row
.row0_6
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_6
    lda #2
    sta row
.row0_7
    sta WSYNC
    lda #$96
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$1E
    sta GRP0                   ; c13
    lda #$39
    sta GRP1                   ; c18
    lda #$04
    sta GRP0                   ; c23
    lda #$0E
    ldx #$39
    ldy #$10             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_7
    lda #2
    sta row
.row0_8
    sta WSYNC
    lda #$98
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$11
    sta GRP0                   ; c13
    lda #$45
    sta GRP1                   ; c18
    lda #$04
    sta GRP0                   ; c23
    lda #$11
    ldx #$45
    ldy #$90             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_8
    lda #2
    sta row
.row0_9
    sta WSYNC
    lda #$9A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$11
    sta GRP0                   ; c13
    lda #$45
    sta GRP1                   ; c18
    lda #$04
    sta GRP0                   ; c23
    lda #$11
    ldx #$45
    ldy #$90             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_9
    lda #2
    sta row
.row0_10
    sta WSYNC
    lda #$9C
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$1E
    sta GRP0                   ; c13
    lda #$7D
    sta GRP1                   ; c18
    lda #$04
    sta GRP0                   ; c23
    lda #$11
    ldx #$45
    ldy #$50             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_10
    lda #2
    sta row
.row0_11
    sta WSYNC
    lda #$9E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$11
    sta GRP0                   ; c13
    lda #$45
    sta GRP1                   ; c18
    lda #$04
    sta GRP0                   ; c23
    lda #$11
    ldx #$45
    ldy #$30             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_11
    lda #2
    sta row
.row0_12
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$11
    sta GRP0                   ; c13
    lda #$45
    sta GRP1                   ; c18
    lda #$04
    sta GRP0                   ; c23
    lda #$11
    ldx #$45
    ldy #$30             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_12
    lda #2
    sta row
.row0_13
    sta WSYNC
    lda #$9C
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$1E
    sta GRP0                   ; c13
    lda #$45
    sta GRP1                   ; c18
    lda #$F7
    sta GRP0                   ; c23
    lda #$CE
    ldx #$39
    ldy #$10             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_13
    lda #2
    sta row
.row0_14
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_14
.row0_15
    sta WSYNC
    lda #$9C
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$18
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_16
    sta WSYNC
    lda #$9C
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$3C
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    lda #2
    sta row
.row0_17
    sta WSYNC
    lda #$9C
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$7E
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_17
.row0_18
    sta WSYNC
    lda #$9C
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$3C
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_19
    sta WSYNC
    lda #$9C
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$18
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_20
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$08
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$0F
    ldx #$FC
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_21
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$0F
    ldx #$FC
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_22
    sta WSYNC
    lda #$08
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$07
    ldx #$F8
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    lda #2
    sta row
.row0_23
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$07
    ldx #$F8
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_23
.row0_24
    sta WSYNC
    lda #$08
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$06
    ldx #$18
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_25
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$06
    ldx #$18
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_26
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$06
    ldx #$1B
    ldy #$FF             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_27
    sta WSYNC
    lda #$08
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$06
    ldx #$1B
    ldy #$FF             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_28
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$06
    ldx #$19
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_29
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$07
    ldx #$F9
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_30
    sta WSYNC
    lda #$08
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$30
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$07
    ldx #$F9
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_31
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$78
    sta GRP1                   ; c18
    lda #$3F
    sta GRP0                   ; c23
    lda #$F7
    ldx #$F9
    ldy #$86             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_32
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$FC
    sta GRP1                   ; c18
    lda #$3F
    sta GRP0                   ; c23
    lda #$F7
    ldx #$F9
    ldy #$86             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_33
    sta WSYNC
    lda #$08
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$7C
    sta GRP1                   ; c18
    lda #$1F
    sta GRP0                   ; c23
    lda #$E6
    ldx #$19
    ldy #$86             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_34
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$78
    sta GRP1                   ; c18
    lda #$1F
    sta GRP0                   ; c23
    lda #$E6
    ldx #$19
    ldy #$86             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_35
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$30
    sta GRP1                   ; c18
    lda #$1F
    sta GRP0                   ; c23
    lda #$E6
    ldx #$19
    ldy #$86             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_36
    sta WSYNC
    lda #$08
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$38
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$66
    ldx #$19
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_37
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$30
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$66
    ldx #$19
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_38
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$78
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$67
    ldx #$F9
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_39
    sta WSYNC
    lda #$08
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$FC
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$67
    ldx #$F9
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_40
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$B8
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$67
    ldx #$F9
    ldy #$86             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_41
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$B0
    sta GRP1                   ; c18
    lda #$1F
    sta GRP0                   ; c23
    lda #$E7
    ldx #$F9
    ldy #$86             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_42
    sta WSYNC
    lda #$08
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$78
    sta GRP1                   ; c18
    lda #$1F
    sta GRP0                   ; c23
    lda #$E6
    ldx #$19
    ldy #$86             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    lda #2
    sta row
.row0_43
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$78
    sta GRP1                   ; c18
    lda #$1F
    sta GRP0                   ; c23
    lda #$E6
    ldx #$19
    ldy #$86             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_43
.row0_44
    sta WSYNC
    lda #$08
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$78
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$66
    ldx #$19
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_45
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$48
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$66
    ldx #$19
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_46
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$48
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$67
    ldx #$F9
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_47
    sta WSYNC
    lda #$08
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$48
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$67
    ldx #$F9
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_48
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$48
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$67
    ldx #$F9
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_49
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$48
    sta GRP1                   ; c18
    lda #$1F
    sta GRP0                   ; c23
    lda #$E7
    ldx #$F9
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_50
    sta WSYNC
    lda #$08
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$CC
    sta GRP1                   ; c18
    lda #$1F
    sta GRP0                   ; c23
    lda #$E7
    ldx #$F9
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_51
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$CC
    sta GRP1                   ; c18
    lda #$3F
    sta GRP0                   ; c23
    lda #$FF
    ldx #$FF
    ldy #$FF             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_52
    sta WSYNC
    lda #$0A
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$3F
    sta GRP0                   ; c23
    lda #$FF
    ldx #$FF
    ldy #$FF             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_53
    sta WSYNC
    lda #$08
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    lda #3
    sta row
.row0_54
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_54
.row0_55
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$7F
    sta GRP0                   ; c13
    lda #$FF
    sta GRP1                   ; c18
    lda #$FF
    sta GRP0                   ; c23
    lda #$FF
    ldx #$FF
    ldy #$FE             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    lda #5
    sta row
.row0_56
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_56
.row0_57
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$06
    sta GRP0                   ; c13
    lda #$CE
    sta GRP1                   ; c18
    lda #$4E
    sta GRP0                   ; c23
    lda #$EC
    ldx #$0C
    ldy #$A0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_58
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$08
    sta GRP0                   ; c13
    lda #$A8
    sta GRP1                   ; c18
    lda #$A4
    sta GRP0                   ; c23
    lda #$8A
    ldx #$0A
    ldy #$A0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_59
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$08
    sta GRP0                   ; c13
    lda #$CC
    sta GRP1                   ; c18
    lda #$E4
    sta GRP0                   ; c23
    lda #$CA
    ldx #$0C
    ldy #$40             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_60
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$08
    sta GRP0                   ; c13
    lda #$A8
    sta GRP1                   ; c18
    lda #$A4
    sta GRP0                   ; c23
    lda #$8A
    ldx #$0A
    ldy #$40             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_61
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$06
    sta GRP0                   ; c13
    lda #$AE
    sta GRP1                   ; c18
    lda #$A4
    sta GRP0                   ; c23
    lda #$EC
    ldx #$0C
    ldy #$40             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    lda #2
    sta row
.row0_62
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_62
.row0_63
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$A4
    sta GRP1                   ; c18
    lda #$CA
    sta GRP0                   ; c23
    lda #$EE
    ldx #$EE
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_64
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$EA
    sta GRP1                   ; c18
    lda #$AA
    sta GRP0                   ; c23
    lda #$2A
    ldx #$A8
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_65
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$EE
    sta GRP1                   ; c18
    lda #$CC
    sta GRP0                   ; c23
    lda #$EA
    ldx #$AE
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_66
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$AA
    sta GRP1                   ; c18
    lda #$AA
    sta GRP0                   ; c23
    lda #$8A
    ldx #$AA
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_67
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$AA
    sta GRP1                   ; c18
    lda #$AA
    sta GRP0                   ; c23
    lda #$EE
    ldx #$EE
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    lda #5
    sta row
.row0_68
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_68
.row0_69
    sta WSYNC
    lda #$1E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$0C
    sta GRP0                   ; c13
    lda #$CE
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$0E
    ldx #$EC
    ldy #$E0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_70
    sta WSYNC
    lda #$1E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$0A
    sta GRP0                   ; c13
    lda #$A8
    sta GRP1                   ; c18
    lda #$88
    sta GRP0                   ; c23
    lda #$08
    ldx #$4A
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_71
    sta WSYNC
    lda #$1E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$0C
    sta GRP0                   ; c13
    lda #$CC
    sta GRP1                   ; c18
    lda #$44
    sta GRP0                   ; c23
    lda #$0C
    ldx #$4C
    ldy #$C0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_72
    sta WSYNC
    lda #$1E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$08
    sta GRP0                   ; c13
    lda #$A8
    sta GRP1                   ; c18
    lda #$22
    sta GRP0                   ; c23
    lda #$08
    ldx #$4A
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
.row0_73
    sta WSYNC
    lda #$1E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$08
    sta GRP0                   ; c13
    lda #$AE
    sta GRP1                   ; c18
    lda #$CC
    sta GRP0                   ; c23
    lda #$08
    ldx #$EA
    ldy #$E0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    lda #4
    sta row
.row0_74
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row0_74
MainTitleDone
    SUBROUTINE
    sta WSYNC
    lda #0
    sta GRP0
    sta GRP1
    sta VDELP0
    sta VDELP1
.wait
    lda INTIM
    bne .wait
    jmp ToLogic
MainTitlePosition
    SUBROUTINE
    sec
    sbc #3
    sta WSYNC
    sec
.loop
    sbc #15
    bcs .loop
    eor #7
    asl
    asl
    asl
    asl
    sta HMP0,x
    sta RESP0,x
    rts
    echo "Title/ending bank bytes:",(*-$F000)
    
    ORG $2FA0
    GAPGATES GapAfterPosition
    ORG $2FB0
    GATES
    ORG $2FFA
    RORG $FFFA
    word ResetGate,ResetGate,ResetGate

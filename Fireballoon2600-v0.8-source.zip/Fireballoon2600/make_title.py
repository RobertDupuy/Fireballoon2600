"""Compile pixel-authored title art into native, colored 48-pixel scanlines.

Identical adjacent rows share a tiny counted loop. All six bytes are immediate
loads; the CPU time saved is spent changing both player colors every scanline.
"""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parent
frames=json.loads((ROOT/'src/title_frames.json').read_text())
entry='''TitleKernel
    SUBROUTINE
    lda mode
    cmp #4
    bcs .ending
    jmp MainTitle
.ending
    lda $1FFB
    jmp EndingKernel
'''
def setup(label):
 return f'''{label}
    SUBROUTINE
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta ENAM1
    sta PF0
    sta PF1
    sta PF2
    sta CTRLPF
    lda #$80
    sta COLUBK
    lda #3
    sta NUSIZ0
    sta NUSIZ1
    lda #1
    sta VDELP0
    sta VDELP1
    lda #55
    ldx #0
    jsr {label}Position
    lda #63
    ldx #1
    jsr {label}Position
    sta WSYNC
    sta HMOVE
    ldx #25
.space
    sta WSYNC
    dex
    bne .space
'''
def rows(kind):
 groups=[]
 for pixels,color in zip(frames[kind]['bits'],frames[kind]['colors']):
  vals=tuple(sum(pixels[i*8+j]<<(7-j) for j in range(8)) for i in range(6))
  if groups and groups[-1][0:2]==[vals,color]:groups[-1][2]+=1
  else:groups.append([vals,color,1])
 s=''
 for i,(b,c,n) in enumerate(groups):
  if n>1:s+=f'    lda #{n}\n    sta row\n'
  s+=f'''.row{kind}_{i}
    sta WSYNC
    lda #${c:02X}
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #${b[0]:02X}
    sta GRP0                   ; c13
    lda #${b[1]:02X}
    sta GRP1                   ; c18
    lda #${b[2]:02X}
    sta GRP0                   ; c23
    lda #${b[3]:02X}
    ldx #${b[4]:02X}
    ldy #${b[5]:02X}             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
'''
  if n>1:s+=f'    dec row\n    bne .row{kind}_{i}\n'
 return s
def finish(label):
 return f'''{label}Done
    SUBROUTINE
    sta WSYNC
    lda #0
    sta GRP0
    sta GRP1
    sta VDELP0
    sta VDELP1
.wait
    lda INTIM
    bne .wait
    jmp ToLogic
{label}Position
    SUBROUTINE
    sec
    sbc #3
    sta WSYNC
    sec
.loop
    sbc #15
    bcs .loop
    eor #7
    asl
    asl
    asl
    asl
    sta HMP0,x
    sta RESP0,x
    rts
'''
def tail(bank):
 return f'''    echo "Title/ending bank bytes:",(*-$F000)
    {'include "src/gap_positions.inc"' if bank==7 else ''}
    ORG ${bank*4096+0xfa0:04X}
    GAPGATES GapAfterPosition
    ORG ${bank*4096+0xfb0:04X}
    GATES
    ORG ${bank*4096+0xffa:04X}
    RORG $FFFA
    word ResetGate,ResetGate,ResetGate
'''
s='; ================= BANK 2: colored, native 48-pixel title ===============\n    ORG $2000\n    RORG $F000\n'+entry+setup('MainTitle')+rows(0)+finish('MainTitle')+tail(2)
(ROOT/'src/title_kernel.asm').write_text(s)
s='; ================= BANK 7: native endings / pause =====================\n    ORG $7000\n    RORG $F000\n'+entry+setup('EndingKernel')+'''    lda mode
    cmp #6
    bne .notPaused
    jmp PausedArt
.notPaused
    cmp #5
    beq .win
    jmp GameOverArt
.win
    jmp VictoryArt
GameOverArt
    SUBROUTINE
'''+rows(1)+'''    jmp EndingKernelDone
VictoryArt
    SUBROUTINE
'''+rows(2)+'''    jmp EndingKernelDone
PausedArt
    SUBROUTINE
'''+rows(3)+finish('EndingKernel')+tail(7)
(ROOT/'src/ending_kernel.asm').write_text(s)
(ROOT/'src/clear_kernel.asm').write_text(setup('CallClearKernel')+rows(4)+finish('CallClearKernel'))

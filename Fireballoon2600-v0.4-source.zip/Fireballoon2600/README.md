# Fireballoon 2600 — v0.4

Created by **Mark2006**. Three buildings, four street layouts, and twenty calls.

**32 KiB, standard Atari F4 banking, NTSC, 262 scanlines.** Native 6507, TIA,
and RIOT RAM; no cartridge RAM or additional processor.

## What changed

- Three separate buildings share the street, with black alleys and different
  roof heights. Four layouts rotate from the first four calls onward: central
  apartments, courtyard, high street, and twin terraces. They contain 8–11
  working windows; missing upper floors cannot catch fire or intercept shots.
- Fire stages advance every 160 frames (about 2.67 seconds) throughout the
  campaign. Outbreak pace, fire strength, wind, and hazards provide the ramp. New outbreaks enter partway
  through the first stage. Ignoring the stronger opening fire can lose a call
  in about five seconds, so the action begins immediately.
- Falling masonry appears in call 1, rescues in call 2, and wind in call 3.
  Warning markers and the 45-frame audible warning precede falling debris.
- Alternate outbreaks favor the far side of the street. Later calls mix small
  fires with occasional two-stage outbreaks, creating competing priorities.
- Once an upper fire reaches stage three, a new outbreak cannot appear below
  it and close the shot path again. Existing lower fires still intercept water.
  This keeps urgent saves possible while preserving the need to clear a path.
- The title vignette now shows the new street. The striped character, white
  road markings, water indicator, original credit, and controls are retained.

## Play

Open `Fireballoon2600-v0.4-NTSC.bin` in Stella, or use a cartridge supporting
standard **F4**, without Superchip RAM. Use the left joystick.

| Input | Action |
| --- | --- |
| Left / right | Move, including during pickup and refill |
| Tap FIRE | Pick up and throw one balloon |
| Release FIRE | Rearm the button for the next tap |
| SELECT | Pause / resume |
| RESET | Start a new game |

A tap during recovery queues one throw. Holding FIRE does not repeat. Eight
balloons fit in the bucket, which refills automatically in **60 frames**.
DOWN has no refill function. The bar shows water and refill progress.

The white digits show score. The blue pairs show call, seconds, and lives.
The arrow indicates wind. Occupied lower windows intercept shots toward upper
windows. A hit removes one fire stage and resets its growth age; a balloon
rescues a waving resident. Clear all incidents and remaining outbreaks before
time expires. Clearing the screen brings the next outbreak forward.

An unchecked fourth-stage fire, a masonry hit, or timeout costs one life and
retries the current call. There are three lives. Masonry has three falling
pieces; move into their gaps. The whole call ends when a building is lost.

Weakening scores 20, extinguishing 100, and rescue 250. Extinguishing streaks
add 10–90; a missed balloon breaks the streak. Clearing awards 10 points per
remaining second. `design.json` lists all twenty call configurations.

## Build

Install Python 3 and DASM, then run:

```sh
python3 build.py
```

Set `DASM` to the assembler executable if it is not on PATH. The result is
`build/Fireballoon2600-NTSC.bin`, with symbols and an assembly listing.

`art_v04.py` authors sprites, the title, and level records. `street_design.py`
defines the building heights and playfield masks. `make_facade.py` generates
the timed facade banks. The game logic is in `src/engine.asm`; the level loader,
HUD, and street renderer are in `src/scene.asm` and `src/street.asm`.
Generated assembly is included for inspection.

## Renderer and memory

| Bank | Purpose |
| --- | --- |
| 0 | Simulation, input, scoring, sound, frame scheduling, collision maps |
| 1 | Central-apartments facade and window art |
| 2 | Colored 48-pixel title |
| 3 | Level loader, HUD, street, call-clear screen |
| 4–6 | Courtyard, high-street, and twin-terraces facades |
| 7 | Game-over, victory, and pause screens |

P0 and P1 form one 16-pixel image. Three hardware copies and six timed graphics
writes draw three independent images on each scanline, reused over four floors.
Each 20-line body runs at **76 CPU cycles per row with no WSYNC inside it**.

| Row | Six GRP0 / GRP1 write cycles |
| --- | --- |
| Balloon update | 10, 18, 39, 47, 55, 58 |
| Masonry update | 12, 20, 39, 47, 55, 58 |

Sharing the player color across selected adjacent rows makes room for the
earlier right-window write. The sixth sprite byte is pipelined in X. Tables are
aligned to avoid indexed page crossings. The ball supplies blue projectiles;
M1 supplies three masonry pieces. Both players are reused for the character,
bucket, and street-level debris below the facade. All lettering uses sprites.

The new geometry uses a reserved heat value for absent windows; variables still
occupy **118 bytes**, leaving ten bytes for the stack. Every bank has matching
switch gates and reset vectors. The cartridge size and hardware requirements
are unchanged.

Fire Fighter was a research reference for scanline scheduling and object reuse.
Its ROM, code, artwork, and gameplay are not included.

## Verification

The supplied reports identify the exact ROM SHA-256. Emulator testing uses
Stella 7.0_pre/libretro, pinned to commit
`ba52c43b9eda950eb0c0eec69cda9b17dee8c39b`, with the supplied observation patch.

```sh
python3 -m pip install numpy pillow
python3 tests/build_stella.py
python3 tests/verify_v04.py
python3 tests/verify_streets.py
python3 tests/expert_player.py
python3 tests/replay.py
```

`STELLA_CORE` can point to an existing patched libretro core. Mechanics and
geometry fixtures explicitly change RAM to isolate cases. Campaign play and
saved-input replay use joystick inputs only. An automated player can verify
reproducible playability, but cannot establish human difficulty or fun.

The movie records native Stella video and TIA audio at normal speed. Images
are enlarged with nearest-neighbor scaling, with no artwork painted over the
gameplay. Run `python3 tests/record_movie.py` to recreate it (FFmpeg required).

This release is NTSC. Physical-console testing and human difficulty calibration
remain outstanding.

"""Package only matching, verified deliverables from the final native ROM."""
from pathlib import Path
import json,hashlib,zipfile,shutil,subprocess
R=Path(__file__).resolve().parent
D=R.parent/'deliverables';D.mkdir(exist_ok=True)
b=(R/'build/Fireballoon2600-NTSC.bin').read_bytes();sha=hashlib.sha256(b).hexdigest()
assert len(b)==32768
reports={n:json.loads((R/'build'/n).read_text()) for n in ['campaign.json','replay.json','verification.json','beam-check.json','streets-verification.json']}
assert all(r.get('sha256',r.get('rom_sha256'))==sha for r in reports.values())
assert reports['campaign.json']['won'] and reports['replay.json']['won']
assert all(v['pass'] for v in reports['verification.json']['checks'])
assert all(v['pass_'] for v in reports['streets-verification.json']['checks'])
for n in ['campaign.json','replay.json','streets-verification.json']:assert set(reports[n]['scanlines'])=={'262'}
for i in range(8):assert b[i*4096+4090:i*4096+4096]==b[4090:4096]
capture=json.loads((R/'build/movie-v04/capture.json').read_text())
assert capture['replay']['sha256']==sha and capture['memory_writes']==0 and capture['playback_speed']==1
movie=D/'Fireballoon2600-v0.4-with-sound.mp4'
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-show_streams','-show_format','-of','json',str(movie)]))
assert {v['codec_type'] for v in probe['streams']}=={'video','audio'}
assert float(probe['format']['duration'])>90
V=R/'validation';V.mkdir(exist_ok=True)
for n in [*reports,'inputs.json']:
 shutil.copy2(R/'build'/n,V/n)
shutil.copy2(R/'build/movie-v04/capture.json',V/'capture.json')
summary={'title':'Fireballoon 2600','creator':'Mark2006','version':'0.4','tv':'NTSC','mapper':'F4',
 'rom_bytes':len(b),'sha256':sha,'allocated_ram_bytes':118,'stack_reserved_bytes':10,
 'emulator':'Stella 7.0_pre libretro','emulator_commit':'ba52c43b9eda950eb0c0eec69cda9b17dee8c39b',
 'assembler':'DASM 2.20.16','calls_completed':20,'input_frames':reports['replay.json']['frames'],
 'replayed_without_planner':True,'game_state_writes_in_campaign_replay_or_movie':0,
 'scanlines':reports['replay.json']['scanlines'],'ending_lives':reports['replay.json']['ending_lives'],
 'fixture_checks_passed':len(reports['verification.json']['checks']),
 'street_checks_passed':len(reports['streets-verification.json']['checks']),
 'buildings_on_screen':3,'street_layouts':4,
 'window_scanlines_verified':reports['beam-check.json']['window_rows'],
 'real_hardware_tested':False,'pal_tested':False,'human_difficulty_calibrated':False,
 'movie_seconds':float(probe['format']['duration']),'movie_sha256':hashlib.sha256(movie.read_bytes()).hexdigest()}
(V/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
romname='Fireballoon2600-v0.4-NTSC.bin';(D/romname).write_bytes(b);(R/romname).write_bytes(b)
shutil.copy2(R/'build/Fireballoon2600-preview.png',D/'Fireballoon2600-v0.4-preview.png')
files=[R/n for n in ['README.md','build.py','art_v04.py','street_design.py','design.json','make_facade.py','make_title.py','package.py',romname]]
files+=sorted((R/'src').glob('*'))+sorted((R/'tests').glob('*.py'))+[R/'tests/stella-observation.patch']+sorted(V.glob('*.json'))
files+=[R/'build'/n for n in ['inputs.json','campaign.json','Fireballoon2600-NTSC.bin','Fireballoon2600.sym','Fireballoon2600.lst','title.png','gameplay.png','ending.png','Fireballoon2600-preview.png']]
archive=D/'Fireballoon2600-v0.4-source.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for f in files:
  assert f.is_file(),f
  z.write(f,Path('Fireballoon2600')/f.relative_to(R))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps(summary,indent=2))

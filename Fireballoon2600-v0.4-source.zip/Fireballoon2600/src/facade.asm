; ================= BANK 1: three 16-pixel images, scanline reuse ===========
    ORG $1000
    RORG $F000
FloorsKernel
    SUBROUTINE
.loop
    jsr DrawFloor
    inc floor
    lda floor
    cmp #4
    bcc .loop
    jmp ToStreet
DrawFloor
    SUBROUTINE
    ldx floor
    lda mode
    cmp #3
    bne .normalFloor
    lda transition
    cmp CollapseTimeK,x
    bcs .normalFloor
    jmp CollapsedFloor
.normalFloor
    lda #0
    sta wallColor
    sta WSYNC                  ; separator 0
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta ENAM1
    sta HMCLR
    lda #$88
    sta COLUPF
    lda wallColor
    nop
    sta COLUBK
    lda SolidPF1,x
    sta PF1
    lda SolidPF2,x
    sta PF2
    lda #0
    sta PF0
    lda FloorFirst,x
    sta tmp2
    tax
    lda artIndex,x
    tax
    sta WSYNC                  ; separator 1: first window
    lda ArtLeftLo,x
    sta p0
    lda ArtRightLo,x
    sta p1
    lda ArtPage,x
    sta p0+1
    sta p1+1
    ldx tmp2
    inx
    lda artIndex,x
    tax
    lda wallColor
    sta COLUBK
    sta WSYNC                  ; separator 2: middle window
    lda ArtLeftLo,x
    sta p2
    lda ArtRightLo,x
    sta p3
    lda ArtPage,x
    sta p2+1
    sta p3+1
    ldx tmp2
    inx
    inx
    lda artIndex,x
    tax
    sta WSYNC                  ; separator 3: right window
    lda ArtLeftLo,x
    sta p4
    lda ArtRightLo,x
    sta p5
    lda ArtPage,x
    sta p4+1
    sta p5+1
    ldy floor
    lda ballBandLo,y
    sta ballPtr
    lda #>BallMask
    sta ballPtr+1
    lda #<BrickMask
    sta colorPtr
    lda #>BrickMask
    sta colorPtr+1
    sta WSYNC                  ; separator 4: masonry position mask
    lda brickY
    cmp KBandTop,y
    bcc .brickReady
    cmp KBandLimit,y
    bcs .brickReady
    lda KBandBottom,y
    sec
    sbc brickY
    sta row
    lda #128
    sec
    sbc row
    sta colorPtr
.brickReady
    lda #0
    sta PF0
    lda #0
    sta PF1
    sta PF2
    lda #$06
    sta COLUP0
    sta COLUP1
    lda ballBandX,y
    ldx #4
    jsr KPosition              ; separator 5: ball horizontal positioning
    sta WSYNC                  ; separator 6: apply motion / facade masks
    sta HMOVE
    lda #$88
    sta COLUPF
    lda wallColor
    sta COLUBK
    lda #0
    sta PF0
    lda BodyPF1,y
    sta PF1
    lda BodyPF2,y
    sta PF2
    lda #1
    sta CTRLPF
    ldy #19
    lda (p5),y
    tax
    lda #$06
    REPEAT 11
    nop
    REPEND
    bit frame                  ; c74: enter row two cycles before the boundary
    nop
    nop
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (ballPtr),y
    sta ENABL                  ; c26: blue balloon visibility
    and #$FD                   ; ball enable bit must NOT enable playfield score mode
    sta CTRLPF                 ; c31: same byte selects round balloon width
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$04                   ; c74: next scanline begins; no WSYNC
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (colorPtr),y
    sta ENAM1                  ; c28: three-piece masonry shower
    bit frame                  ; c31: balanced with balloon-width write
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$36                   ; c74: next scanline begins; no WSYNC
    nop
    nop
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (ballPtr),y
    sta ENABL                  ; c26: blue balloon visibility
    and #$FD                   ; ball enable bit must NOT enable playfield score mode
    sta CTRLPF                 ; c31: same byte selects round balloon width
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$86
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$36                   ; c74: next scanline begins; no WSYNC
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (colorPtr),y
    sta ENAM1                  ; c28: three-piece masonry shower
    bit frame                  ; c31: balanced with balloon-width write
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$38                   ; c74: next scanline begins; no WSYNC
    nop
    nop
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (ballPtr),y
    sta ENABL                  ; c26: blue balloon visibility
    and #$FD                   ; ball enable bit must NOT enable playfield score mode
    sta CTRLPF                 ; c31: same byte selects round balloon width
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$38                   ; c74: next scanline begins; no WSYNC
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (colorPtr),y
    sta ENAM1                  ; c28: three-piece masonry shower
    bit frame                  ; c31: balanced with balloon-width write
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$84
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$2A                   ; c74: next scanline begins; no WSYNC
    nop
    nop
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (ballPtr),y
    sta ENABL                  ; c26: blue balloon visibility
    and #$FD                   ; ball enable bit must NOT enable playfield score mode
    sta CTRLPF                 ; c31: same byte selects round balloon width
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$2A                   ; c74: next scanline begins; no WSYNC
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (colorPtr),y
    sta ENAM1                  ; c28: three-piece masonry shower
    bit frame                  ; c31: balanced with balloon-width write
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$2C                   ; c74: next scanline begins; no WSYNC
    nop
    nop
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (ballPtr),y
    sta ENABL                  ; c26: blue balloon visibility
    and #$FD                   ; ball enable bit must NOT enable playfield score mode
    sta CTRLPF                 ; c31: same byte selects round balloon width
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$86
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$2C                   ; c74: next scanline begins; no WSYNC
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (colorPtr),y
    sta ENAM1                  ; c28: three-piece masonry shower
    bit frame                  ; c31: balanced with balloon-width write
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$2E                   ; c74: next scanline begins; no WSYNC
    nop
    nop
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (ballPtr),y
    sta ENABL                  ; c26: blue balloon visibility
    and #$FD                   ; ball enable bit must NOT enable playfield score mode
    sta CTRLPF                 ; c31: same byte selects round balloon width
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$2E                   ; c74: next scanline begins; no WSYNC
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (colorPtr),y
    sta ENAM1                  ; c28: three-piece masonry shower
    bit frame                  ; c31: balanced with balloon-width write
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$84
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$1A                   ; c74: next scanline begins; no WSYNC
    nop
    nop
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (ballPtr),y
    sta ENABL                  ; c26: blue balloon visibility
    and #$FD                   ; ball enable bit must NOT enable playfield score mode
    sta CTRLPF                 ; c31: same byte selects round balloon width
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$1A                   ; c74: next scanline begins; no WSYNC
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (colorPtr),y
    sta ENAM1                  ; c28: three-piece masonry shower
    bit frame                  ; c31: balanced with balloon-width write
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$1C                   ; c74: next scanline begins; no WSYNC
    nop
    nop
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (ballPtr),y
    sta ENABL                  ; c26: blue balloon visibility
    and #$FD                   ; ball enable bit must NOT enable playfield score mode
    sta CTRLPF                 ; c31: same byte selects round balloon width
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$86
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$1C                   ; c74: next scanline begins; no WSYNC
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (colorPtr),y
    sta ENAM1                  ; c28: three-piece masonry shower
    bit frame                  ; c31: balanced with balloon-width write
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$1E                   ; c74: next scanline begins; no WSYNC
    nop
    nop
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (ballPtr),y
    sta ENABL                  ; c26: blue balloon visibility
    and #$FD                   ; ball enable bit must NOT enable playfield score mode
    sta CTRLPF                 ; c31: same byte selects round balloon width
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$1E                   ; c74: next scanline begins; no WSYNC
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (colorPtr),y
    sta ENAM1                  ; c28: three-piece masonry shower
    bit frame                  ; c31: balanced with balloon-width write
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$84
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$0E                   ; c74: next scanline begins; no WSYNC
    nop
    nop
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (ballPtr),y
    sta ENABL                  ; c26: blue balloon visibility
    and #$FD                   ; ball enable bit must NOT enable playfield score mode
    sta CTRLPF                 ; c31: same byte selects round balloon width
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    dey
    lda (p5),y
    tax
    ; c67: following row's sixth byte is ready in X
    lda #$88
    sta COLUPF                  ; c72: next row's masonry/raster state
    lda #$1A                   ; c74: next scanline begins; no WSYNC
    sta COLUP0
    sta COLUP1
    lda (p0),y
    sta GRP0                   ; c10/12: left image, first half
    lda (p1),y
    sta GRP1                   ; c18/20: left image, second half
    lda (colorPtr),y
    sta ENAM1                  ; c28: three-piece masonry shower
    bit frame                  ; c31: balanced with balloon-width write
    lda (p2),y
    sta GRP0                   ; c39: middle image, first half
    lda (p3),y
    sta GRP1                   ; c47: middle image, second half
    lda (p4),y
    sta GRP0                   ; c55: right image, first half
    stx GRP1                   ; c58: right image, pipelined second half
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta ENAM1
    rts
CollapsedFloor
    SUBROUTINE
    lda transition
    clc
    adc #8
    cmp CollapseTimeK,x
    lda #0
    bcc .noDust
    lda #$FF
.noDust
    sta tmp
    sta WSYNC
    lda #0
    sta GRP0
    sta GRP1
    sta PF0
    sta PF1
    sta PF2
    sta ENABL
    sta ENAM1
    sta COLUBK
    lda #$06
    sta COLUP0
    sta COLUP1
    ldy #26
.dust
    sta WSYNC
    lda DustRows,y
    and tmp
    sta GRP0
    sta GRP1
    dey
    bpl .dust
    lda #0
    sta GRP0
    sta GRP1
    rts
DustRows
    byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,$24,$5A,$A5,$42
KPosition
    SUBROUTINE
    sec
    sbc #3
    bcs .coord
    lda #0
.coord
    sta WSYNC
    sec
.loop
    sbc #15
    bcs .loop
    eor #7
    asl
    asl
    asl
    asl
    sta HMP0,x
    sta RESP0,x
    rts
SolidPF1 byte $00,$0F,$0F,$0F
SolidPF2 byte $E0,$EF,$EF,$EF
BodyPF1 byte $00,$0C,$0C,$0C
BodyPF2 byte $20,$2C,$2C,$2C

FloorFirst byte 0,3,6,9
CollapseTimeK byte 105,80,55,30
KBandTop byte 38,66,94,122
KBandBottom byte 57,85,113,141
KBandLimit byte 64,92,120,148
    include "src/flames.inc"
    align 256
BallMask
    ds 64,1
    byte $03,$13,$33,$33,$33,$13,$03,$01
    ds 56,1
    byte $03,$13,$23,$23,$13,$03
    ds 122,1
    align 256
BrickMask
    ds 128,0
    byte 2,2,2,2
    ds 124,0
    echo "Facade bytes:",(*-$F000)
    ORG $1FB0
    GATES
    ORG $1FFA
    RORG $FFFA
    word ResetGate,ResetGate,ResetGate

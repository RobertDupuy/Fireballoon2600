; ================= BANK 7: native endings / pause =====================
    ORG $7000
    RORG $F000
TitleKernel
    SUBROUTINE
    lda mode
    cmp #4
    bcs .ending
    jmp MainTitle
.ending
    lda $1FFB
    jmp EndingKernel
EndingKernel
    SUBROUTINE
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta ENAM1
    sta PF0
    sta PF1
    sta PF2
    sta CTRLPF
    lda #$80
    sta COLUBK
    lda #3
    sta NUSIZ0
    sta NUSIZ1
    lda #1
    sta VDELP0
    sta VDELP1
    lda #55
    ldx #0
    jsr EndingKernelPosition
    lda #63
    ldx #1
    jsr EndingKernelPosition
    sta WSYNC
    sta HMOVE
    ldx #25
.space
    sta WSYNC
    dex
    bne .space
    lda mode
    cmp #6
    bne .notPaused
    jmp PausedArt
.notPaused
    cmp #5
    beq .win
    jmp GameOverArt
.win
    jmp VictoryArt
GameOverArt
    SUBROUTINE
    lda #2
    sta row
.row1_0
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_0
    lda #4
    sta row
.row1_1
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$1E
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$66
    ldx #$7E
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_1
    lda #4
    sta row
.row1_2
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$60
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$7E
    ldx #$60
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_2
    lda #4
    sta row
.row1_3
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$66
    sta GRP1                   ; c18
    lda #$7E
    sta GRP0                   ; c23
    lda #$7E
    ldx #$78
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_3
    lda #4
    sta row
.row1_4
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$66
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$66
    ldx #$60
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_4
    lda #4
    sta row
.row1_5
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$1E
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$66
    ldx #$7E
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_5
    lda #2
    sta row
.row1_6
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_6
    lda #4
    sta row
.row1_7
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$18
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$7E
    ldx #$78
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_7
    lda #4
    sta row
.row1_8
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$66
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$60
    ldx #$66
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_8
    lda #4
    sta row
.row1_9
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$66
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$78
    ldx #$78
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_9
    lda #4
    sta row
.row1_10
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$66
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$60
    ldx #$66
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_10
    lda #4
    sta row
.row1_11
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$18
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$7E
    ldx #$66
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_11
    lda #11
    sta row
.row1_12
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_12
    lda #3
    sta row
.row1_13
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$03
    sta GRP0                   ; c13
    lda #$B2
    sta GRP1                   ; c18
    lda #$81
    sta GRP0                   ; c23
    lda #$19
    ldx #$3A
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_13
    lda #3
    sta row
.row1_14
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$01
    sta GRP0                   ; c13
    lda #$2A
    sta GRP1                   ; c18
    lda #$82
    sta GRP0                   ; c23
    lda #$A2
    ldx #$93
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_14
    lda #3
    sta row
.row1_15
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$01
    sta GRP0                   ; c13
    lda #$31
    sta GRP1                   ; c18
    lda #$03
    sta GRP0                   ; c23
    lda #$AB
    ldx #$93
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_15
    lda #3
    sta row
.row1_16
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$01
    sta GRP0                   ; c13
    lda #$29
    sta GRP1                   ; c18
    lda #$02
    sta GRP0                   ; c23
    lda #$AA
    ldx #$93
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_16
    lda #3
    sta row
.row1_17
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$01
    sta GRP0                   ; c13
    lda #$29
    sta GRP1                   ; c18
    lda #$02
    sta GRP0                   ; c23
    lda #$9A
    ldx #$BA
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_17
    lda #10
    sta row
.row1_18
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_18
    lda #2
    sta row
.row1_19
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$0C
    sta GRP0                   ; c13
    lda #$CE
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$0E
    ldx #$EC
    ldy #$E0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_19
    lda #2
    sta row
.row1_20
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$0A
    sta GRP0                   ; c13
    lda #$A8
    sta GRP1                   ; c18
    lda #$88
    sta GRP0                   ; c23
    lda #$08
    ldx #$4A
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_20
    lda #2
    sta row
.row1_21
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$0C
    sta GRP0                   ; c13
    lda #$CC
    sta GRP1                   ; c18
    lda #$44
    sta GRP0                   ; c23
    lda #$0C
    ldx #$4C
    ldy #$C0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_21
    lda #2
    sta row
.row1_22
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$08
    sta GRP0                   ; c13
    lda #$A8
    sta GRP1                   ; c18
    lda #$22
    sta GRP0                   ; c23
    lda #$08
    ldx #$4A
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_22
    lda #2
    sta row
.row1_23
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$08
    sta GRP0                   ; c13
    lda #$AE
    sta GRP1                   ; c18
    lda #$CC
    sta GRP0                   ; c23
    lda #$08
    ldx #$EA
    ldy #$E0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_23
    lda #6
    sta row
.row1_24
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row1_24
    jmp EndingKernelDone
VictoryArt
    SUBROUTINE
    lda #3
    sta row
.row2_0
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_0
    lda #4
    sta row
.row2_1
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$04
    sta GRP1                   ; c18
    lda #$88
    sta GRP0                   ; c23
    lda #$0E
    ldx #$E0
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_1
    lda #4
    sta row
.row2_2
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$0A
    sta GRP1                   ; c18
    lda #$88
    sta GRP0                   ; c23
    lda #$02
    ldx #$A0
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_2
    lda #4
    sta row
.row2_3
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$0E
    sta GRP1                   ; c18
    lda #$88
    sta GRP0                   ; c23
    lda #$0E
    ldx #$A0
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_3
    lda #4
    sta row
.row2_4
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$0A
    sta GRP1                   ; c18
    lda #$88
    sta GRP0                   ; c23
    lda #$08
    ldx #$A0
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_4
    lda #4
    sta row
.row2_5
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$0A
    sta GRP1                   ; c18
    lda #$EE
    sta GRP0                   ; c23
    lda #$0E
    ldx #$E0
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_5
    lda #5
    sta row
.row2_6
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_6
    lda #3
    sta row
.row2_7
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$19
    sta GRP0                   ; c13
    lda #$22
    sta GRP1                   ; c18
    lda #$18
    sta GRP0                   ; c23
    lda #$1A
    ldx #$39
    ldy #$30             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_7
    lda #3
    sta row
.row2_8
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$22
    sta GRP0                   ; c13
    lda #$A2
    sta GRP1                   ; c18
    lda #$20
    sta GRP0                   ; c23
    lda #$22
    ldx #$22
    ldy #$A8             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_8
    lda #3
    sta row
.row2_9
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$23
    sta GRP0                   ; c13
    lda #$A2
    sta GRP1                   ; c18
    lda #$10
    sta GRP0                   ; c23
    lda #$22
    ldx #$33
    ldy #$B0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_9
    lda #3
    sta row
.row2_10
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$22
    sta GRP0                   ; c13
    lda #$A2
    sta GRP1                   ; c18
    lda #$08
    sta GRP0                   ; c23
    lda #$22
    ldx #$22
    ldy #$A8             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_10
    lda #3
    sta row
.row2_11
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$1A
    sta GRP0                   ; c13
    lda #$BB
    sta GRP1                   ; c18
    lda #$B0
    sta GRP0                   ; c23
    lda #$1B
    ldx #$BA
    ldy #$A8             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_11
    lda #9
    sta row
.row2_12
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_12
    lda #3
    sta row
.row2_13
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$06
    sta GRP0                   ; c13
    lda #$EE
    sta GRP1                   ; c18
    lda #$A0
    sta GRP0                   ; c23
    lda #$64
    ldx #$AE
    ldy #$C0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_13
    lda #3
    sta row
.row2_14
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$08
    sta GRP0                   ; c13
    lda #$44
    sta GRP1                   ; c18
    lda #$A0
    sta GRP0                   ; c23
    lda #$8A
    ldx #$A8
    ldy #$A0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_14
    lda #3
    sta row
.row2_15
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$08
    sta GRP0                   ; c13
    lda #$44
    sta GRP1                   ; c18
    lda #$40
    sta GRP0                   ; c23
    lda #$4E
    ldx #$AC
    ldy #$A0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_15
    lda #3
    sta row
.row2_16
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$08
    sta GRP0                   ; c13
    lda #$44
    sta GRP1                   ; c18
    lda #$40
    sta GRP0                   ; c23
    lda #$2A
    ldx #$A8
    ldy #$A0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_16
    lda #3
    sta row
.row2_17
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$06
    sta GRP0                   ; c13
    lda #$E4
    sta GRP1                   ; c18
    lda #$40
    sta GRP0                   ; c23
    lda #$CA
    ldx #$4E
    ldy #$C0             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_17
    lda #11
    sta row
.row2_18
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_18
    lda #2
    sta row
.row2_19
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$A4
    sta GRP1                   ; c18
    lda #$CA
    sta GRP0                   ; c23
    lda #$EE
    ldx #$EE
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_19
    lda #2
    sta row
.row2_20
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$EA
    sta GRP1                   ; c18
    lda #$AA
    sta GRP0                   ; c23
    lda #$2A
    ldx #$A8
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_20
    lda #2
    sta row
.row2_21
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$EE
    sta GRP1                   ; c18
    lda #$CC
    sta GRP0                   ; c23
    lda #$EA
    ldx #$AE
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_21
    lda #2
    sta row
.row2_22
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$AA
    sta GRP1                   ; c18
    lda #$AA
    sta GRP0                   ; c23
    lda #$8A
    ldx #$AA
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_22
    lda #2
    sta row
.row2_23
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$AA
    sta GRP1                   ; c18
    lda #$AA
    sta GRP0                   ; c23
    lda #$EE
    ldx #$EE
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_23
    lda #8
    sta row
.row2_24
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row2_24
    jmp EndingKernelDone
PausedArt
    SUBROUTINE
    lda #12
    sta row
.row3_0
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_0
    lda #4
    sta row
.row3_1
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$78
    sta GRP0                   ; c13
    lda #$18
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$1E
    ldx #$7E
    ldy #$78             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_1
    lda #4
    sta row
.row3_2
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$66
    sta GRP0                   ; c13
    lda #$66
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$60
    ldx #$60
    ldy #$66             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_2
    lda #4
    sta row
.row3_3
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$78
    sta GRP0                   ; c13
    lda #$7E
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$18
    ldx #$78
    ldy #$66             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_3
    lda #4
    sta row
.row3_4
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$60
    sta GRP0                   ; c13
    lda #$66
    sta GRP1                   ; c18
    lda #$66
    sta GRP0                   ; c23
    lda #$06
    ldx #$60
    ldy #$66             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_4
    lda #4
    sta row
.row3_5
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$60
    sta GRP0                   ; c13
    lda #$66
    sta GRP1                   ; c18
    lda #$7E
    sta GRP0                   ; c23
    lda #$78
    ldx #$7E
    ldy #$78             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_5
    lda #23
    sta row
.row3_6
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_6
    lda #3
    sta row
.row3_7
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$06
    sta GRP1                   ; c18
    lda #$E8
    sta GRP0                   ; c23
    lda #$E6
    ldx #$E0
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_7
    lda #3
    sta row
.row3_8
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$08
    sta GRP1                   ; c18
    lda #$88
    sta GRP0                   ; c23
    lda #$88
    ldx #$40
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_8
    lda #3
    sta row
.row3_9
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$04
    sta GRP1                   ; c18
    lda #$C8
    sta GRP0                   ; c23
    lda #$C8
    ldx #$40
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_9
    lda #3
    sta row
.row3_10
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$02
    sta GRP1                   ; c18
    lda #$88
    sta GRP0                   ; c23
    lda #$88
    ldx #$40
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_10
    lda #3
    sta row
.row3_11
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$0C
    sta GRP1                   ; c18
    lda #$EE
    sta GRP0                   ; c23
    lda #$E6
    ldx #$40
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_11
    lda #8
    sta row
.row3_12
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_12
    lda #2
    sta row
.row3_13
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$03
    sta GRP0                   ; c13
    lda #$90
    sta GRP1                   ; c18
    lda #$33
    sta GRP0                   ; c23
    lda #$9A
    ldx #$AB
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_13
    lda #2
    sta row
.row3_14
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$01
    sta GRP0                   ; c13
    lda #$28
    sta GRP1                   ; c18
    lda #$2A
    sta GRP0                   ; c23
    lda #$22
    ldx #$BA
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_14
    lda #2
    sta row
.row3_15
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$01
    sta GRP0                   ; c13
    lda #$28
    sta GRP1                   ; c18
    lda #$33
    sta GRP0                   ; c23
    lda #$12
    ldx #$BB
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_15
    lda #2
    sta row
.row3_16
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$01
    sta GRP0                   ; c13
    lda #$28
    sta GRP1                   ; c18
    lda #$2A
    sta GRP0                   ; c23
    lda #$0A
    ldx #$AA
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_16
    lda #2
    sta row
.row3_17
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$01
    sta GRP0                   ; c13
    lda #$10
    sta GRP1                   ; c18
    lda #$2B
    sta GRP0                   ; c23
    lda #$B3
    ldx #$AB
    ldy #$80             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_17
    lda #8
    sta row
.row3_18
    sta WSYNC
    lda #$0E
    sta COLUP0                 ; c5
    sta COLUP1                 ; c8
    lda #$00
    sta GRP0                   ; c13
    lda #$00
    sta GRP1                   ; c18
    lda #$00
    sta GRP0                   ; c23
    lda #$00
    ldx #$00
    ldy #$00             ; c29
    REPEAT 6
    nop
    REPEND
    sta GRP1                   ; c44
    stx GRP0                   ; c47
    sty GRP1                   ; c50
    sty GRP0                   ; c53
    dec row
    bne .row3_18
EndingKernelDone
    SUBROUTINE
    sta WSYNC
    lda #0
    sta GRP0
    sta GRP1
    sta VDELP0
    sta VDELP1
.wait
    lda INTIM
    bne .wait
    jmp ToLogic
EndingKernelPosition
    SUBROUTINE
    sec
    sbc #3
    sta WSYNC
    sec
.loop
    sbc #15
    bcs .loop
    eor #7
    asl
    asl
    asl
    asl
    sta HMP0,x
    sta RESP0,x
    rts
    echo "Title/ending bank bytes:",(*-$F000)
    ORG $7FB0
    GATES
    ORG $7FFA
    RORG $FFFA
    word ResetGate,ResetGate,ResetGate

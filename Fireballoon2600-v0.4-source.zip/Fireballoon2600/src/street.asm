StreetKernel
    SUBROUTINE
    sta WSYNC
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta ENAM1
    sta NUSIZ0
    sta NUSIZ1
    sta PF0
    sta PF1
    sta PF2
    lda #$06
    sta COLUBK
    lda #$0E
    sta COLUPF
    lda #$FF
    sta PF0
    sta PF1
    sta PF2
    sta WSYNC
    lda #$04
    sta COLUBK
    lda #0
    sta PF0
    sta PF1
    sta PF2
    lda manX
    ldx #0
    jsr StreetPosition
    lda brickY
    cmp #150
    bcc .bucketPos
    lda #6
    sta NUSIZ1
    lda brickX
    jmp .objectPos
.bucketPos
    lda manX
    clc
    adc #6
.objectPos
    ldx #1
    jsr StreetPosition
    sta WSYNC
    sta HMOVE
    lda facing
    ldx pose
    beq .faceReady
    lda #0
.faceReady
    sta REFP0
    lda #$82
    sta COLUBK
    lda #$9C
    sta COLUP1
    lda #<ManColors
    sta colorPtr
    lda #>ManColors
    sta colorPtr+1
    lda #<Man0
    sta spritePtr
    lda #>Man0
    sta spritePtr+1
    lda pose
    beq .walk
    cmp #9
    bcc .throw
    lda #<ReachColors
    sta colorPtr
    lda #<Man2
    bne .poseReady
.throw
    lda #<Man3
    bne .poseReady
.walk
    lda SWCHA
    and #$C0
    cmp #$C0
    beq .poseReadyBlank
    lda frame
    lsr
    lsr
    and #3
    tax
    lda StreetWalkFrames,x
.poseReady
    sta spritePtr
.poseReadyBlank
    lda #$0E
    sta COLUPF
    lda #0
    sta PF0
    sta PF1
    sta PF2
    ldy #27
.man
    sta WSYNC
    lda (spritePtr),y
    sta GRP0
    lda (colorPtr),y
    sta COLUP0
    lda brickY
    cmp #150
    bcs .brick
    lda pose
    cmp #5
    bcc .bucket
    cmp #9
    bcs .bucket
    lda BucketThrow,y
    jmp .object
.bucket
    lda Bucket,y
.object
    sta GRP1
    jmp .road
.brick
    sty row
    lda #185
    sec
    sbc brickY
    sec
    sbc row
    cmp #4
    lda #0
    bcs .brickOff
    lda #$F0
.brickOff
    sta GRP1
    lda #$28
    sta COLUP1
.road
    dey
    bpl .man
    sta WSYNC
    lda #0
    sta GRP0
    sta GRP1
    lda #$55
    sta PF1
    lda #$AA
    sta PF2
    lda #$0E
    sta COLUPF
    sta WSYNC
    lda #0
    sta PF1
    sta PF2
.waitDisplay
    lda INTIM
    bne .waitDisplay
    jmp ToLogic
StreetWalkFrames byte <Man0,<Man1,<Man4,<Man5

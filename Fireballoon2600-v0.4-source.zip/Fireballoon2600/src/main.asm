    processor 6502
    include "src/hardware.inc"
    include "src/ram.inc"

; All banks share entry trampolines. No RAM or coprocessor on the cartridge.
    MAC GATES
    RORG $FFB0
ResetGate
    SUBROUTINE
    lda $1FF4
    jmp Reset
    ds $FFC0-*, $EA
ToLogic
    SUBROUTINE
    lda $1FF4
    jmp FrameLogic
ToKernel
    SUBROUTINE
    sta HMCLR
    lda $1FF7
    jmp Kernel
ToTitle
    SUBROUTINE
    lda $1FF6
    jmp TitleKernel
ToLevel
    SUBROUTINE
    lda $1FF7
    jmp LoadLevel
FromLevel
    SUBROUTINE
    lda $1FF4
    jmp LevelReturn
ToFloors
    SUBROUTINE
    ldx palette
    lda $1FF4,x
    jmp FloorsKernel
ToStreet
    SUBROUTINE
    lda $1FF7
    jmp StreetKernel
    ENDM

    include "src/engine.asm"
    include "src/facade.asm"
    include "src/title_kernel.asm"
    include "src/scene.asm"
    include "src/facade_extra.asm"
    include "src/ending_kernel.asm"

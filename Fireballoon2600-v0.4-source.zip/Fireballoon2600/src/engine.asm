; ================= BANK 0: game logic, sound, frame scheduling ==============
    ORG $0000
    RORG $F000
Reset
    SUBROUTINE
    sei
    cld
    ldx #$FF
    txs
    lda #0
.clear
    sta $00,x
    dex
    bne .clear
    lda #$5D
    sta random
    lda #2
    sta VBLANK
    jmp FrameLogic

FrameLogic
    SUBROUTINE
    sta WSYNC
    lda #2
    sta VBLANK
    lda #32
    sta TIM64T
    inc frame
    jsr Update
    jsr Audio
.waitOver
    lda INTIM
    bne .waitOver
    sta WSYNC
    lda #2
    sta VSYNC
    sta WSYNC
    sta WSYNC
    sta WSYNC
    lda #0
    sta VSYNC
    lda #42
    sta TIM64T
    jsr Prepare
.waitBlank
    lda INTIM
    bne .waitBlank
    sta WSYNC
    lda #0
    sta VBLANK
    lda #234
    sta TIM64T
    lda mode
    beq .title
    cmp #4
    beq .title
    cmp #5
    beq .title
    cmp #6
    beq .title
    jmp ToKernel
.title
    jmp ToTitle

Update
    SUBROUTINE
    lda random
    lsr
    bcc .rng
    eor #$B8
.rng
    sta random
    lda SWCHB
    and #3
    sta tmp
    cmp switches
    beq .switchDone
    sta switches
    and #1
    bne .notReset
    jmp NewGame
.notReset
    lda tmp
    and #2
    bne .switchDone
    lda mode
    cmp #1
    bne .notPause
    lda #6
    sta mode
    rts
.notPause
    cmp #6
    bne .switchDone
    lda #1
    sta mode
.switchDone
    lda INPT4
    and #$80
    sta tmp
    lda tmp
    cmp trigger
    beq .noPress
    sta trigger
    cmp #0
    bne .noPress
    lda #1
    sta pending
.noPress
    lda mode
    cmp #6
    bne .notPaused
    rts
.notPaused
    cmp #1
    beq Play
    cmp #2
    beq .transition
    cmp #3
    beq .transition
    lda pending
    beq .return
    jmp NewGame
.transition
    dec transition
    bne .return
    lda mode
    cmp #2
    bne .retry
    inc level
    lda level
    cmp #20
    bcc .retry
    lda #5
    sta mode
    rts
.retry
    lda lives
    bne .load
    lda #4
    sta mode
    rts
.load
    jsr StartLevel
.return
    rts

NewGame
    SUBROUTINE
    lda #0
    sta level
    sta scoreLo
    sta scoreHi
    sta scoreTop
    lda #3
    sta lives
    jsr StartLevel
    rts
StartLevel
    SUBROUTINE
    jmp ToLevel
LevelReturn
    SUBROUTINE
    rts

Play
    SUBROUTINE
    lda hitClock
    beq .hitDone
    dec hitClock
.hitDone
    lda invincible
    beq .move
    dec invincible
.move
    lda SWCHA
    and #$40
    bne .right
    lda manX
    cmp #18
    bcc .right
    dec manX
    lda frame
    and #3
    bne .leftSpeed
    dec manX
.leftSpeed
    lda #8
    sta facing
.right
    lda SWCHA
    and #$80
    bne .water
    lda manX
    cmp #132
    bcs .water
    inc manX
    lda frame
    and #3
    bne .rightSpeed
    inc manX
.rightSpeed
    lda #0
    sta facing
.water
    lda refill
    beq .cool
    dec refill
    bne .cool
    lda #8
    sta water
    lda #4
    jsr Sfx
.cool
    lda pose
    beq .cool2
    dec pose
    lda pose
    cmp #8
    bne .cool2
    jsr Launch
.cool2
    lda cooldown
    beq .press
    dec cooldown
.press
    lda pending
    beq .shots
    lda cooldown
    ora refill
    bne .shots
    lda water
    beq .shots
    lda #0
    sta pending
    lda #16
    sta cooldown
    lda #14
    sta pose
    dec water
    bne .shots
    lda #60
    sta refill
.shots
    jsr Projectiles
    lda mode
    cmp #1
    beq .continuePlay
    rts
.continuePlay
    dec secondClock
    bne .growth
    lda #60
    sta secondClock
    sed
    lda seconds
    sec
    sbc #1
    sta seconds
    cld
    bne .growth
    jmp LoseLife
.growth
    dec growClock
    bne .waves
    lda growPeriod
    sta growClock
    ldx #11
.grow
    lda fireHeat,x
    beq .gnext
    bmi .gnext
    inc fireHeat,x
    lda fireHeat,x
    cmp #128
    bcc .gnext
    dec fireHeat,x             ; retain stage 4 during collapse, not the resident flag
    jmp LoseLife
.gnext
    dex
    bpl .grow
.waves
    jsr CountFires
    lda waves
    bne .pendingWaves
    jmp .doneCheck
.pendingWaves
    lda count
    beq .spawn
    lda waveClock
    beq .spawn
    dec waveClock
    jmp .debris
.spawn
    lda level
    lsr
    lsr
    lsr
    clc
    adc #6
    cmp count
    bcc .spawnBlocked
    bne .spawnRoom
.spawnBlocked
    jmp .debris
.spawnRoom
    ; Alternate a random outbreak with a threat across the street.
    lda waves
    and #1
    beq .randomSpawn
    lda random
    and #3
    tax
    lda manX
    cmp #80
    bcc .farRight
    lda FarLeft,x
    jmp .pickWindow
.farRight
    lda FarRight,x
    jmp .pickWindow
.randomSpawn
    lda random
    and #15
    cmp #12
    bcc .randomReady
    sbc #12
.randomReady
.pickWindow
    tax
    ldy #12
.find
    sty tmp
    lda fireHeat,x
    bne .skipCandidate
    ; Do not re-block the shot path to an already urgent upper-floor fire.
    ; Existing lower fires still intercept: the player must clear that path.
    txa
    sec
    sbc #3
    bmi .ignite
    tay
.above
    lda fireHeat,y
    cmp #65
    bcc .aboveNext
    cmp #128
    bcc .skipCandidate
.aboveNext
    tya
    sec
    sbc #3
    bmi .ignite
    tay
    bpl .above
.skipCandidate
    ldy tmp
    inx
    cpx #12
    bcc .findWrap
    ldx #0
.findWrap
    dey
    bne .find
    jmp .debris
.ignite
    lda level
    cmp #10
    bcc .smallOutbreak
    lda waves
    and #3
    bne .smallOutbreak
    lda #33
    bne .newHeat
.smallOutbreak
    lda #17
.newHeat
    sta fireHeat,x
    dec waves
    lda wavePeriod
    sta waveClock
    jmp .debris
.doneCheck
    lda count
    bne .debris
    lda seconds
    and #15
    asl
    asl
    asl
    asl
    jsr AddPoints
    lda seconds
    lsr
    lsr
    lsr
    lsr
    sed
    clc
    adc scoreHi
    sta scoreHi
    lda scoreTop
    adc #0
    sta scoreTop
    cld
    lda #2
    sta mode
    lda #120
    sta transition
    lda #6
    jsr Sfx
    rts
.debris
    jsr Bricks
.return
    rts

CountFires
    SUBROUTINE
    lda #0
    sta count
    sta warn
    ldx #11
.loop
    lda fireHeat,x
    beq .next
    cmp #$80
    beq .next
    inc count
    cmp #128
    bcs .next
    cmp #97
    bcc .next
    inc warn
.next
    dex
    bpl .loop
    rts

Launch
    SUBROUTINE
    ldx #3
.slot
    lda shotY,x
    beq .found
    dex
    bpl .slot
    rts
.found
    lda manX
    clc
    adc #5
    sta shotX,x
    lda #150
    sta shotY,x
    lda #1
    jsr Sfx
    rts

Projectiles
    SUBROUTINE
    ldx #3
.loop
    stx tmp2
    lda shotY,x
    bne .activeShot
    jmp .next
.activeShot
    sec
    sbc #2
    sta shotY,x
    cmp #32
    bcs .wind
    lda #0
    sta shotY,x
    sta combo
    jmp .next
.wind
    lda frame
    and #7
    bne .collision
    lda wind
    beq .collision
    cmp #2
    bne .drift
    lda frame
    and #$80
    beq .east
    lda #$FF
    bne .drift
.east
    lda #1
.drift
    clc
    adc shotX,x
    sta shotX,x
.collision
    lda shotY,x
    tay
    lda HitRow,y
    bmi .next
    sta tmp
    lda shotX,x
    tay
    lda HitColumn,y
    bmi .next
    clc
    adc tmp
    tay
    lda fireHeat,y
    beq .next
    cmp #$80
    beq .next
    lda fireHeat,y
    bmi .rescue
    cmp #33
    bcc .out
    sec
    sbc #32
    and #$60
    ora #1
    sta fireHeat,y
    lda #$20
    jsr AddPoints
    lda #2
    jsr Sfx
    jmp .hit
.out
    lda #0
    sta fireHeat,y
    lda #$00
    jsr AddHundred
    lda combo
    cmp #9
    bcs .comboReady
    inc combo
.comboReady
    lda combo
    asl
    asl
    asl
    asl
    jsr AddPoints
    lda #3
    jsr Sfx
    jmp .hit
.rescue
    lda #0
    sta fireHeat,y
    lda #$50
    jsr AddHundred
    lda #0
    jsr AddHundred
    lda #5
    jsr Sfx
.hit
    sty hitWindow
    lda #12
    sta hitClock
    ldx tmp2
    lda #0
    sta shotY,x
    jmp .next
.next
    ldx tmp2
    dex
    bmi .done
    jmp .loop
.done
    rts

AddHundred
    SUBROUTINE
    sed
    clc
    adc scoreLo
    sta scoreLo
    lda scoreHi
    adc #1
    sta scoreHi
    lda scoreTop
    adc #0
    sta scoreTop
    cld
    rts
AddPoints
    SUBROUTINE
    sed
    clc
    adc scoreLo
    sta scoreLo
    lda scoreHi
    adc #0
    sta scoreHi
    lda scoreTop
    adc #0
    sta scoreTop
    cld
    rts

Bricks
    SUBROUTINE
    lda brickPeriod
    beq .done
    lda brickWarn
    beq .falling
    dec brickWarn
    bne .done
    lda #37
    sta brickY
    rts
.falling
    lda brickY
    beq .new
    clc
    adc #2
    sta brickY
    cmp #190
    bcc .hit
    lda #0
    sta brickY
    rts
.hit
    cmp #166
    bcc .done
    lda invincible
    bne .done
    lda brickX
    sec
    sbc manX
    clc
    adc #3
    cmp #11
    bcc .brickHit
    clc
    adc #32
    cmp #11
    bcc .brickHit
    clc
    adc #32
    cmp #11
    bcs .done
.brickHit
    jmp LoseLife
.new
    dec brickClock
    bne .done
    lda brickPeriod
    sta brickClock
    lda random
    and #$1F
    clc
    adc #24
    sta brickX
    lda #45
    sta brickWarn
.done
    rts

LoseLife
    SUBROUTINE
    lda #3
    sta mode
    lda #150
    sta transition
    dec lives
    lda #7
    jsr Sfx
    rts

Sfx
    SUBROUTINE
    sta sound
    lda #24
    sta soundClock
    rts
Audio
    SUBROUTINE
    lda mode
    cmp #6
    bne .audible
    jmp .silent
.audible
    lda soundClock
    beq .music
    dec soundClock
    ldx sound
    lda SoundControl,x
    sta AUDC0
    lda soundClock
    lsr
    clc
    adc SoundPitch,x
    and #31
    sta AUDF0
    lda soundClock
    lsr
    lsr
    sta AUDV0
    jmp .background
.music
    lda mode
    beq .tune
    cmp #5
    beq .tune
    lda #0
    sta AUDV0
    beq .background
.tune
    lda frame
    lsr
    lsr
    lsr
    and #31
    tax
    lda Tune,x
    sta AUDF0
    lda #4
    sta AUDC0
    lda frame
    and #7
    eor #7
    lsr
    sta AUDV0
.background
    lda mode
    cmp #1
    bne .quiet1
    lda brickWarn
    beq .fireAlarm
    and #4
    beq .quiet1
    lda #3
    sta AUDV1
    lda #4
    sta AUDC1
    lda #5
    sta AUDF1
    rts
.fireAlarm
    lda warn
    beq .crackle
    lda frame
    and #16
    lsr
    lsr
    clc
    adc #9
    sta AUDF1
    lda #4
    sta AUDC1
    lda #2
    sta AUDV1
    rts
.crackle
    lda #8
    sta AUDC1
    lda random
    and #31
    sta AUDF1
    lda frame
    and #7
    bne .quiet1
    lda #1
    sta AUDV1
    rts
.quiet1
    lda #0
    sta AUDV1
    rts
.silent
    lda #0
    sta AUDV0
    sta AUDV1
    rts

; Prepare score/status digits and projectile multiplexing during vertical blank.
Prepare
    SUBROUTINE
    lda #$FF
    sta wallColor
    lda mode
    cmp #3
    bne .roofReady
    lda transition
    cmp #105
    bcs .roofReady
    lda #0
    sta wallColor
.roofReady
    lda scoreTop
    ldx #0
    jsr SplitDigits
    lda scoreHi
    ldx #2
    jsr SplitDigits
    lda scoreLo
    ldx #4
    jsr SplitDigits
    lda levelBCD
    ldx #6
    jsr SplitDigits
    lda seconds
    ldx #8
    jsr SplitDigits
    lda lives
    ldx #10
    jsr SplitDigits
    lda frame
    lsr
    lsr
    lsr
    and #3
    sta anim
    ldx #11
.artPrep
    lda fireHeat,x
    beq .zeroArt
    cmp #$80
    bne .liveArt
    lda #28
    bne .zeroArt
.liveArt
    lda fireHeat,x
    bmi .residentArt
    sec
    sbc #1                     ; 1..32, 33..64, 65..96, 97..127
    lsr
    lsr
    lsr
    lsr
    lsr
    clc
    adc #1
    bne .artStage
.residentArt
    lda #5
.artStage
    asl
    asl
    sta tmp
    txa
    and #3
    eor anim
    ora tmp
.zeroArt
    sta artIndex,x
    dex
    bpl .artPrep
    lda hitClock
    beq .noSplash
    ldx hitWindow
    lsr
    lsr
    and #3
    clc
    adc #24
    sta artIndex,x
.noSplash
    lda water
    tax
    lda WaterBits,x
    sta waterMask
    lda refill
    beq .bands
    lsr
    lsr
    lsr
    tax
    lda WaterBits,x
    eor #$FF
    sta waterMask
.bands
    ldy #3
.band
    lda #0
    sta ballBandX,y
    lda #<BallMask
    sta ballBandLo,y
    ldx #3
.find
    lda shotY,x
    cmp BandTop,y
    bcc .nextShot
    cmp BandLimit,y
    bcs .nextShot
    lda shotX,x
    sta ballBandX,y
    lda BandBottom,y
    sec
    sbc shotY,x
    sta tmp
    lda #128
    sec
    sbc tmp
    sta ballBandLo,y
    jmp .bandDone
.nextShot
    dex
    bpl .find
.bandDone
    dey
    bpl .band
    ; Water-blue center beneath the expanding sprite droplets.
    lda hitClock
    beq .noWaterBurst
    ldx hitWindow
    lda WindowFloor,x
    tay
    lda TargetX,x
    sec
    sbc #3
    sta ballBandX,y
    lda #54
    sta ballBandLo,y
.noWaterBurst
    ; Character raster artwork pointer.
    lda #<ManColors
    sta colorPtr
    lda #>ManColors
    sta colorPtr+1
    lda #<Man0
    sta spritePtr
    lda #>Man0
    sta spritePtr+1
    lda pose
    beq .walk
    cmp #9
    bcc .throw
    lda #<ReachColors
    sta colorPtr
    lda #>ReachColors
    sta colorPtr+1
    lda #<Man2
    jmp .poseReady
.throw
    lda #<Man3
    bne .poseReady
.walk
    lda SWCHA
    and #$C0
    cmp #$C0
    beq .position
    lda frame
    lsr
    lsr
    lsr
    and #3
    tax
    lda WalkFrames,x
.poseReady
    sta spritePtr
.position
    ldx #10
.hudPointers
    txa
    lsr
    tay
    lda hud,y
    clc
    adc #<Digit0
    sta p0,x
    lda #>Digit0
    sta p0+1,x
    dex
    dex
    bpl .hudPointers
    lda #0
    sta REFP0
    sta REFP1
    sta VDELP0
    sta VDELP1
    sta GRP0
    sta GRP1
    sta ENABL
    sta ENAM1
    sta PF0
    sta PF1
    sta PF2
    sta COLUBK
    lda #6
    sta NUSIZ0
    sta NUSIZ1
    lda mode
    beq .titlePositions
    cmp #4
    beq .titlePositions
    cmp #5
    beq .titlePositions
    lda #32
    ldx #0
    jsr Position
    lda #40
    bne .secondPosition
.titlePositions
    lda #16
    ldx #0
    jsr Position
    lda #128
.secondPosition
    ldx #1
    jsr Position
    lda brickX
    ldx #3
    jsr Position
    sta WSYNC
    sta HMOVE
    rts

SplitDigits
    SUBROUTINE
    pha
    and #$F0
    lsr
    sta hud,x
    pla
    and #15
    asl
    asl
    asl
    sta hud+1,x
    rts

; Position A at X=0 player0 / 1 player1 / 4 ball. Standard divide-by-15.
Position
    SUBROUTINE
    sec
    sbc #3
    bcs .coordinate
    lda #0
.coordinate
    sta WSYNC
    sec
.posLoop
    sbc #15
    bcs .posLoop
    eor #7
    asl
    asl
    asl
    asl
    sta HMP0,x
    sta RESP0,x
    rts

FarLeft byte 0,3,6,9
FarRight byte 2,5,8,11
CollapseTime byte 105,80,55,30
WindowFloor byte 0,0,0,1,1,1,2,2,2,3,3,3
TargetX byte 48,80,112,48,80,112,48,80,112,48,80,112
TargetY byte 47,47,47,75,75,75,103,103,103,131,131,131
BandTop byte 38,66,94,122
BandBottom byte 57,85,113,141
BandLimit byte 64,92,120,148
    include "src/collisions.inc"
WaterBits byte $00,$80,$C0,$E0,$F0,$F8,$FC,$FE,$FF
SoundControl byte 0,4,8,4,12,4,4,8
SoundPitch byte 0,6,4,12,1,3,6,16
Tune byte 15,15,12,12,9,9,12,12,15,15,12,12,7,7,9,9,12,12,9,9,7,7,9,9,12,12,15,15,19,19,15,15
WalkFrames byte <Man0,<Man1,<Man4,<Man5
    echo "Logic bytes:",(*-$F000)
    ORG $0FB0
    GATES
    ORG $0FFA
    RORG $FFFA
    word ResetGate,ResetGate,ResetGate


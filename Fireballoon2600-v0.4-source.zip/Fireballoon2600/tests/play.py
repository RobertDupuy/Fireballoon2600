import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from emulator import Emulator,ROOT
from collections import Counter
TARGETY=[47]*3+[75]*3+[103]*3+[131]*3
TARGETX=[48,80,112]*4

def policy(e,frame):
 mode=e.get('mode')
 if mode==0:return [0] if frame%2==0 else []
 if mode!=1:return []
 heats=[0 if v==128 else v for v in e.get('fireHeat',12)];pos=e.get('manX');wind=e.get('wind');phase=e.get('frame')
 def wind_drift(x,y):
  travel=max(0,(150-y)//2+6)
  w=wind if wind!=255 else -1
  if w==2:
   return sum(1 if ((phase+k)&128)==0 else -1 for k in range(0,travel,8))
  return w*(travel//8)
 projected=heats[:]
 # Forecast hits by in-flight projectiles, nearest impacts first.
 for sx,sy in sorted(zip(e.get('shotX',4),e.get('shotY',4)),key=lambda a:a[1]):
  if not sy:continue
  for i in reversed(range(12)):
   if not projected[i] or sy<TARGETY[i]-1:continue
   delta=wind_drift(0,TARGETY[i])-wind_drift(0,sy)
   if abs(sx+delta-TARGETX[i])<=8:
    projected[i]=0 if projected[i]<33 or projected[i]>=128 else ((projected[i]-32)&96)|1
    break
 # Preserve aim during pickup (release is six frames after the tap).
 by=e.get('brickY');bx=e.get('brickX')
 if by>=126:
  # Commit to a safe gap. Reversing away from the nearest piece each frame
  # causes an artificial oscillation when decisions are deliberately slower.
  safe=[bx+d for d in (-16,16,48,80) if 18<=bx+d<=132]
  target=min(safe,key=lambda x:abs(x-pos))
  return [] if abs(target-pos)<=3 else [6 if pos>target else 7]
 if e.get('pose')>8:return []
 choices=[]
 for col in (0,1,2):
  indices=[i for i in range(col,12,3) if projected[i]]
  if not indices:continue
  target=max(indices)
  aim=TARGETX[target]-5-wind_drift(0,TARGETY[target])
  urgency=max((projected[i] if projected[i]<128 else 15) for i in indices)
  # A switch costs a second. Work through a column until the other needs help.
  value=urgency*2 +len(indices)*10 - abs(pos-aim)*.7
  choices.append((value,target,aim))
 if not choices:return []
 _,target,aim=max(choices)
 aim=max(18,min(132,aim))
 diff=aim-pos
 buttons=[]
 if abs(diff)>2:buttons.append(7 if diff>0 else 6)
 if abs(diff)<=3 and not e.get('cooldown') and e.get('water') and not e.get('refill') and e.get('trigger'):
  buttons.append(0)
 return buttons

def campaign(limit=150000):
 e=Emulator();trace=[];events=[];old=None;stats=Counter();e.step(n=20)
 for f in range(limit):
  buttons=policy(e,f);trace.append(sum(1<<b for b in buttons));e.step(buttons)
  key=(e.get('mode'),e.get('level'),e.get('lives'))
  if key!=old:
   events.append({'frame':f,'mode':key[0],'level':key[1]+1,'lives':key[2],'seconds':e.get('seconds'),'heat':e.get('fireHeat',12)})
   print(events[-1],flush=True);old=key
  if f>10:stats[e.lines[-1]]+=1
  if key[0] in (4,5):break
 out={'sha256':hashlib.sha256((ROOT/'build/Fireballoon2600-NTSC.bin').read_bytes()).hexdigest(),'frames':len(trace),'events':events,'scanlines':dict(stats),'won':e.get('mode')==5,'memory_writes':0}
 (ROOT/'build/campaign.json').write_text(json.dumps(out,indent=2));(ROOT/'build/inputs.json').write_text(json.dumps(trace))
 e.save(ROOT/'build/campaign-last.png');e.close();return out
if __name__=='__main__':campaign()

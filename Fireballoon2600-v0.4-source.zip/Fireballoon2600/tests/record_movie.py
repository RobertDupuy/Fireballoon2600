"""Record authentic Stella output and native audio from the saved input replay."""
import ctypes as C
import json,hashlib
from collections import Counter
from pathlib import Path
import subprocess
import sys
import wave
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from emulator import Emulator

OUT = ROOT / 'build/movie-v04'
OUT.mkdir(parents=True, exist_ok=True)
FINAL = ROOT.parent / 'deliverables/Fireballoon2600-v0.4-with-sound.mp4'
FINAL.parent.mkdir(parents=True, exist_ok=True)
trace = json.loads((ROOT / 'build/inputs.json').read_text())

class Geometry(C.Structure):
    _fields_ = [('base_width', C.c_uint), ('base_height', C.c_uint),
                ('max_width', C.c_uint), ('max_height', C.c_uint), ('aspect_ratio', C.c_float)]
class Timing(C.Structure):
    _fields_ = [('fps', C.c_double), ('sample_rate', C.c_double)]
class AVInfo(C.Structure):
    _fields_ = [('geometry', Geometry), ('timing', Timing)]

e = Emulator()
e.step(n=20)
av = AVInfo()
e.core.retro_get_system_av_info(C.byref(av))
fps = float(av.timing.fps)
rate = round(av.timing.sample_rate)
print({'fps': fps, 'sample_rate': rate, 'raster': list(e.image.shape)}, flush=True)
records = []

class Clip:
    def __init__(self, name):
        self.name = name
        self.frames = 0
        self.heights = set()
        e.samples.clear()
        e.capture_audio = True
        self.log = (OUT / (name + '-encode.log')).open('wb')
        h, w, _ = e.image.shape
        self.proc = subprocess.Popen([
            'ffmpeg', '-hide_banner', '-loglevel', 'warning', '-y',
            '-f', 'rawvideo', '-pixel_format', 'rgb24', '-video_size', f'{w}x{h}',
            '-framerate', str(fps), '-i', 'pipe:0',
            '-vf', 'scale=960:684:flags=neighbor,pad=960:720:0:18,setsar=1',
            '-an', '-c:v', 'libx264', '-preset', 'fast', '-crf', '18',
            '-pix_fmt', 'yuv420p', str(OUT / (name + '-video.mp4'))
        ], stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=self.log)
    def frame(self):
        self.proc.stdin.write(e.image.tobytes())
        self.frames += 1
        self.heights.add(e.lines[-1])
        if self.frames == 180:
            Image.fromarray(e.image).resize((640,456), Image.Resampling.NEAREST).save(OUT / (self.name + '.png'))
    def close(self):
        self.proc.stdin.close()
        assert self.proc.wait() == 0
        self.log.close()
        e.capture_audio = False
        samples = np.concatenate(e.samples, axis=0)
        e.samples.clear()
        duration = self.frames / fps
        assert abs(len(samples) / rate - duration) < 0.025, (self.name, len(samples), duration)
        with wave.open(str(OUT / (self.name + '.wav')), 'wb') as wav:
            wav.setnchannels(2)
            wav.setsampwidth(2)
            wav.setframerate(rate)
            wav.writeframes(samples.astype('<i2', copy=False).tobytes())
        # Matroska keeps PCM exact across the later cuts; AAC is encoded once at the end.
        subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
            '-i', str(OUT / (self.name + '-video.mp4')),
            '-i', str(OUT / (self.name + '.wav')),
            '-c:v', 'copy', '-c:a', 'pcm_s16le', '-t', str(duration),
            str(OUT / (self.name + '.mkv'))], check=True)
        info = {'name': self.name, 'frames': self.frames, 'seconds': duration,
            'audio_samples': len(samples), 'sample_rate': rate,
            'audio_peak': int(np.abs(samples.astype(np.int32)).max()),
            'audio_rms': float(np.sqrt(np.mean(samples.astype(np.float64)**2))),
            'scanlines': sorted(self.heights)}
        records.append(info)
        print(info, flush=True)

campaign=json.loads((ROOT/'build/campaign.json').read_text())
start=lambda level: next(v['frame'] for v in campaign['events'] if v['level']==level and v['mode']==1)
clear1=next(v['frame'] for v in campaign['events'] if v['level']==1 and v['mode']==2)
ranges=[(0,clear1+60,'first-call'),(start(2),start(2)+720,'courtyard'),
        (start(3),start(3)+720,'high-street'),(start(4),start(4)+720,'twin-terraces'),
        (start(20),len(trace),'final-call')]
starts={a:(b,name) for a,b,name in ranges}
clip=None;clip_end=0;lines=Counter();best=-1;best_frame=None;best_state=None
street_best={}
for frame,bits in enumerate(trace):
    if clip and frame==clip_end:
        clip.close();clip=None
    if frame in starts:
        clip_end,name=starts[frame];clip=Clip(name)
    e.step([b for b in range(16) if bits&(1<<b)])
    if frame>10:lines[e.lines[-1]]+=1
    if clip:clip.frame()
    if e.get('mode')==1 and e.get('level')<4:
        key=e.get('level');h=e.get('fireHeat',12)
        q=sum(v for v in h if v<128)+60*sum(0<v<128 for v in h)
        if q>street_best.get(key,(-1,None))[0]:street_best[key]=(q,e.image.copy())
    if e.get('mode')==1 and e.get('level')>=10:
        heats=e.get('fireHeat',12)
        heat=sum(v for v in heats if v<128)
        n=sum(0<v<128 for v in heats)
        people=sum(v>=224 for v in heats)
        quality=heat+n*60+people*45+(20 if 60<e.get('brickY')<140 else 0)
        if quality>best:
            best=quality;best_frame=e.image.copy()
            best_state={'frame':frame,'level':e.get('level')+1,'heat':heats,'shotY':e.get('shotY',4),'brickY':e.get('brickY')}
    if frame%6000==0:print({'replay_frame':frame,'call':e.get('level')+1},flush=True)
assert e.get('mode')==5,'Input-only replay must reach victory.'
assert set(lines)=={262},lines
if clip:clip.close()
report={'sha256':hashlib.sha256((ROOT/'build/Fireballoon2600-NTSC.bin').read_bytes()).hexdigest(),
    'frames':len(trace),'memory_writes':0,'won':True,'scanlines':dict(lines),
    'ending_lives':e.get('lives'),'screenshot':best_state}
(ROOT/'build/replay.json').write_text(json.dumps(report,indent=2))
Image.fromarray(best_frame).resize((640,456),Image.Resampling.NEAREST).save(ROOT/'build/gameplay.png')
e.save(ROOT/'build/ending.png')
clip = Clip('victory')
for _ in range(180):
    e.step()
    clip.frame()
clip.close()

e.core.retro_reset()
e.step(n=20)
assert e.get('mode') == 0
clip = Clip('title')
for _ in range(180):
    e.step()
    clip.frame()
clip.close()
e.save(ROOT/'build/title.png')
e.close()
sheet=Image.new('RGB',(1280,912),'black')
for index in range(4):
    picture=Image.fromarray(street_best[index][1]).resize((640,456),Image.Resampling.NEAREST)
    sheet.paste(picture,((index%2)*640,(index//2)*456))
sheet.save(ROOT/'build/Fireballoon2600-preview.png')

names = ['title', 'first-call', 'courtyard', 'high-street', 'twin-terraces', 'final-call', 'victory']
listing = OUT / 'clips.txt'
listing.write_text(''.join("file '" + str(OUT / (name + '.mkv')) + "'\n" for name in names))
subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'warning', '-y',
    '-f', 'concat', '-safe', '0', '-i', str(listing), '-map', '0:v:0', '-map', '0:a:0',
    '-c:v', 'copy', '-c:a', 'aac', '-b:a', '160k', '-ar', '48000',
    '-movflags', '+faststart', str(FINAL)], check=True)
(OUT / 'capture.json').write_text(json.dumps({'fps': fps, 'memory_writes': 0,
    'playback_speed': 1, 'replay': report, 'source_ranges': ranges, 'clips': records, 'output': str(FINAL)}, indent=2))
print({'complete': str(FINAL), 'bytes': FINAL.stat().st_size}, flush=True)

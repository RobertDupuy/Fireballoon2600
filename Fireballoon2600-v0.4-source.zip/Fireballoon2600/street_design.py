"""Shared authoring data; no runtime dependency or cartridge RAM."""
STREETS = [
    dict(name='Central apartments', bank=1, heights=(3,4,3), hue=0x80),
    dict(name='Courtyard', bank=4, heights=(4,2,4), hue=0x20),
    dict(name='High street', bank=5, heights=(2,4,2), hue=0x90),
    dict(name='Twin terraces', bank=6, heights=(4,3,4), hue=0x40),
]

def present(street, index):
    return index//3 >= 4-street['heights'][index%3]

def playfield(street, floor, solid=False):
    """Symmetric three-building silhouettes, with black alleys and apertures."""
    outer = floor >= 4-street['heights'][0]
    middle = floor >= 4-street['heights'][1]
    return ((0x0f if solid else 0x0c) if outer else 0,
            ((0x0f if solid else 0x0c) if outer else 0) |
            ((0xe0 if solid else 0x20) if middle else 0))

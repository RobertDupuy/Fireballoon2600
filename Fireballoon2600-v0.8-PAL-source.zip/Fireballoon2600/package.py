"""Package the verified PAL release."""
from package_pal import package
if __name__ == '__main__':
    package()

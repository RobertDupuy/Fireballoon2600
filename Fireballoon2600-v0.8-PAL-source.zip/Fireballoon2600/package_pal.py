"""Save a matched PAL cartridge, editable source and verification evidence."""
from pathlib import Path
import hashlib, json, shutil, zipfile

ROOT = Path(__file__).resolve().parent

def package():
    build = ROOT/'build'
    dest = ROOT.parent/'deliverables'
    dest.mkdir(exist_ok=True)
    config = json.loads((build/'config.json').read_text())
    assert config['tv'] == 'pal'
    data = (build/config['rom']).read_bytes()
    sha = hashlib.sha256(data).hexdigest()
    assert len(data) == 32768
    for bank in range(8):
        assert data[bank*4096+4090:bank*4096+4096] == data[4090:4096]
    reports = {name: json.loads((build/name).read_text()) for name in
               ('campaign.json','replay.json','pal-verification.json')}
    for report in reports.values():
        assert report['sha256'] == sha
        assert set(report['scanlines']) == {'312'}
    assert reports['campaign.json']['won'] and reports['replay.json']['won']
    assert reports['campaign.json']['memory_writes'] == reports['replay.json']['memory_writes'] == 0
    assert all(c['passed'] for c in reports['pal-verification.json']['checks'])
    checks = reports['pal-verification.json']
    summary = dict(title='Fireballoon 2600', creator='Mark2006', version='0.8 PAL',
        tv='PAL50', scanlines=312, nominal_video_hz=50, nominal_logic_hz=60,
        mapper='F4', rom_bytes=len(data), sha256=sha, ram_bytes=119,
        stack_reserved_bytes=9, calls_completed=20,
        campaign_frames=reports['campaign.json']['frames'],
        ending_lives=reports['replay.json']['ending_lives'],
        independent_input_replay=True, campaign_replay_memory_writes=0,
        blanket_catches=sum(x['event']=='jump_caught' for x in reports['campaign.json']['mechanic_events']),
        fixture_checks=len(checks['checks']), fixture_memory_writes=True,
        foreground_frames=checks['foreground_frames'],
        resident_delay_pal_frames=320, refill_pal_frames=50, inferno_pal_frames=75,
        emulator='Stella 7.0_pre/libretro',
        emulator_commit='ba52c43b9eda950eb0c0eec69cda9b17dee8c39b',
        ntsc_build_identical_to_original=True,
        ntsc_sha256='063e6930ef85fb77369a9aa15dcccbfa24335e4afbfb02825ce14ee3d27e3d80',
        physical_hardware_tested=False)
    validation=ROOT/'validation'
    validation.mkdir(exist_ok=True)
    for name in (*reports, 'inputs.json'):
        shutil.copy2(build/name, validation/name)
    (validation/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    name='Fireballoon2600-v0.8-PAL.bin'
    (dest/name).write_bytes(data)
    (ROOT/name).write_bytes(data)
    sources=sorted(ROOT.glob('*.py'))+[ROOT/'README.md', ROOT/'design.json', ROOT/name]
    sources+=sorted((ROOT/'src').glob('*'))+sorted((ROOT/'tests').glob('*.py'))
    sources+=[ROOT/'tests/stella-observation.patch']+sorted(validation.glob('*.json'))
    sources+=[build/n for n in ('config.json','Fireballoon2600-PAL.bin',
        'Fireballoon2600.sym','Fireballoon2600.lst','inputs.json','campaign.json')]
    archive=dest/'Fireballoon2600-v0.8-PAL-source.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for path in sources:
            assert path.is_file(),path
            z.write(path, Path('Fireballoon2600')/path.relative_to(ROOT))
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
    print(json.dumps(summary,indent=2))
    print(archive)

if __name__ == '__main__':
    package()

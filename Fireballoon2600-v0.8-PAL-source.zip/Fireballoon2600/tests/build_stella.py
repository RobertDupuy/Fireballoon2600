"""Build the pinned open-source emulator used for the supplied validation."""
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[1]
path=ROOT/'.test-tools/stella'
commit='ba52c43b9eda950eb0c0eec69cda9b17dee8c39b'
if not path.exists():
 path.parent.mkdir(exist_ok=True)
 subprocess.run(['git','clone','https://github.com/libretro/stella2023.git',str(path)],check=True)
 subprocess.run(['git','checkout',commit],cwd=path,check=True)
p=path/'src/os/libretro/libretro.cxx'
s=p.read_text()
if 'retro_ff_trace_start' not in s:
 patch=ROOT/'tests/stella-observation.patch'
 subprocess.run(['git','apply','--check',str(patch)],cwd=path,check=True)
 subprocess.run(['git','apply',str(patch)],cwd=path,check=True)
subprocess.run(['make','-j4'],cwd=path/'src/os/libretro',check=True)
print('Emulator ready:',path/'src/os/libretro')

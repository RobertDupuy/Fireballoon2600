"""Mechanics, raster and native-image checks. These isolated fixtures write RAM.

The separate campaign/replay/movie programs never write game state.
"""
import ctypes as C
import hashlib,json,sys
from pathlib import Path
from collections import defaultdict,Counter
import numpy as np
sys.path.insert(0,str(Path(__file__).parent))
from emulator import Emulator,ROOT

e=Emulator();checks=[]
def check(name,value,detail=None):
 checks.append({'test':name,'pass':bool(value),'detail':detail})
 print(name, 'PASS' if value else 'FAIL',detail if detail is not None else '',flush=True)
 assert value,name
def fresh():
 e.core.retro_reset();e.step(n=30);e.step([0]);e.step(n=10)
def put(name,vals):
 for i,v in enumerate(vals):e.ram[e.symbols[name]-128+i]=v
def fixture(heats=None):
 e.set('residentQuota',0);e.set('growClock',250);e.set('waveClock',250);e.set('waves',1)
 e.set('brickPeriod',0);e.set('brickY',0);e.set('brickWarn',0)
 if heats is not None:put('fireHeat',heats)

fresh();fixture();e.step([0],n=60)
check('Held FIRE consumes exactly one balloon',e.get('water')==7)
e.step();e.step([0]);e.step(n=18)
check('Release/repress throws again',e.get('water')==6)
fresh();fixture();e.set('cooldown',5);e.step([0]);e.step(n=5)
check('A quick tap during recovery is buffered once',e.get('water')==7 and e.get('pending')==0)
e.step(n=30);check('Buffered input does not repeat',e.get('water')==7)

fresh();fixture();e.set('manX',18)
for k in range(8):
 e.step([0])
 if k<7:e.step(n=19)
check('Eight taps empty the bucket',e.get('water')==0 and e.get('refill')==60)
x=e.get('manX');e.step([7],n=10)
check('Movement remains responsive while refilling',12<=e.get('manX')-x<=13)
e.step([5],n=49)
check('DOWN does not accelerate the 60-frame refill',e.get('water')==0 and e.get('refill')==1)
e.step();check('Automatic refill completes on frame 60',e.get('water')==8 and e.get('refill')==0)

fresh();fixture();e.set('water',0);e.set('refill',40);e.step([2]);e.step()
before=[e.get(n) for n in ['refill','seconds','secondClock']]+e.get('fireHeat',12)
e.step(n=40);e.save(ROOT/'build/qa-pause.png')
check('SELECT pauses timers, fires and refill',e.get('mode')==6 and before==[e.get(n) for n in ['refill','seconds','secondClock']]+e.get('fireHeat',12))
e.step([2]);e.step();check('SELECT resumes the same call',e.get('mode')==1 and e.get('refill')<40)

fresh();fixture([0]*9+[224,0,0]);e.step()
check('A resident is not a critical fire',e.get('warn')==0)
e.set('manX',43);e.step([0]);e.step(n=22)
check('A balloon rescues a resident',e.get('fireHeat',12)[9]==0)
check('A rescue awards 250 points',e.get('scoreHi')==2 and e.get('scoreLo')==0x50)
fresh();fixture([0]*9+[104,0,0]);e.set('manX',43);e.step([0]);e.step(n=22)
check('A hit removes one stage and resets its growth age',e.get('fireHeat',12)[9]==65)
check('Weakening awards 20 points',e.get('scoreLo')==0x20)
fresh();fixture([0,0,0,0,0,0,1,0,0,1,0,0]);e.set('manX',43);e.step([0]);e.step(n=48)
check('Lower windows intercept shots to upper windows',e.get('fireHeat',12)[9]==0 and e.get('fireHeat',12)[6]==1)
check('Extinguishing starts the score streak',e.get('combo')==1 and e.get('scoreHi')==1 and e.get('scoreLo')==0x10)

fresh();fixture([127]*12);e.set('growClock',1);e.step(n=2)
check('Simultaneous critical fires cost one life',e.get('mode')==3 and e.get('lives')==2)
check('Critical fires remain fires throughout collapse',e.get('fireHeat',12)==[127]*12)
e.step(n=160);e.save(ROOT/'build/qa-collapse.png')
check('The burned building loses its upper floors',np.count_nonzero(e.image[60:75,100:124])<50)
e.step(n=80);check('Collapse retries the same call',e.get('mode')==1 and e.get('level')==0 and e.get('lives')==2)
fresh();fixture();e.set('seconds',1);e.set('secondClock',1);e.step(n=2)
check('Timeout costs one life',e.get('mode')==3 and e.get('lives')==2)
fresh();fixture();e.set('brickPeriod',100);e.set('brickClock',1);e.step()
check('Masonry gives a 45-frame warning',e.get('brickWarn')==45 and e.get('brickY')==0)
e.step(n=44);check('The warning precedes falling masonry',e.get('brickWarn')==1 and e.get('brickY')==0)
e.step();check('Masonry releases after the warning',e.get('brickY')==37)
for offset in (0,32,64):
 fresh();fixture();e.set('brickPeriod',100);e.set('brickX',32);e.set('brickY',164);e.set('manX',32+offset);e.set('invincible',0);e.step()
 check(f'Masonry copy at +{offset} has a matching hitbox',e.get('mode')==3 and e.get('lives')==2)
fresh();fixture();e.set('brickPeriod',100);e.set('brickX',32);e.set('brickY',164);e.set('manX',48);e.set('invincible',0);e.step()
check('The gap between falling pieces is safe',e.get('mode')==1)

fresh();e.step(n=3400);check('Idle play reaches game over',e.get('mode')==4 and e.get('lives')==0)
e.save(ROOT/'build/qa-game-over.png');e.step([0]);e.step()
check('FIRE restarts from game over',e.get('mode')==1 and e.get('lives')==3 and e.get('level')==0)

# Worst-case branch combinations, not a collection of tests mirroring assembly.
timing=Counter()
for wind in (0,1,255,2):
 for by in (0,38,65,94,122,149,158,170):
  fresh();fixture([32,33,64,65,96,97,127,224,1,33,65,97])
  e.set('wind',wind);e.set('brickPeriod',100);e.set('brickY',by);e.set('brickX',42)
  put('shotX',[48,80,112,48]);put('shotY',[52,80,108,136])
  e.set('growClock',1);e.set('secondClock',1);e.step(n=3)
  timing.update(e.lines[-3:])
check('Worst-case game and draw paths retain 262 scanlines',set(timing)=={262},dict(timing))
for start in range(12):
 fresh();fixture([65,65,65]+[0]*9)
 e.set('random',start);e.set('waveClock',0);e.set('waves',2)
 e.set('growClock',1);e.set('secondClock',1)
 put('shotX',[18]*4);put('shotY',[52,80,108,136]);e.step()
 timing[e.lines[-1]]+=1
 check(f'Outbreak search {start} cannot re-block urgent upper fires',e.get('fireHeat',12)[3:]==[0]*9)
check('Exhausted outbreak searches retain 262 scanlines',set(timing)=={262},dict(timing))
fresh();e.ram[118]=0xa5;e.ram[119]=0x5a;e.step(n=1000)
check('The stack does not collide with allocated game RAM',list(e.ram[118:120])==[0xa5,0x5a])

# Verify the actual TIA writes, including the no-WSYNC scanline loop.
if hasattr(e.core,'retro_ff_trace_start'):
 fresh();fixture([1,33,65,97,224,1,33,65,97,224,1,33]);e.step()
 e.core.retro_ff_trace_start();e.step()
 e.core.retro_ff_trace_size.restype=C.c_uint
 e.core.retro_ff_trace_data.restype=C.POINTER(C.c_uint32)
 n=e.core.retro_ff_trace_size()
 tr=np.ctypeslib.as_array(e.core.retro_ff_trace_data(),shape=(n,)).copy().reshape(-1,10)
 scan=defaultdict(list)
 for f,line,cc,reg,value,pc,p0,p1,ball,cycles in tr:
  if reg in (0x1b,0x1c):scan[int(line)].append((int(cc)//3,int(reg)))
 schedules=[];rowlines=[]
 for line,writes in scan.items():
  if writes[:6] in [[(10,27),(18,28),(39,27),(47,28),(55,27),(58,28)],[(12,27),(20,28),(39,27),(47,28),(55,27),(58,28)]]:
   rowlines.append(line);schedules.append(writes[:6])
 check('All 64 window scanlines meet their six sprite-write deadlines',len(rowlines)==64,len(rowlines))
 check('Four 16-line bands are exactly 28 scanlines apart',rowlines[::16]==[rowlines[0]+28*i for i in range(4)],rowlines[::16])
 check('Playfield score mode stays disabled during the facade',not any(int(r[4])&2 for r in tr if r[3]==10 and rowlines[0]<=r[1]<=rowlines[-1]))
 rom=(ROOT/'build/Fireballoon2600-NTSC.bin').read_bytes();mismatch=0
 for i,art in enumerate(e.get('artIndex',12)):
  stage,phase=divmod(art,4);halves=[]
  for half in (0,1):
   address=4096+e.symbols[f'Art{stage}_{phase}_{half}']-0xf000
   halves.append(list(reversed(rom[address:address+16])))
  expected=np.array([[(halves[x//8][y]>>(7-x%8))&1 for x in range(16)] for y in range(16)])
  xx=40+(i%3)*32;yy=rowlines[(i//3)*16]-23
  actual=e.image[yy:yy+16,xx:xx+16].any(axis=2)
  mismatch+=int(np.count_nonzero(expected!=actual))
 check('All twelve native window images match their ROM sprite bytes',mismatch==0,mismatch)
 (ROOT/'build/beam-check.json').write_text(json.dumps({'rom_sha256':hashlib.sha256((ROOT/'build/Fireballoon2600-NTSC.bin').read_bytes()).hexdigest(),'window_rows':len(rowlines),'band_start_scanlines':rowlines[::16],'write_schedules':list({str(x) for x in schedules}),'fixture_memory_writes':True},indent=2))

e.core.retro_reset();e.step(n=60)
expected=np.array(json.loads((ROOT/'src/title_frames.json').read_text())[0]['bits'])
bg=e.image[40,0];best=expected.size
for y in range(35,65):
 for x in range(52,59):
  mask=(e.image[y:y+120,x:x+48]!=bg).any(axis=2)
  best=min(best,int(np.count_nonzero(mask!=expected)))
check('Native title output matches all 5,760 authored pixels',best==0,best)
e.capture_audio=True;e.step(n=120)
samples=np.concatenate(e.samples)
check('Native TIA audio is present',int(np.abs(samples.astype(np.int32)).max())>1000)
e.close()
(ROOT/'build/verification.json').write_text(json.dumps({'rom_sha256':hashlib.sha256((ROOT/'build/Fireballoon2600-NTSC.bin').read_bytes()).hexdigest(),'fixture_memory_writes':True,'checks':checks},indent=2))

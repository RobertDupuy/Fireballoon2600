"""Replay saved input only: no planner and no game-state writes."""
from pathlib import Path
import json,hashlib,sys
from collections import Counter
import numpy as np
from PIL import Image
sys.path.insert(0,str(Path(__file__).parent))
from emulator import Emulator,ROOT,ROM,SCANLINES,FPS
trace=json.loads((ROOT/'build/inputs.json').read_text())
e=Emulator();e.step(n=20);lines=Counter();best=-1;best_frame=None;best_state=None
for f,bits in enumerate(trace):
 e.step([b for b in range(16) if bits&(1<<b)])
 if f>10:lines[e.lines[-1]]+=1
 if e.get('mode')==1 and e.get('level')>=10:
  heats=e.get('fireHeat',12);heat=sum(v for v in heats if v<128);n=sum(0<v<128 for v in heats)
  # Choose a real, dense late-call frame for the screenshot, with no fixture edits.
  quality=heat+n*60+ (25 if 60<e.get('brickY')<140 else 0)
  if quality>best:
   best=quality;best_frame=e.image.copy();best_state={'frame':f,'level':e.get('level')+1,'heat':heats,'shotY':e.get('shotY',4),'brickY':e.get('brickY')}
assert e.get('mode')==5,'replay did not win'
assert set(lines)=={SCANLINES},lines
out={'sha256':hashlib.sha256(ROM.read_bytes()).hexdigest(),'frames':len(trace),'memory_writes':0,'won':True,'scanlines':dict(lines),'ending_lives':e.get('lives'),'screenshot':best_state}
(ROOT/'build/replay.json').write_text(json.dumps(out,indent=2))
Image.fromarray(best_frame).resize((640,best_frame.shape[0]*2),Image.Resampling.NEAREST).save(ROOT/'build/gameplay.png')
e.save(ROOT/'build/ending.png');e.core.retro_reset();e.step(n=170);e.save(ROOT/'build/title.png')
# Contact sheet consists exclusively of real TIA output, no painted-over gameplay.
a=Image.open(ROOT/'build/title.png');b=Image.open(ROOT/'build/gameplay.png');sheet=Image.new('RGB',(1280,max(a.height,b.height)),'black');sheet.paste(a,(0,0));sheet.paste(b,(640,0));sheet.save(ROOT/'build/Fireballoon2600-preview.png')
e.close();print(json.dumps(out,indent=2))

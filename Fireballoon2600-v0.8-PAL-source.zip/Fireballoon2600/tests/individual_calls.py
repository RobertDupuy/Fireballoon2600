"""Isolated winnability fixtures. Only the setup changes RAM; play uses inputs."""
from emulator import Emulator, ROOT
from expert_player import policy
import json,sys,hashlib
from collections import Counter
e=Emulator();rows=[];lines=Counter()
first=int(sys.argv[1]) if len(sys.argv)>1 else 0
last=int(sys.argv[2]) if len(sys.argv)>2 else 20
for call in range(first,last):
    success=False
    for attempt in range(3):
        e.core.retro_reset();e.step(n=20+17*attempt);e.step([0]);e.step()
        if call:
            e.set('mode',2);e.set('level',call-1);e.set('transition',1);e.step()
        fired=0;old=e.get('water')
        for f in range(5000):
            e.step(policy(e,f));lines[e.lines[-1]]+=1
            water=e.get('water')
            if water<old:fired+=1
            old=water
            if e.get('mode')!=1:break
        row=dict(call=call+1,attempt=attempt+1,won=e.get('mode')==2,frames=f+1,
                 seconds_bcd=e.get('seconds'),launches=fired,waves_left=e.get('waves'),
                 remaining_heat=e.get('fireHeat',12))
        rows.append(row);print(row,flush=True)
        if row['won']:success=True;break
out=dict(rom_sha256=hashlib.sha256((ROOT/'build/Fireballoon2600-NTSC.bin').read_bytes()).hexdigest(),
         fixture_memory_writes=True,gameplay_memory_writes=0,results=rows,scanlines=dict(lines))
(ROOT/f'build/individual-{first}-{last}.json').write_text(json.dumps(out,indent=2))
e.close()

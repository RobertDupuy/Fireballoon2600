import sys,json,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
from emulator import Emulator,ROOT,ROM,SCANLINES,FPS
from collections import Counter
TARGETY=[47]*3+[75]*3+[103]*3+[131]*3
TARGETX=[48,80,112]*4

def policy(e,frame):
 from expert_player import policy as expert
 return expert(e,frame)

def campaign(limit=150000):
 e=Emulator();trace=[];events=[];old=None;stats=Counter();mechanics=[];previous=None;e.step(n=20)
 for f in range(limit):
  buttons=policy(e,f);trace.append(sum(1<<b for b in buttons));e.step(buttons)
  key=(e.get('mode'),e.get('level'),e.get('lives'))
  state=(e.get('eventType'),e.get('streetPose'),e.get('level'),e.get('lives'),e.get('brickY'),e.get('brickX'),e.get('brickWarn'),e.get('mode'))
  if previous and key[0]==1 and previous[7]==1 and previous[2]==state[2]:
   kind=None
   if previous[0]!=state[0]:
    kind='jump_started' if state[0]==2 else 'jump_caught'
   if kind:mechanics.append(dict(frame=f,call=key[1]+1,event=kind,y=previous[4],lives=state[3]))
  previous=state
  if key!=old:
   events.append({'frame':f,'mode':key[0],'level':key[1]+1,'lives':key[2],'seconds':e.get('seconds'),'heat':e.get('fireHeat',12)})
   print(events[-1],flush=True);old=key
  if f>10:stats[e.lines[-1]]+=1
  if key[0] in (4,5):break
 out={'sha256':hashlib.sha256(ROM.read_bytes()).hexdigest(),'frames':len(trace),'events':events,'scanlines':dict(stats),'won':e.get('mode')==5,'memory_writes':0,'mechanic_events':mechanics,'ending_lives':e.get('lives')}
 (ROOT/'build/campaign.json').write_text(json.dumps(out,indent=2));(ROOT/'build/inputs.json').write_text(json.dumps(trace))
 e.save(ROOT/'build/campaign-last.png');e.close();return out
if __name__=='__main__':campaign()

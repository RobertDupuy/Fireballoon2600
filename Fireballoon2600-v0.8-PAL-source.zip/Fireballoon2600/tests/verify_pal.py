"""PAL timing/mechanics and native TIA rendering checks. Fixtures write RAM.

The separate campaign/replay uses input only. Here controlled fixtures measure
real PAL-frame durations and exercise worst paths on the extra simulation tick.
"""
import ctypes as C
import hashlib, json
from collections import Counter, defaultdict
import numpy as np
from emulator import Emulator, ROOT, ROM, SCANLINES

assert SCANLINES == 312, 'Build --tv pal first'
e = Emulator()
checks, timing = [], Counter()
rom = ROM.read_bytes()

def check(name, result, detail=None):
    checks.append(dict(test=name, passed=bool(result), detail=detail))
    print(name, 'PASS' if result else 'FAIL', detail or '', flush=True)
    assert result, name

def put(name, values):
    for i, value in enumerate(values):
        e.ram[e.symbols[name] - 128 + i] = value

def step(n=1, buttons=()):
    e.step(buttons, n)
    timing.update(e.lines[-n:])
    assert set(e.lines[-n:]) == {312}, (e.lines[-n:], e.get('palPhase'))

def load(call=1):
    e.core.retro_reset()
    e.step(n=30)
    e.step([0])
    e.step()
    if call > 1:
        e.set('level', call-2)
        e.set('mode', 2)
        e.set('transition', 1)
        e.set('palPhase', 5)
        step()

def quiet():
    for key, value in dict(residentQuota=0, growClock=240, waves=1,
        waveClock=240, eventType=0, brickY=0, brickWarn=0, brickPeriod=0,
        seconds=0x99, secondClock=60, frame=0, palPhase=5, hitClock=0,
        cooldown=0, pose=0, pending=0, refill=0, water=8).items():
        e.set(key, value)
    put('shotY', [0]*4)
    put('fireHeat', [128 if v == 128 else 0 for v in e.get('fireHeat', 12)])

def trace(buttons=()):
    e.core.retro_ff_trace_start()
    step(buttons=buttons)
    e.core.retro_ff_trace_size.restype = C.c_uint
    e.core.retro_ff_trace_data.restype = C.POINTER(C.c_uint32)
    count = e.core.retro_ff_trace_size()
    data = np.ctypeslib.as_array(e.core.retro_ff_trace_data(), shape=(count,)).copy().reshape(-1,10)
    writes = defaultdict(list)
    for v in data:
        if v[3] in (27, 28):
            writes[int(v[1])].append((int(v[2])//3, int(v[3])))
    patterns = [[(10,27),(18,28),(39,27),(47,28),(55,27),(58,28)],
                [(12,27),(20,28),(39,27),(47,28),(55,27),(58,28)]]
    rows = [line for line, seq in writes.items() if seq[:6] in patterns]
    return rows, data

def expected_window(art, bank):
    stage, phase = divmod(art, 4)
    halves = []
    for half in (0,1):
        address = bank*4096 + e.symbols[f'Art{stage}_{phase}_{half}'] - 0xf000
        halves.append(list(reversed(rom[address:address+16])))
    return np.array([[(halves[x//8][y]>>(7-x%8))&1 for x in range(16)] for y in range(16)], bool)

load(); quiet(); e.set('seconds',0x50); e.set('manX',18)
step(50, (7,))
check('50 PAL frames execute 60 original logic ticks', e.get('frame') == 60)
check('Countdown advances one second per 50 PAL frames', e.get('seconds') == 0x49 and e.get('secondClock') == 60)
check('Movement retains 75 color clocks per second', e.get('manX') == 93, e.get('manX'))

load(); quiet(); e.set('water',0); e.set('refill',60)
step(49)
check('Refill is still in progress before one second', e.get('water') == 0 and e.get('refill') > 0)
step()
check('Refill finishes after 50 PAL frames', e.get('water') == 8 and e.get('refill') == 0)

load(); quiet(); e.set('growClock',5); e.ram[e.symbols['fireHeat']-128+1] = 1
step(50)
check('Fire growth retains 12 heat ticks per second', e.get('fireHeat',12)[1] == 13)

load(3); quiet(); e.set('waves',0); e.ram[e.symbols['fireHeat']-128+1] = 160
step(213)
check('Resident warning has not started before 4.27 seconds', e.get('fireHeat',12)[1] == 223 and e.get('eventType') == 0)
step()
check('Resident warning starts at the original real time', e.get('fireHeat',12)[1] == 224)
step(105)
check('Resident stays at the window until the rescue delay ends', e.get('eventType') == 0 and e.get('fireHeat',12)[1] == 255)
step()
check('Resident jumps after 320 PAL frames / 6.4 seconds', e.get('eventType') == 2 and e.get('brickY') == 56)

for buttons in ((5,), (5,6), (5,7), (5,0,7)):
    load(3); quiet(); e.set('manX',72)
    step(15,buttons)
    check(f'DOWN {buttons} keeps blanket open and blocks movement/throws',
        e.get('manX') == 72 and e.get('streetPose') == 4 and e.get('water') == 8)
    step(2,(7,))
    check(f'Releasing DOWN {buttons} restores movement', e.get('manX') > 72)

load(3); quiet(); e.set('waves',0)
for k,v in dict(eventType=2, brickY=163, brickX=72, brickWarn=4, manX=68).items(): e.set(k,v)
step(5,(5,7))
check('A stationary blanket catches at PAL speed', e.get('eventType') == 0 and e.get('lives') == 3 and e.get('scoreHi') == 5)

load(3); quiet(); e.set('waves',0)
for k,v in dict(eventType=2, brickY=163, brickX=72, brickWarn=4, manX=68).items(): e.set(k,v)
step(25)
check('A missed catch costs exactly one life', e.get('mode') == 3 and e.get('lives') == 2 and e.get('lossCause') == 5)
step(124)
check('Loss animation cannot repeatedly subtract lives', e.get('mode') == 3 and e.get('lives') == 2)
step()
check('Missed catch retries the same call at the original pace', e.get('mode') == 1 and e.get('level') == 2)

load(3); quiet(); e.ram[e.symbols['fireHeat']-128+1] = 224
e.set('manX',75); e.set('wind',0)
step(1,(0,)); step(55)
check('A FIRE tap rescues a resident at the window', e.get('fireHeat',12)[1] == 0 and e.get('scoreHi') == 2 and e.get('scoreLo') == 0x50)
load(); quiet(); step(30,(0,))
check('Holding FIRE still throws only one balloon', e.get('water') == 7)

# Find the native PAL viewport origin from ROM pixels, then use the same origin
# for every layout, window and resident position. No stretching or painted pixels.
load(); quiet(); put('fireHeat',[128 if v==128 else 65 for v in e.get('fireHeat',12)])
rows, data = trace()
expected = expected_window(e.get('artIndex',12)[1], 1)
matches = []
for origin in range(0,80):
    y = rows[0]-origin
    crop = e.image[y:y+16,72:88]
    if crop.shape == (16,16,3):
        actual = (crop != e.image[y:y+16,0:1]).any(axis=2)
        if np.array_equal(expected,actual): matches.append(origin)
check('PAL viewport origin is identified from native sprite pixels', len(matches)==1, matches)
origin = matches[0]

shape = [0x18,0x3c,0x3c,0x18,0x99,0xdb,0x7e,0x3c,0x3c,0x24,0x24,0x66]
resident = np.array([[(v>>(7-x))&1 for x in range(8)] for v in shape],bool)
foreground_frames=0
for call,bank in ((1,1),(2,4),(3,5),(4,6)):
    load(call); quiet(); put('fireHeat',[128 if v==128 else 65 for v in e.get('fireHeat',12)])
    rows,data=trace()
    check(f'Layout {call}: all 64 window rows meet their six write deadlines',len(rows)==64)
    check(f'Layout {call}: floor pitch remains exactly 28 lines',rows[::16]==[rows[0]+28*i for i in range(4)])
    errors=0
    for i,art in enumerate(e.get('artIndex',12)):
        y=rows[(i//3)*16]-origin; x=40+(i%3)*32
        actual=(e.image[y:y+16,x:x+16] != e.image[y:y+16,0:1]).any(axis=2)
        errors+=int(np.count_nonzero(actual != expected_window(art,bank)))
    check(f'Layout {call}: all window graphics match ROM pixels',errors==0,errors)
    e.save(ROOT/f'build/pal-street-{call}.png')
    offset=rows[0]-origin-42
    quiet(); e.core.retro_ff_debug_colors(1)
    for col in range(3):
        missing=[]
        for by in range(56,178):
            # Keep this fixture on a single logical step so the measured y
            # coordinate is exact; cadence is tested separately above.
            for k,v in dict(mode=1,eventType=2,brickX=40+32*col,brickWarn=4*col,
                brickY=by,manX=18,frame=0,palPhase=5,growClock=240,
                waveClock=240,secondClock=60).items(): e.set(k,v)
            step(); foreground_frames+=1
            crop=e.image[by+offset-11:by+offset+1,40+32*col:48+32*col]
            # Stella's PAL yellow has blue=115; the old NTSC blue<100
            # predicate rejects P1 at the street handoff. Identify red/yellow
            # by chroma, excluding gray background and blue playfield.
            signed=crop.astype(np.int16)
            foreground=(signed[:,:,0]-signed[:,:,2])>60
            n=int(np.count_nonzero(resident & ~foreground))
            if n: missing.append((by,n))
        check(f'Layout {call}, column {col+1}: full resident at all 122 heights',not missing,missing[:4])
    e.core.retro_ff_debug_colors(0)

# Check life-loss display phases and timing in all four layouts.
for call in range(1,5):
    for col in range(3):
        load(call); quiet(); before=e.get('fireHeat',12)
        windows=[i for i in range(col,12,3) if before[i]!=128]
        e.ram[e.symbols['fireHeat']-128+windows[-1]]=127
        e.set('growClock',1); step()
        check(f'Layout {call}, building {col+1}: all its windows erupt',
            e.get('mode')==3 and e.get('lives')==2 and e.get('transition')==240
            and all(e.get('fireHeat',12)[i]==127 for i in windows))
        step(74)
        check(f'Layout {call}, building {col+1}: inferno lasts 1.5 seconds',e.get('transition')>=151)
        step()
        check(f'Layout {call}, building {col+1}: collapse begins after inferno',e.get('transition')==150)
        step(125)
        check(f'Layout {call}, building {col+1}: retry preserves one-life penalty',e.get('mode')==1 and e.get('lives')==2 and e.get('level')==call-1)

# Extra-tick collision/growth/arrival extremes and the remaining stack margin.
load(20); quiet(); e.ram[119]=0xa5; e.ram[120]=0x5a
for phase in range(1,6):
    for frame in (3,7,63,127,255):
        for buttons in ((),(5,),(5,7)):
            for k,v in dict(mode=1,residentQuota=1,growClock=1,frame=frame,
                palPhase=phase,secondClock=1,seconds=0x99,brickPeriod=100,
                brickClock=1,brickY=0,brickWarn=0,eventType=0,wind=2,
                waveClock=1,hitClock=12,hitWindow=10).items(): e.set(k,v)
            put('fireHeat',[223,128,97,223,65,32,65,32,97,1,32,65])
            put('shotX',[48,80,112,48]); put('shotY',[52,80,108,136])
            step(3,buttons)
check('Extra-tick worst paths preserve stack guards',list(e.ram[119:121])==[0xa5,0x5a])
check('PAL uses 119 RAM bytes and leaves nine bytes for the stack',e.symbols['ramEnd']==0xf7)
check('All controlled paths stay at exactly 312 scanlines',set(timing)=={312},dict(timing))

e.core.retro_reset(); e.step(n=90); e.capture_audio=True; e.step(n=50)
samples=np.concatenate(e.samples)
check('PAL title has native TIA audio',int(np.abs(samples.astype(np.int32)).max())>1000)
e.save(ROOT/'build/pal-title.png')
e.close()
(ROOT/'build/pal-verification.json').write_text(json.dumps(dict(
    sha256=hashlib.sha256(rom).hexdigest(),tv='PAL',fixture_memory_writes=True,
    checks=checks,scanlines=dict(timing),viewport_origin=origin,
    foreground_frames=foreground_frames),indent=2)+'\n')

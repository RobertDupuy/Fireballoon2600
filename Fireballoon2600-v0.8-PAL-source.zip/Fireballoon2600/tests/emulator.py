"""Small libretro host for native Stella. Memory reads for tests; no custom emulation."""
import ctypes as C
import os,json
from pathlib import Path
import numpy as np
from PIL import Image
ROOT=Path(__file__).resolve().parents[1]
CONFIG=json.loads((ROOT/'build/config.json').read_text()) if (ROOT/'build/config.json').exists() else dict(tv='ntsc',rom='Fireballoon2600-NTSC.bin',scanlines=262,fps=60)
ROM=ROOT/'build'/CONFIG['rom']
SCANLINES=CONFIG['scanlines']
FPS=CONFIG['fps']
class Info(C.Structure):_fields_=[('path',C.c_char_p),('data',C.c_void_p),('size',C.c_size_t),('meta',C.c_char_p)]
class Var(C.Structure):_fields_=[('key',C.c_char_p),('value',C.c_char_p)]
ENV=C.CFUNCTYPE(C.c_bool,C.c_uint,C.c_void_p)
VIDEO=C.CFUNCTYPE(None,C.c_void_p,C.c_uint,C.c_uint,C.c_size_t)
AUDIO=C.CFUNCTYPE(None,C.c_int16,C.c_int16)
BATCH=C.CFUNCTYPE(C.c_size_t,C.POINTER(C.c_int16),C.c_size_t)
POLL=C.CFUNCTYPE(None)
INPUT=C.CFUNCTYPE(C.c_int16,C.c_uint,C.c_uint,C.c_uint,C.c_uint)
class Emulator:
 def __init__(self,rom=None,console=None):
  console=console or CONFIG['tv']
  core=Path(os.environ.get('STELLA_CORE',str(ROOT/'.test-tools/stella/src/os/libretro/stella2023_libretro.so')))
  if not core.exists():
   folder=ROOT/'.test-tools/stella/src/os/libretro'
   candidates=[folder/('stella2023_libretro'+suffix) for suffix in ('.so','.dylib','.dll')]
   core=next((p for p in candidates if p.exists()),ROOT.parent/'tools/stella2023/src/os/libretro/stella2023_libretro.so')
  self.core=C.CDLL(str(core))
  self.console=console
  self.buttons=set();self.image=None;self.samples=[];self.capture_audio=False;self.lines=[];self.options={};self.pixels=1
  @ENV
  def env(cmd,data):
   if cmd==15:
    v=C.cast(data,C.POINTER(Var)).contents
    if v.key in self.options:v.value=self.options[v.key];return True
    return False
   if cmd==16:
    vs=C.cast(data,C.POINTER(Var));i=0
    while vs[i].key:
     self.options.setdefault(vs[i].key,vs[i].value.split(b'; ')[1].split(b'|')[0]);i+=1
    self.options[b'stella_console']=console.encode()
    self.options[b'stella_filter']=b'disabled'
    self.options[b'stella_phosphor']=b'disabled'
    return True
   if cmd==10:self.pixels=C.cast(data,C.POINTER(C.c_int)).contents.value;return True
   if cmd in (9,31):C.cast(data,C.POINTER(C.c_char_p))[0]=str(ROOT/'build').encode();return True
   if cmd==17:C.cast(data,C.POINTER(C.c_bool))[0]=False;return True
   if cmd==47:C.cast(data,C.POINTER(C.c_uint))[0]=3;return True
   if cmd in (8,11,18,32,35,37):return True
   return False
  @VIDEO
  def video(data,w,h,pitch):
   if data:
    a=np.frombuffer(C.string_at(data,h*pitch),np.uint8).reshape(h,pitch)[:,:w*4].reshape(h,w,4)
    self.image=a[:,:,[2,1,0]].copy()
  @AUDIO
  def audio(l,r):
   if self.capture_audio:self.samples.append(np.array([[l,r]],dtype=np.int16))
  @BATCH
  def batch(p,n):
   if self.capture_audio:self.samples.append(np.ctypeslib.as_array(p,shape=(n*2,)).reshape(n,2).copy())
   return n
  @POLL
  def poll():pass
  @INPUT
  def inp(port,device,index,key):return int(port==0 and key in self.buttons)
  self.callbacks=[env,video,audio,batch,poll,inp]
  for name,cb in zip(['environment','video_refresh','audio_sample','audio_sample_batch','input_poll','input_state'],self.callbacks):getattr(self.core,'retro_set_'+name)(cb)
  self.core.retro_init()
  rom=Path(rom or ROM);self.rombytes=C.create_string_buffer(rom.read_bytes());self.info=Info(str(rom).encode(),C.cast(self.rombytes,C.c_void_p),len(self.rombytes)-1,None)
  self.core.retro_load_game.argtypes=[C.POINTER(Info)];self.core.retro_load_game.restype=C.c_bool
  assert self.core.retro_load_game(C.byref(self.info)),'load failed'
  self.core.retro_get_memory_data.argtypes=[C.c_uint];self.core.retro_get_memory_data.restype=C.c_void_p
  ptr=self.core.retro_get_memory_data(2);self.ram=(C.c_uint8*128).from_address(ptr)
  self.symbols={}
  for line in (ROOT/'build/Fireballoon2600.sym').read_text().splitlines():
   a=line.split()
   if len(a)>1:
    try:self.symbols[a[0]]=int(a[1],16)
    except ValueError:pass
 def get(self,name,n=1):
  i=self.symbols[name]-128
  return self.ram[i] if n==1 else list(self.ram[i:i+n])
 def set(self,name,v):self.ram[self.symbols[name]-128]=v
 def step(self,buttons=(),n=1):
  self.buttons=set(buttons)
  for _ in range(n):
   self.core.retro_run()
   if hasattr(self.core,'retro_fb_scanlines'):self.lines.append(self.core.retro_fb_scanlines())
 def save(self,path):
  im=Image.fromarray(self.image)
  im.resize((640,im.height*2),Image.Resampling.NEAREST).save(path)
 def close(self):self.core.retro_unload_game();self.core.retro_deinit()
if __name__=='__main__':
 e=Emulator();e.step(n=120);e.save(ROOT/'build/title.png');print('title',e.get('mode'),e.image.shape,e.lines[-10:]);e.step([0]);e.step(n=120);e.save(ROOT/'build/game.png');print('play',e.get('mode'),e.get('fireHeat',8),e.get('seconds'),e.lines[-10:]);e.close()

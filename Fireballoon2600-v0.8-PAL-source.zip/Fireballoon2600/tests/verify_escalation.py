"""Visual failure clarity and recurring-resident fixtures; writes RAM for setup."""
import hashlib,json
from collections import Counter
from pathlib import Path
import sys
import numpy as np
sys.path.insert(0,str(Path(__file__).parent))
from emulator import Emulator,ROOT
sys.path.insert(0,str(ROOT))
from street_design import STREETS,present

e=Emulator();checks=[];timing=Counter()
def check(name,passed,detail=None):
    checks.append(dict(test=name,passed=bool(passed),detail=detail))
    print(name,'PASS' if passed else 'FAIL',detail or '',flush=True)
    assert passed,name
def put(name,values):
    for i,v in enumerate(values):e.ram[e.symbols[name]-128+i]=v
def step(n=1,buttons=()):
    e.step(buttons,n);timing.update(e.lines[-n:])
    if any(v!=262 for v in e.lines[-n:]):print('BAD RASTER',e.lines[-n:],{k:e.get(k) for k in ['level','mode','transition','frame','lossCause','count','growClock','brickY']},flush=True)
def load(call):
    e.core.retro_reset();e.step(n=30);e.step([0]);e.step()
    if call>1:e.set('level',call-2);e.set('mode',2);e.set('transition',1);e.step()
def quiet():
    for k,v in dict(residentQuota=0,growClock=240,waves=1,waveClock=240,eventType=0,brickY=0,brickWarn=0,brickPeriod=0,seconds=90,secondClock=60).items():e.set(k,v)
    put('shotY',[0]*4)
    put('fireHeat',[128 if v==128 else 0 for v in e.get('fireHeat',12)])
def flame_mask(im):
    return (im[:,:,0]>im[:,:,2]+40)&(im[:,:,1]>im[:,:,2]+40)

# Compare the entire rendered flame, including its extension above the window.
load(1);quiet();sizes=[];heights=[]
for heat in (97,113):
    e.ram[e.symbols['fireHeat']-128+4]=heat;e.set('frame',0);step(2)
    mask=flame_mask(e.image[70:110,72:88].astype(np.int16))
    sizes.append(int(mask.sum()));heights.append(int(np.count_nonzero(mask.any(axis=1))))
check('Critical flames visibly exceed the previous largest stage',sizes[1]>sizes[0]*1.4 and heights[1]>heights[0]+5,dict(pixels=sizes,visible_rows=heights))
check('The oversized stage is still playable before collapse',e.get('mode')==1 and e.get('lives')==3)

regions=[(32,64),(68,92),(96,128)]
for call in range(1,5):
    street=STREETS[call-1]
    for col in range(3):
        load(call);quiet();before=e.get('fireHeat',12)
        doomed=[i for i in range(col,12,3) if present(street,i)]
        before[doomed[-1]]=127;put('fireHeat',before);e.set('growClock',1);step()
        heat=e.get('fireHeat',12)
        check(f'Layout {call}, building {col+1}: every real window erupts together',
              e.get('mode')==3 and e.get('lossCause')==col and e.get('transition')==240 and
              all(v==127 if i in doomed else v==before[i] for i,v in enumerate(heat)))
        check(f'Layout {call}, building {col+1}: engulfment costs exactly one life',e.get('lives')==2)
        step(89)
        check(f'Layout {call}, building {col+1}: all windows stay oversized for 90 frames',
              e.get('transition')==151 and all(32<=e.get('artIndex',12)[i]<=35 for i in doomed))
        # The collapse kernel has a fixed silhouette; compare its successive stages.
        step(2);intact=e.image.copy();step(121);gone=e.image.copy()
        x0,x1=regions[col]
        check(f'Layout {call}, building {col+1}: the burned building disappears',
              np.count_nonzero(intact[40:150,x0:x1])>100 and not np.any(gone[40:150,x0:x1]))
        check(f'Layout {call}, building {col+1}: neighboring buildings stay standing',
              all(np.array_equal(intact[40:150,a:b],gone[40:150,a:b]) for c,(a,b) in enumerate(regions) if c!=col))
        check(f'Layout {call}, building {col+1}: score and timer stay visible through collapse',
              np.array_equal(intact[:40],gone[:40]))
        step(28)
        check(f'Layout {call}, building {col+1}: one loss retries the same call',
              e.get('mode')==1 and e.get('level')==call-1 and e.get('lives')==2)

# Failure from another cause never masquerades as a burned-down building.
for cause in ('timeout','masonry','missed catch'):
    load(1);quiet();step(2);before=e.image.copy()
    if cause=='timeout':e.set('seconds',1);e.set('secondClock',1)
    elif cause=='masonry':
        for k,v in dict(brickY=164,brickX=32,manX=32,invincible=0,brickPeriod=100).items():e.set(k,v)
    else:
        for k,v in dict(eventType=2,brickY=177,brickX=40,manX=132,frame=1).items():e.set(k,v)
    step();step(120)
    check(f'{cause}: buildings remain standing',e.get('mode')==3 and e.get('lossCause')>=3 and all(np.count_nonzero(e.image[40:145,a:b])>=0.9*np.count_nonzero(before[40:145,a:b]) for a,b in regions))

# The authored quota increases; a cleared street cannot skip pending arrivals.
manifest=json.loads((ROOT/'design.json').read_text())
for call in (3,6,7,12,13,20):
    load(call)
    total=sum(v>=160 for v in e.get('fireHeat',12))+e.get('residentQuota')
    check(f'Call {call}: three to five resident emergencies are scheduled',total==(3 if call<=6 else 4 if call<=12 else 5),total)
    quiet();e.set('residentQuota',2);e.set('waves',0);e.set('count',0);e.set('frame',20);step()
    check(f'Call {call}: pending arrivals prevent a premature call clear',e.get('mode')==1 and e.get('residentQuota')==1 and sum(v>=160 for v in e.get('fireHeat',12))==1)
    sky=[i for i in range(12) if not present(STREETS[(call-1)%4],i)]
    e.set('frame',127);step(2)
    check(f'Call {call}: another resident appears in a real window',e.get('residentQuota')==0 and sum(v>=160 for v in e.get('fireHeat',12))==2 and all(e.get('fireHeat',12)[i]==128 for i in sky))
    e.set('residentQuota',1);e.set('frame',127);step(2)
    check(f'Call {call}: at most two residents are active together',e.get('residentQuota')==1 and sum(v>=160 for v in e.get('fireHeat',12))==2)

# Spawn-search extremes coincide with growth, four projectiles, timer and input.
for fill in (0,97):
    for col in range(12):
        load(20);quiet()
        values=[128 if v==128 else fill for v in e.get('fireHeat',12)]
        if values[col]!=128:values[col]=0
        put('fireHeat',values);put('shotX',[48,80,112,48]);put('shotY',[52,80,108,136])
        for k,v in dict(residentQuota=1,frame=127,random=col,growClock=1,secondClock=1,waveClock=1,brickPeriod=100,brickClock=1).items():e.set(k,v)
        step(3,[5,7])
check('Escalation, collapse and recurring arrivals retain 262 scanlines',set(timing)=={262},dict(timing))
(ROOT/'build/escalation-verification.json').write_text(json.dumps(dict(sha256=hashlib.sha256((ROOT/'build/Fireballoon2600-NTSC.bin').read_bytes()).hexdigest(),fixture_memory_writes=True,checks=checks,scanlines=dict(timing)),indent=2))
e.close()

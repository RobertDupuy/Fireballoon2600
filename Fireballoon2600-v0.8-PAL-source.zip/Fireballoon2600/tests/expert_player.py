"""Input-only deadline-aware player. No state changes, saves, or rewinds."""
from emulator import Emulator, ROOT

X=[48,80,112]*4
Y=[50]*3+[78]*3+[106]*3+[134]*3

def policy(e, frame):
    mode=e.get('mode')
    if mode==0:return [0] if frame%2==0 else []
    if mode!=1:return []
    pos=e.get('manX');phase=e.get('frame');wind=e.get('wind')
    heats=[0 if v==128 else v for v in e.get('fireHeat',12)]
    by=e.get('brickY');bx=e.get('brickX')
    event=e.get('eventType')
    if event==2 and (by>=146 or (164-by)*2<abs(e.get('brickX')-pos)/1.25+12):
        target=e.get('brickX')-4
        return [5] if abs(target-pos)<=3 else [6 if pos>target else 7]
    if event==0 and by>=126:
        safe=[bx+d for d in (-16,16,48,80) if 18<=bx+d<=132]
        target=min(safe,key=lambda x:abs(x-pos))
        return [] if abs(target-pos)<=3 else [6 if pos>target else 7]
    if e.get('pose')>8:return []
    def drift(start, frames):
        if wind==0:return 0
        return sum((-1 if wind==255 or (wind==2 and (start+t)&128) else 1)
                   for t in range(1,frames+1) if (start+t)&7==0)
    # Predict interceptions in order of actual arrival, allowing aim changes
    # before an already committed balloon reaches a distant upper floor.
    projected=heats[:]
    shots=[[sx,sy] for sx,sy in zip(e.get('shotX',4),e.get('shotY',4)) if sy]
    for tick in range(1,61):
        for shot in shots:
            if not shot[1]:continue
            shot[1]-=2
            if shot[1]<32:shot[1]=0;continue
            if (phase+tick)&7==0:
                shot[0]+=(-1 if wind==255 or (wind==2 and (phase+tick)&128) else 1) if wind else 0
            for i in reversed(range(12)):
                if projected[i] and Y[i]-3<=shot[1]<=Y[i]+1 and abs(shot[0]-X[i])<=8:
                    h=projected[i]
                    projected[i]=0 if h<=32 or h>=128 else ((h-32)&96)|1
                    shot[1]=0;break
    choices=[]
    for col in range(3):
        occupied=[i for i in range(col,12,3) if projected[i]]
        fires=[i for i in occupied if projected[i]<128]
        # Account for residents that will intercept balloons on the way up.
        # Residents above the highest fire can be left for a blanket rescue.
        indices=[i for i in occupied if e.get('level')<2 or (fires and i>=min(fires))]
        if not indices:continue
        low=max(indices)
        travel=(150-Y[low])//2
        aim=X[low]-5-drift(phase+5,travel)
        move=max(0,abs(aim-pos)-5)/1.25
        # How much time remains after clearing the obstructing lower windows?
        required=0;slack=10000
        for i in reversed(indices):
            h=projected[i]
            required += 1 if h>=128 else (h+31)//32
            deadline=900 if h>=128 else (128-h)*5
            need=max(0,required-1)*16+(150-Y[i])//2+6
            slack=min(slack,deadline-need)
        choices.append((slack+move*1.9,aim,low))
    if not choices:return []
    _,aim,target=min(choices)
    aim=max(18,min(132,aim));diff=aim-pos
    buttons=[]
    tolerance=4
    if abs(diff)>tolerance:buttons.append(7 if diff>0 else 6)
    if abs(diff)<=tolerance+1 and not e.get('cooldown') and e.get('water') and not e.get('refill') and e.get('trigger'):
        buttons.append(0)
    return buttons

if __name__=='__main__':
    import play
    play.policy=policy
    play.campaign()

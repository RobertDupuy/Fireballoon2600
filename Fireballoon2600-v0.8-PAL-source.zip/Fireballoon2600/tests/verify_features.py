"""Targeted late-mechanic, collision, rendering and timing fixtures (RAM setup)."""
import json,hashlib,ctypes as C
from collections import Counter,defaultdict
from emulator import Emulator,ROOT
import numpy as np
import sys
sys.path.insert(0,str(ROOT))
from street_design import STREETS

e=Emulator();checks=[];timing=Counter()
def check(name,value,detail=None):
    checks.append(dict(test=name,passed=bool(value),detail=detail));print(name,'PASS' if value else 'FAIL',detail or '',flush=True)
    assert value,name
def put(name,vals):
    for i,v in enumerate(vals):e.ram[e.symbols[name]-128+i]=v
def load(call):
    e.core.retro_reset();e.step(n=30);e.step([0]);e.step()
    if call>1:e.set('level',call-2);e.set('mode',2);e.set('transition',1);e.step()
def quiet():
    e.set('residentQuota',0);e.set('brickY',0);e.set('brickWarn',0);e.set('eventType',0);e.set('brickPeriod',0)
    e.set('growClock',240);e.set('waves',1);e.set('waveClock',240)
    put('shotY',[0]*4)
    put('fireHeat',[128 if v==128 else 0 for v in e.get('fireHeat',12)])
def step(n=1,buttons=()):
    e.step(buttons,n=n);timing.update(e.lines[-n:])
    if any(v!=262 for v in e.lines[-n:]):
        print("BAD TIMING",e.lines[-n:],{k:e.get(k) for k in ["eventType","brickY","brickWarn","mode","level"]},flush=True)
def trace():
    e.core.retro_ff_trace_start();step()
    e.core.retro_ff_trace_size.restype=C.c_uint;e.core.retro_ff_trace_data.restype=C.POINTER(C.c_uint32)
    n=e.core.retro_ff_trace_size();tr=np.ctypeslib.as_array(e.core.retro_ff_trace_data(),shape=(n,)).copy().reshape(-1,10)
    writes=defaultdict(list)
    for f,line,cc,reg,value,*_ in tr:
        if reg in (27,28):writes[int(line)].append((int(cc)//3,int(reg)))
    schedules=[[(10,27),(18,28),(39,27),(47,28),(55,27),(58,28)],[(12,27),(20,28),(39,27),(47,28),(55,27),(58,28)]]
    rows=[line for line,seq in writes.items() if seq[:6] in schedules]
    return rows,tr

for call in (2,3,4,5,7,8,10,11,20):
    load(call)
    check(f'Call {call}: correct resident unlock',all(v==224 for v in e.get('fireHeat',12) if v>=160) if call<3 else all(v in (160,161) for v in e.get('fireHeat',12) if v>=160))
check('Reservoir logic and data removed',not any('Tank' in k or 'tankMask' in k for k in e.symbols))

load(5);quiet();put('fireHeat',[128,160,128]+[0]*9);e.set('waves',0);e.set('frame',0)
step(255)
check('Resident stays rescueable for over four seconds',e.get('fireHeat',12)[1]==223 and e.get('eventType')==0)
step()
check('Final warning starts at 4.27 seconds',e.get('fireHeat',12)[1]==224 and e.get('sound')==8)
step(127)
check('Resident remains at window until full delay',e.get('eventType')==0 and e.get('fireHeat',12)[1]==255)
step()
check('Resident jumps after 384 frames (6.4 seconds)',e.get('eventType')==2 and e.get('brickY')==56 and e.get('fireHeat',12)[1]==0)
step(2);check('Falling resident prevents premature call clear',e.get('mode')==1 and e.get('count')==1)

load(5);quiet();put('fireHeat',[128,224,128]+[0]*9);e.set('manX',75);e.set('wind',0)
step(1,[0]);step(65)
check('A real FIRE tap saves a resident during the final warning',e.get('fireHeat',12)[1]==0 and e.get('eventType')==0 and e.get('scoreHi')==2 and e.get('scoreLo')==0x50)

for buttons in ([5],[5,6],[5,7],[5,6,7],[5,0,7]):
    load(5);quiet();e.set('manX',72);x=e.get('manX');water=e.get('water')
    step(12,buttons)
    check(f'DOWN input {buttons} locks horizontal movement and opens blanket',e.get('manX')==x and e.get('streetPose')==4)
    check(f'DOWN input {buttons} leaves water untouched',e.get('water')==water and e.get('pending')==0)
    if buttons==[5]:e.save(ROOT/'build/qa-blanket.png')
    step(2,[7]);check(f'Releasing DOWN after {buttons} restores movement',e.get('manX')>x and e.get('streetPose')<4)

for direction in (6,7):
    load(5);quiet();e.set('eventType',2);e.set('brickX',72);e.set('brickWarn',4);e.set('brickY',163);e.set('manX',68);e.set('frame',0)
    step(6,[5,direction])
    check(f'Blanket catches while DOWN+{direction} stays stationary',e.get('eventType')==0 and e.get('brickY')==0 and e.get('manX')==68 and e.get('scoreHi')==5 and e.get('lives')==3)

load(5);quiet();e.set('eventType',2);e.set('brickX',72);e.set('brickWarn',4);e.set('brickY',163);e.set('manX',68);e.set('frame',0)
step(28)
check('Standing underneath without DOWN does not catch',e.get('eventType')==2 and e.get('brickY')==177 and e.get('lives')==3)
step(2)
check('Ground contact costs one life and starts the normal death sequence',e.get('mode')==3 and e.get('lives')==2 and e.get('transition')==150)
step(149);check('Missed catch cannot subtract repeated lives',e.get('lives')==2 and e.get('mode')==3)
step();check('Missed catch retries the same call',e.get('mode')==1 and e.get('level')==4 and e.get('lives')==2)

load(5);quiet();e.set('eventType',2);e.set('brickX',40);e.set('brickWarn',0);e.set('brickY',170);e.set('manX',120)
step(20,[5]);check('DOWN at the wrong position cannot catch',e.get('mode')==3 and e.get('lives')==2)

for call in range(11,15):
    for col,x in enumerate((38,70,102)):
        load(call);quiet();e.set('wind',0)
        floor=4-STREETS[(call-1)%4]['heights'][col];y=34+28*floor
        put('shotX',[x,0,0,0]);put('shotY',[y+2,0,0,0]);step()
        check(f'Layout {call%4}, roof {col+1}: former tank has no invisible collision',e.get('shotY',4)[0]==y)

# Inspect native pixels at every vertical position, with all four layouts.
# Fixed TIA colors distinguish P0/P1 pixels from the playfield and background.
shape=[0x18,0x3c,0x3c,0x18,0x99,0xdb,0x7e,0x3c,0x3c,0x24,0x24,0x66]
expected=np.array([[(v>>(7-x))&1 for x in range(8)] for v in shape],bool)
foreground_frames=0
for call in range(11,15):
    load(call);quiet();step()
    rows,tr=trace();offset=rows[0]-23-42
    check(f'Layout {call%4}: all 64 window rows keep their deadlines',len(rows)==64,rows[::16])
    check(f'Layout {call%4}: floor pitch stays 28 scanlines',rows[::16]==[rows[0]+28*i for i in range(4)])
    for col in range(3):
        roof=4-STREETS[(call-1)%4]['heights'][col]
        yy=rows[roof*16]-23-4
        x0,x1=[(32,64),(68,92),(96,128)][col]
        check(f'Layout {call%4}, building {col+1}: solid roof coping restored',e.image[yy,x0:x1].any(axis=1).all())
    e.save(ROOT/f'build/qa-roofs-{call}.png')
    e.core.retro_ff_debug_colors(1)
    for col in range(3):
        missing=[]
        for by in range(56,178):
            for key,value in dict(mode=1,eventType=2,brickX=40+32*col,brickWarn=4*col,brickY=by,manX=18,frame=0,growClock=240,waveClock=240,secondClock=60).items():e.set(key,value)
            step();foreground_frames+=1
            crop=e.image[by+offset-11:by+offset+1,40+32*col:48+32*col]
            foreground=(crop[:,:,0]>100)&(crop[:,:,2]<100)
            n=int(np.count_nonzero(expected&~foreground))
            if n:missing.append((by,n))
        check(f'Layout {call%4}, column {col+1}: complete resident at every descent pixel',not missing,missing or {'heights_checked':122,'sprite_pixels_per_height':int(expected.sum())})
    e.core.retro_ff_debug_colors(0)
load(11);quiet();e.set('eventType',2);e.set('brickX',72);e.set('brickWarn',4);e.set('brickY',100);e.set('frame',0);step();e.save(ROOT/'build/qa-jumper.png')
load(11);quiet();e.set('eventType',2);e.set('brickX',72);e.set('brickWarn',4);e.set('brickY',163);e.set('manX',18);e.set('frame',0);step();e.save(ROOT/'build/qa-catch.png')

# A resident must not erase unrelated floors while using a window sprite.
rom=(ROOT/'build/Fireballoon2600-NTSC.bin').read_bytes()
for call in range(11,15):
    load(call);quiet();put('fireHeat',[128 if v==128 else 65 for v in e.get('fireHeat',12)])
    e.set('eventType',2);e.set('brickX',72);e.set('brickWarn',4);e.set('brickY',100);e.set('frame',0)
    rows,tr=trace();mismatch=0
    for i,art in enumerate(e.get('artIndex',12)):
        if i==7:continue
        stage,phase=divmod(art,4);halves=[]
        for half in range(2):
            address=e.get('palette')*4096+e.symbols[f'Art{stage}_{phase}_{half}']-0xf000
            halves.append(list(reversed(rom[address:address+16])))
        wanted=np.array([[(halves[x//8][y]>>(7-x%8))&1 for x in range(16)] for y in range(16)],bool)
        yy=rows[(i//3)*16]-23;xx=40+32*(i%3)
        mismatch+=int(np.count_nonzero(wanted!=e.image[yy:yy+16,xx:xx+16].any(axis=2)))
    check(f'Layout {call%4}: unrelated windows retain their complete graphics during a jump',mismatch==0,mismatch)

# Fine motion must finish before HMCLR: keep the bucket beside the player.
for x in (18,72,132):
    for pose in (0,4,12):
        load(5);quiet();e.set('manX',x);e.set('pose',pose)
        _,tr=trace();street=[v for v in tr if v[3]==28 and 190<v[1]<225]
        positions=tuple(int(v) for v in street[-1][6:8])
        check(f'Player {x}, pose {pose}: bucket stays within one pixel of the hand',positions[0]==x and abs(positions[1]-(x+6))<=1,positions)

# Confirm horizontal balloon positioning after the new foreground-safe kernel.
for x in (18,38,70,102,132,146):
    load(5);quiet();e.set('wind',0)
    put('shotX',[x]*4);put('shotY',[54,82,110,138])
    rows,tr=trace()
    drawn={int(v[8]) for v in tr if int(v[3])==28 and int(v[2])//3==58}
    check(f'Balloon aim {x}: all four bands retain horizontal alignment',bool(drawn) and all(abs(v-x)<=1 for v in drawn),sorted(drawn))

# Check the actual TIA enable latches through the entire street. In v0.6 a
# balloon on the lowest window row stayed enabled and became a white column.
leaks=[];cases=0
for pose,buttons in [(0,()),(4,()),(12,()),(0,(5,))]:
    for by in range(122,149):
        load(5);quiet();e.set('pose',pose);e.set('wind',0);e.set('manX',72)
        put('shotX',[77,0,0,0]);put('shotY',[by,0,0,0])
        step(1,buttons)
        e.core.retro_ff_trace_start();step(1,buttons)
        n=e.core.retro_ff_trace_size();tr=np.ctypeslib.as_array(e.core.retro_ff_trace_data(),shape=(n,)).copy().reshape(-1,10)
        state={30:0,31:0}
        for v in tr:
            line,reg,val=map(int,(v[1],v[3],v[4]))
            if reg in state:state[reg]=val&2
            if 177<=line<=211 and any(state.values()):leaks.append((pose,by,line,dict(state)));break
        cases+=1
check('Balloon and masonry latches cannot streak through the player',not leaks,{'cases':cases,'leaks':leaks[:5]})

# Coincident growth, all four shots, warnings and catching still fit the frame.
for buttons in ((),(5,),(5,6),(5,7)):
    for t in (0,2):
        load(20);quiet();put('fireHeat',[223,128,97,223,65,32,65,32,97,1,32,65])
        e.set('eventType',t);e.set('brickY',100 if t else 0);e.set('brickWarn',0);e.set('brickX',40)
        e.set('hitClock',12);e.set('hitWindow',10);e.set('refill',40);e.set('water',0);e.set('growClock',1);e.set('frame',7)
        put('shotX',[48,80,112,48]);put('shotY',[54,82,110,138]);step(5,buttons)
check('All new mechanic paths retain 262 scanlines' ,set(timing)=={262},dict(timing))
load(11);quiet();e.ram[118]=0xa5;e.ram[119]=0x5a
put('shotX',[48,80,112,48]);put('shotY',[52,80,108,136]);step(10,[5])
check('Feature calls leave the stack guard untouched',list(e.ram[118:120])==[0xa5,0x5a])
(ROOT/'build/features-verification.json').write_text(json.dumps(dict(sha256=hashlib.sha256((ROOT/'build/Fireballoon2600-NTSC.bin').read_bytes()).hexdigest(),fixture_memory_writes=True,checks=checks,scanlines=dict(timing),foreground_frames=foreground_frames),indent=2))
e.close()

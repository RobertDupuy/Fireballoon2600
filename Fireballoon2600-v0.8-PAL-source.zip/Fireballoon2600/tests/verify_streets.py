"""Fixtures for new roof geometry, valid targets, early pressure and timing."""
import sys, json, ctypes as C, hashlib
from pathlib import Path
from collections import Counter, defaultdict
import numpy as np
from PIL import Image
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from street_design import STREETS, present
from emulator import Emulator, ROOT

e=Emulator();checks=[];pictures=[];lines=Counter()
def check(name,value,detail=None):
    checks.append(dict(test=name,pass_=bool(value),detail=detail))
    print(name,'PASS' if value else 'FAIL',detail or '',flush=True)
    assert value,name
def load(call):
    e.core.retro_reset();e.step(n=30);e.step([0]);e.step()
    if call:
        e.set('level',call-1);e.set('mode',2);e.set('transition',1);e.step()

for i in range(20):
    load(i);street=STREETS[i%4];h=e.get('fireHeat',12)
    check(f'Call {i+1}: correct bank and inactive windows',
          e.get('palette')==street['bank'] and all((v!=128)==present(street,j) for j,v in enumerate(h)))
    check(f'Call {i+1}: opening fires and residents are in real windows',
          sum(0<v<128 for v in h)==4 and sum(v>=160 for v in h)==(0 if i==0 else 1 if i<10 else 2))
    e.step(n=90);lines.update(e.lines[-90:])
    if i<4:pictures.append(Image.fromarray(e.image).resize((640,456),Image.Resampling.NEAREST))
    # Trigger 100 accelerated outbreaks/clears without changing the validity map.
    for k in range(100):
        for j in range(12):
            if present(street,j):e.ram[e.symbols['fireHeat']-128+j]=0
        e.set('mode',1);e.set('growClock',250);e.set('waves',2+(k&1));e.set('waveClock',0)
        e.set('brickPeriod',0);e.set('brickY',0);e.set('brickWarn',0)
        e.step();lines[e.lines[-1]]+=1
        assert all((v!=128)==present(street,j) for j,v in enumerate(e.get('fireHeat',12)))
    check(f'Call {i+1}: outbreaks never ignite empty sky',True)
    if i<4:
        # Every bank must retain the exact 76-cycle window schedule.
        e.core.retro_ff_trace_start();e.step()
        e.core.retro_ff_trace_size.restype=C.c_uint
        e.core.retro_ff_trace_data.restype=C.POINTER(C.c_uint32)
        n=e.core.retro_ff_trace_size()
        tr=np.ctypeslib.as_array(e.core.retro_ff_trace_data(),shape=(n,)).copy().reshape(-1,10)
        writes=defaultdict(list)
        for f,line,cc,reg,value,pc,p0,p1,ball,cycles in tr:
            if reg in (27,28):writes[int(line)].append((int(cc)//3,int(reg)))
        schedules=[[(10,27),(18,28),(39,27),(47,28),(55,27),(58,28)],
                   [(12,27),(20,28),(39,27),(47,28),(55,27),(58,28)]]
        rows=[line for line,seq in writes.items() if seq[:6] in schedules]
        check(street['name']+': all 64 beam schedules',len(rows)==64,len(rows))
        # Black alleys separate the three silhouettes at every floor.
        yy=rows[48]-23
        check(street['name']+': black alleys reach the pavement',
              not e.image[yy:yy+16,64:68].any() and not e.image[yy:yy+16,92:96].any())

load(0);e.set('brickPeriod',0);e.set('waves',0)
for j in range(12):e.ram[e.symbols['fireHeat']-128+j]=128 if not present(STREETS[0],j) else 0
e.ram[e.symbols['fireHeat']-128+9]=1;e.set('growClock',5)
e.step(n=159);check('Opening fire has not grown before its scheduled tick',e.get('fireHeat',12)[9]==32)
e.step();check('Opening fire visibly grows after 160 frames',e.get('fireHeat',12)[9]==33)
load(0);e.step(n=165);check('Call 1 introduces warned masonry immediately',e.get('brickWarn')>0 or e.get('brickY')>0)
load(2);check('Wind arrives on call 3',e.get('wind')!=0)
check('Every tested street holds 262 scanlines',set(lines)=={262},dict(lines))
sheet=Image.new('RGB',(1280,912),'black')
for i,p in enumerate(pictures):sheet.paste(p,((i%2)*640,(i//2)*456))
sheet.save(ROOT/'build/qa-streets.png')
(ROOT/'build/streets-verification.json').write_text(json.dumps(dict(
    rom_sha256=hashlib.sha256((ROOT/'build/Fireballoon2600-NTSC.bin').read_bytes()).hexdigest(),
    fixture_memory_writes=True,checks=checks,scanlines=dict(lines)),indent=2))
e.close()

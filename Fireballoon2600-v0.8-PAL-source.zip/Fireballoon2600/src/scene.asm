; ================= BANK 3: twenty call definitions ========================
    ORG $3000
    RORG $F000
LoadLevel
    SUBROUTINE
    lda #1
    sta mode
    lda #0
    sta pose
    sta cooldown
    sta refill
    sta brickY
    sta soundClock
    sta hitClock
    sta brickWarn
    sta combo
    sta pending
    sta eventType
    sta streetPose
    lda #0
    ldx #11
.clearFires
    sta fireHeat,x
    dex
    bpl .clearFires
    ldx #3
.clearShots
    sta shotY,x
    dex
    bpl .clearShots
    lda #8
    sta water
    lda #72
    sta manX
    lda #60
    sta secondClock
    lda #60
    sta invincible
    lda level
    clc
    adc #1
    cmp #10
    bcc .bcd
    cmp #20
    bcc .teen
    lda #$20
    bne .bcd
.teen
    clc
    adc #6
.bcd
    sta levelBCD
    lda level
    asl
    asl
    asl
    asl
    sta p0
    lda #>Levels
    adc #0
    sta p0+1
    ldy #0
    lda (p0),y
    sta seconds
    iny
    lda (p0),y
    sta waves
    iny
    lda (p0),y
    sta wavePeriod
    clc
    adc #12
    sta waveClock
    iny
    lda (p0),y
    sta growClock
    iny
    lda (p0),y
    sta wind
    iny
    lda (p0),y
    sta brickPeriod
    sta brickClock
    iny
    lda (p0),y
    sta tmp2
    iny
    lda (p0),y
    sta palette
    asl
    asl
    asl
    asl
    tay
    ldx #0
.windowMap
    lda WindowFlags,y
    sta fireHeat,x
    iny
    inx
    cpx #12
    bcc .windowMap
    ldy #8
    lda (p0),y
    tax
    lda #65
    sta fireHeat,x
    iny
    lda (p0),y
    tax
    lda #49
    sta fireHeat,x
    iny
    lda (p0),y
    tax
    lda #17
    sta fireHeat,x
    iny
    lda (p0),y
    tax
    lda #1
    sta fireHeat,x
    lda tmp2
    beq .finish
    lda level
    cmp #2
    bcc .oldResidents
    ldx #0
.newResident
    lda fireHeat,x
    bne .newNext
    lda #160
    sta fireHeat,x
    dec tmp2
    beq .finish
.newNext
    inx
    cpx #12
    bcc .newResident
    bcs .finish
.oldResidents
    ldx #11
.resident
    lda fireHeat,x
    bne .next
    lda #$E0
    sta fireHeat,x
    dec tmp2
    beq .finish
.next
    dex
    bpl .resident
.finish
    ldy #12
    lda (p0),y
    sta residentQuota
    jmp FromLevel
    include "src/levels.inc"
Kernel
    SUBROUTINE
    lda #C0E
    sta COLUP0
    sta COLUP1
    lda #0
    sta CTRLPF
    ldy #7
    jsr DrawDigits
    ; Prepare the second HUD row within a single scanline.
    sta WSYNC
    lda hud+6
    clc
    adc #<Digit0
    sta p0
    lda hud+7
    clc
    adc #<Digit0
    sta p1
    lda hud+8
    clc
    adc #<Digit0
    sta p2
    lda hud+9
    clc
    adc #<Digit0
    sta p3
    lda hud+10
    clc
    adc #<Digit0
    sta p4
    lda hud+11
    clc
    adc #<Digit0
    sta p5
    sta WSYNC
    lda #C9C
    sta COLUP0
    sta COLUP1
    ldy #7
    jsr DrawDigits
    lda mode
    cmp #2
    bne .normalBar
    jmp CallClearKernel
.normalBar
    sta WSYNC
    lda #0
    sta GRP0
    sta GRP1
    sta PF0
    sta PF2
    lda waterMask
    sta PF1
    lda #C9C
    sta COLUPF
    lda #1
    sta CTRLPF
    lda #<WindCalm
    sta p0
    lda #>WindCalm
    sta p0+1
    lda wind
    beq .windReady
    bmi .westArrow
    cmp #2
    bne .eastArrow
    lda frame
    and #$80
    bne .westArrow
.eastArrow
    lda #<WindEast
    sta p0
    jmp .windReady
.westArrow
    lda #<WindWest
    sta p0
.windReady
    lda #$16
    sta NUSIZ1
    lda #C2E
    sta COLUP1
    lda eventType
    bne .noRoofMarker
    lda brickWarn
    beq .noRoofWarning
    and #4
    beq .noRoofWarning
    lda #2
    bne .noRoofWarning
.noRoofMarker
    lda #0
.noRoofWarning
    sta ENAM1
    ldy #0
.bar
    sta WSYNC
    lda waterMask
    sta PF1
    lda (p0),y
    tax
    REPEAT 15
    nop
    REPEND
    stx PF1                ; c46: change only the right half to the wind arrow
    iny
    cpy #5
    bne .bar
    lda #0
    sta PF1
    lda #C06
    sta COLUPF
    lda #0
    sta PF1
    sta PF2
    lda level
    and #3
    asl
    asl
    sta tmp
    ldy #3
.sky
    sta WSYNC
    ldx SceneFloor0,y
    lda artIndex,x
    tax
    lda SceneArtCap,x
    sta hud,y
    ldx SceneFloor1,y
    lda artIndex,x
    tax
    lda SceneArtCap,x
    sta hud+4,y
    ldx SceneFloor2,y
    lda artIndex,x
    tax
    lda SceneArtCap,x
    sta hud+8,y
    dey
    bne .sky
    sta WSYNC
    lda #128
    sta hud
    sta hud+4
    sta hud+8
    lda eventType
    cmp #2
    bne .cachesReady
    lda brickY
    cmp #142
    bcc .gapCache
    sec
    sbc #113
    ora #128
    ldx brickWarn
    sta hud,x
    jmp .cachesReady
.gapCache
    ldx brickY
    lda GapFloor-56,x
    bmi .cachesReady
    tay
    lda brickY
    sec
    sbc GapBottom,y
    clc
    adc #64
    pha
    tya
    ora brickWarn
    tay
    pla
    sta hud,y
.cachesReady
    ; Roof coping and the three composite 16-pixel window positions.
    sta WSYNC
    lda #0
    sta ENAM1
    lda #0
    sta PF0
    lda #0
    sta PF1
    sta PF2
    lda #C08
    sta COLUPF
    lda #6
    sta NUSIZ0
    lda #$16
    sta NUSIZ1
    lda #40
    ldx #0
    jsr StreetPosition
    lda #48
    ldx #1
    jsr StreetPosition
    sta WSYNC
    sta HMOVE
    lda #0
    sta floor
    jmp ToFloors

    include "src/street.asm"

; 6 independently changed player images, 3 hardware copies each.
; Writes GRP0/1 at cycles 21/29/37/45/53/56, before each corresponding copy.
    align 64
DrawDigits
    SUBROUTINE
.digit
    sta WSYNC
    nop
    nop
    nop
    lda (p5),y
    tax
    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
    dey
    bpl .digit
    rts

StreetPosition
    SUBROUTINE
    sec
    sbc #3
    bcs .coordinate
    lda #0
.coordinate
    sta WSYNC
    sec
.posLoop
    sbc #15
    bcs .posLoop
    eor #7
    asl
    asl
    asl
    asl
    sta HMP0,x
    sta RESP0,x
    rts
    align 32
SceneFloor0 byte 0,3,6,9
SceneFloor1 byte 1,4,7,10
SceneFloor2 byte 2,5,8,11
SceneArtCap byte 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,16,32,16,32
WindCalm byte 0,0,$18,0,0
WindEast byte $20,$40,$FF,$40,$20
WindWest byte $04,$02,$FF,$02,$04
    include "src/scene_gap_data.inc"
    include "src/sprites.inc"
    include "src/clear_kernel.asm"
    echo "Level/HUD/street bytes:",(*-$F000)
    ORG $3E00
    RORG $FE00
JumpStreet
    ds 64,0
    byte $66,$24,$24,$3C,$3C,$7E,$DB,$99,$18,$3C,$3C,$18
    ds 116,0
    byte $66,$24,$24,$3C,$3C,$7E,$DB,$99,$18,$3C,$3C,$18
    ds 52,0
    ORG $3F00
    RORG $FF00
    include "src/street_positions.inc"
    ORG $3FA0
    GAPGATES StreetAfterPosition
    ORG $3FB0
    GATES
    ORG $3FFA
    RORG $FFFA
    word ResetGate,ResetGate,ResetGate
    echo "RAM end:",ramEnd


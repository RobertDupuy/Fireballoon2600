; Resident mechanics share the existing airborne-event slot. This keeps
; the original 118-byte RAM footprint and prevents competing falling hazards.
; 96 four-frame patience ticks give 6.4 seconds before jumping.
; The last 32 ticks give a 2.1-second urgent wave and audible warning.
Features
    SUBROUTINE
    lda mode
    cmp #1
    beq .play
    rts
.play
    lda eventType
    cmp #2
    beq .jumper
.residentsCheck
    lda level
    cmp #2
    bcc .done
    lda frame
    and #3
    bne .done
    ldx #11
.residents
    lda fireHeat,x
    cmp #160
    bcc .next
    cmp #255
    beq .ready
    inc fireHeat,x
    lda fireHeat,x
    cmp #224
    bne .next
    lda #8
    jsr Sfx                   ; warning: about two seconds remain to shoot safely
    jmp .next
.ready
    lda brickY
    bne .next
    lda #0
    sta fireHeat,x
    lda #2
    sta eventType
    lda TargetY,x
    clc
    adc #9
    sta brickY
    lda TargetX,x
    sec
    sbc #8
    sta brickX
    txa
.mod3
    cmp #3
    bcc .column
    sbc #3
    bcs .mod3
.column
    asl
    asl
    sta brickWarn             ; pointer offset 0/4/8, not a masonry warning
    lda #8
    jsr Sfx
    rts
.next
    dex
    bpl .residents
.done
    rts
.jumper
    lda frame
    and #1
    bne .done
    inc brickY
    lda brickY
    cmp #178
    bcc .aboveGround
    jmp MissResident          ; a missed resident is the same failure as dying
.aboveGround
    cmp #166
    bcc .done
    lda streetPose
    cmp #4
    bne .done                 ; standing underneath alone never catches
    lda brickX
    sec
    sbc manX
    clc
    adc #4
    cmp #17
    bcs .done
.catch
    lda #0
    sta eventType
    sta brickY
    sta brickWarn
    ; Never chain an immediate jump from across the street after a catch.
    ldx #11
.catchGrace
    lda fireHeat,x
    cmp #224
    bcc .catchNext
    lda #224
    sta fireHeat,x
.catchNext
    dex
    bpl .catchGrace
    lda #$00
    jsr AddHundred
    lda #$00
    jsr AddHundred
    lda #$00
    jsr AddHundred
    lda #$00
    jsr AddHundred
    lda #$00
    jsr AddHundred
    lda #9
    jmp Sfx

; New residents replenish the emergency throughout a call, not only at its start.
; A quota guarantees each call ends; at most two residents are active at once.
ResidentArrivals
    SUBROUTINE
    lda residentQuota
    beq .done
    lda count
    beq .check
    lda frame
    and #127
    bne .done
.check
    ldy #0
    lda eventType
    beq .windows
    iny
.windows
    ldx #11
.count
    lda fireHeat,x
    cmp #160
    bcc .nextCount
    iny
.nextCount
    dex
    bpl .count
    cpy #2
    bcs .done
    lda random
    and #7
    tax
    ldy #12
.find
    lda fireHeat,x
    beq .spawn
    inx
    cpx #12
    bcc .nowrap
    ldx #0
.nowrap
    dey
    bne .find
.done
    rts
.spawn
    lda #160
    sta fireHeat,x
    dec residentQuota
    rts

StreetKernel
    SUBROUTINE
    ; Road row 142: continue P0 foreground copies through the bank handoff.
    sty ENABL                 ; Y=0; disable facade objects before visible pixels
    sty ENAM1
    ldx hud
    lda JumpStreet+35,x
    sta GRP0                  ; c29, still before the first resident at x40
    ldx hud+4
    lda JumpStreet+35,x
    sta GRP0
    nop
    ldx hud+8
    lda JumpStreet+35,x
    sta GRP0
    lda #>Man0
    sta spritePtr+1
    sta colorPtr+1
    lda #<Man0
    sta spritePtr
    lda #<ManColors
    sta colorPtr
    lda #3
    sta palette
    nop
    ; Row 143: choose the street object and preserve the resident above it.
    lda brickY
    cmp #142
    bcc .bucketPosition
    lda brickX
    sta waterMask
    lda eventType
    bne .singleObject
    lda #6
    bne .objectSize
.bucketPosition
    lda manX
    clc
    adc #6
    sta waterMask
.singleObject
    lda #0
.objectSize
    sta NUSIZ1
    ldx hud
    lda JumpStreet+34,x
    sta GRP0
    ldx hud+4
    lda JumpStreet+34,x
    sta GRP0
    ldx hud+8
    lda JumpStreet+34,x
    sta GRP0
    lda #$FF
    sta PF1
    sta PF2
    lda #C0E
    sta COLUPF
    sta WSYNC
    ; Row 144: fine/coarse positioning is prepared outside its drawing row.
    ldx waterMask
    lda StreetPackedPosition,x
    pha
    and #15
    tax
    lda StreetGapLo,x
    sta tmp
    stx p0
    ldx hud
    lda JumpStreet+33,x
    sta GRP0
    ldx hud+4
    lda JumpStreet+33,x
    sta GRP0
    ldx hud+8
    lda JumpStreet+33,x
    sta GRP0
    ldx p0
    lda StreetGapHi,x
    sta tmp2
    pla
    and #$F0
    sta HMP1
    sta WSYNC
    ; Row 145: next position row's three bytes and a full-height resident pointer.
    ldx hud
    lda JumpStreet+30,x
    sta row
    ldx hud+4
    lda JumpStreet+30,x
    sta anim
    ldx hud
    lda JumpStreet+32,x
    sta GRP0
    ldx hud+4
    lda JumpStreet+32,x
    sta GRP0
    ldx hud+8
    lda JumpStreet+32,x
    sta GRP0
    ldx hud+8
    lda JumpStreet+30,x
    sta warn
    ldx brickWarn
    lda hud,x
    sta ballPtr
    sta WSYNC
    ; Row 146: preselected artwork keeps all foreground deadlines identical.
    ldx streetPose
    lda StreetPoseLo,x
    sta spritePtr
    lda StreetColorLo,x
    sta colorPtr
    bit frame
    nop
    ldx hud
    lda JumpStreet+31,x
    sta GRP0
    nop
    ldx hud+4
    lda JumpStreet+31,x
    sta GRP0
    nop
    ldx hud+8
    lda JumpStreet+31,x
    sta GRP0
    sty PF1
    sty PF2
    ldx #1
    jmp ToGapPosition
StreetAfterPosition
    ; Row 148: P1 now owns the falling resident. P0 can become the player.
    ldx streetPose
    lda StreetSizes,x
    sta NUSIZ0
    lda #0
    sta GRP0
    ldy #29
    lda (ballPtr),y
    sta GRP1
    lda #C3E
    sta COLUP1
    sta HMCLR
    ldx manX
    lda StreetPackedPosition,x
    pha
    and #15
    tax
    pla
    and #$F0
    sta HMP0
    sta WSYNC
    ; Row 149: P1 is updated before the variable-delay P0 positioning loop.
    ldy #28
    lda (ballPtr),y
    sta GRP1
    nop
.manPosition
    dex
    bpl .manPosition
    bit frame
    nop
    sta RESP0
    sta WSYNC
    sta HMOVE
    lda #C82
    sta COLUBK
    lda facing
    sta REFP0
    ldy #27
    lda (ballPtr),y
    sta GRP1
    lda level
    and #3
    tax
    lda StreetBanks,x
    sta palette
    lda eventType
    cmp #2
    bne .ordinaryMan
    lda brickY
    cmp #142
    bcc .ordinaryMan
    dey
.residentMan
    sta WSYNC
    lda (spritePtr),y
    sta GRP0
    lda (colorPtr),y
    sta COLUP0
    lda (ballPtr),y
    sta GRP1
    dey
    bpl .residentMan
    jmp .roadEnd
.ordinaryMan
    lda #C9C
    sta COLUP1
    dey
.man
    sta WSYNC
    lda (spritePtr),y
    sta GRP0
    lda (colorPtr),y
    sta COLUP0
    lda brickY
    cmp #142
    bcs .brick
    lda streetPose
    cmp #4
    beq .noBucket
    lda pose
    cmp #5
    bcc .bucket
    cmp #9
    bcs .bucket
    lda BucketThrow,y
    jmp .object
.noBucket
    lda #0
    beq .object
.bucket
    lda Bucket,y
.object
    sta GRP1
    jmp .nextRow
.brick
    sty row
    lda #185
    sec
    sbc brickY
    sec
    sbc row
    cmp #4
    lda #0
    bcs .brickOff
    lda #$F0
.brickOff
    sta GRP1
    lda #C28
    sta COLUP1
.nextRow
    dey
    bpl .man
.roadEnd
    sta WSYNC
    lda #0
    sta GRP0
    sta GRP1
    lda #$55
    sta PF1
    lda #$AA
    sta PF2
    lda #C0E
    sta COLUPF
    sta WSYNC
    lda #0
    sta PF1
    sta PF2
.waitDisplay
    lda INTIM
    bne .waitDisplay
    jmp ToLogic
StreetPoseLo byte <Man0,<Man1,<Man2,<Man3,<ManCatch
StreetColorLo byte <ManColors,<ManColors,<ReachColors,<ManColors,<CatchColors
StreetSizes byte 0,0,0,0,5

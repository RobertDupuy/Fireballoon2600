"""Compile-time PAL colors: no extra instructions in the display kernel."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PAL_HUES = (0x00, 0x20, 0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0,
            0xD0, 0xB0, 0x90, 0x70, 0x50, 0x30, 0x30, 0x20)

def color_name(value):
    return f'C{value:02X}'

def color_loads(source):
    """Name immediate TIA color loads; deferred loads use color_name."""
    return re.sub(r'lda #\$([0-9A-Fa-f]{2})(\s+sta COLU[PB][0-9KF]?)',
                  lambda m: 'lda #' + color_name(int(m[1], 16)) + m[2], source)

def generate():
    source = '''; Generated television constants. Color names use NTSC codes.
    IFNCONST PAL
PAL = 0
    ENDIF
    IF PAL
OVERSCAN_TIMER = 63
VBLANK_TIMER = 70
    ELSE
OVERSCAN_TIMER = 39
VBLANK_TIMER = 35
    ENDIF
'''
    for value in range(0, 256, 2):
        pal = PAL_HUES[value >> 4] | (value & 15)
        source += (f'    IF PAL\nC{value:02X} = ${pal:02X}\n'
                   f'    ELSE\nC{value:02X} = ${value:02X}\n    ENDIF\n')
    (ROOT / 'src/tv.inc').write_text(source)

if __name__ == '__main__':
    generate()

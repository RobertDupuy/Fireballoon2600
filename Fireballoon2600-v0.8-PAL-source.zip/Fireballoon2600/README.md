# Fireballoon 2600 — v0.8 PAL

Created by **Mark2006**. Three buildings, four street layouts, twenty calls.

**32 KiB standard F4 cartridge, PAL 50 Hz, 312 scanlines.** Native 6507,
TIA and RIOT RAM. No cartridge RAM or extra processor.

## Play

Open `Fireballoon2600-v0.8-PAL.bin` in Stella, or use a cartridge supporting
standard **F4**, without Superchip RAM. Select PAL if the emulator does not
choose it automatically. Use the left joystick.

| Input | Action |
| --- | --- |
| Left / right | Move |
| Hold DOWN | Open the catching blanket; movement and throwing stop |
| Release DOWN | Move and throw again |
| Tap FIRE | Pick up and throw one water balloon |
| Release FIRE | Rearm for the next throw |
| SELECT | Pause / resume |
| RESET | Start a new game |

One tap during recovery queues a throw. Holding FIRE does not repeat. The
bucket holds eight balloons and refills automatically in one second (50 PAL
frames). Refilling continues while catching. The blue bar shows water and
refill progress. White digits show score; blue numbers show call, seconds
and lives. The arrow indicates wind direction.

Clear all fires, residents and remaining outbreaks before time runs out.
Occupied lower windows intercept balloons aimed at higher windows. Larger
fires need more hits. The final oversized stage remains extinguishable.
If a fire destroys a building, every real window in that building erupts for
1.5 seconds, followed by a floor-by-floor collapse of that building only.

Residents begin jumping on call 3. There are three residents in calls 3–6,
four in calls 7–12 and five in calls 13–20, with at most two active at once.
A resident waits about 6.4 seconds before jumping. Faster waving and sound
mark the last 2.1 seconds. A balloon can rescue them at the window throughout
this period. Once they jump, put the center of the blanket underneath them
and hold DOWN. A catch gives another urgent resident at least two seconds
before their next jump. Falling masonry or another airborne resident may
also extend a resident's wait.

You begin with three lives. A missed resident, masonry hit, building burning
down or timeout costs one life and retries the current call. Masonry gives
a 0.75-second audible warning, then falls in three pieces; move into the gaps.
Flying embers and rooftop reservoirs remain removed.

| Action | Points |
| --- | --- |
| Weaken a fire | 20 |
| Extinguish a fire | 100, plus a 10–90-point streak bonus |
| Rescue at a window | 250 |
| Catch a falling resident | 500 |
| Clear a call | 10 per remaining second |

A missed balloon breaks the extinguishing streak.

## PAL conversion

PAL displays 312 scanlines per picture at nominally 50 Hz. The game still
processes 60 simulation ticks per second: six original ticks for every five
PAL pictures. Each tick processes movement, input edges and collisions.
The additional tick occupies vertical blank, outside the beam-timed kernel.

This preserves the original movement, fire growth, warning periods, refills,
animations and sound-envelope pace. Refilling takes 50 PAL frames; resident
patience is 320 PAL frames; the building-wide eruption is 75 PAL frames.
Authoring tables in `design.json` still express frame durations in original
60-Hz simulation ticks, not PAL video frames.

`tv.py` remaps colors at assembly time, including all four streets, flames,
character, blanket, balloons, title, HUD and endings. The display instructions
retain their original cycle counts. PAL's native audio clock is retained;
its small pitch difference is not artificially quantized away.

RAM use is 119 bytes in PAL, including one byte for the simulation cadence,
leaving nine bytes for the stack. NTSC still uses 118 bytes. There is no
cartridge RAM or coprocessor. Each bank retains reset vectors and gates.

## Build

Install Python 3 and DASM. Set `DASM` to the assembler executable if needed.

```sh
python3 build.py --tv pal
```

The output is `build/Fireballoon2600-PAL.bin`, with symbols and a listing.
PAL is the default. `python3 build.py --tv ntsc` reproduces the original v0.8
NTSC cartridge byte for byte, SHA-256:
`063e6930ef85fb77369a9aa15dcccbfa24335e4afbfb02825ce14ee3d27e3d80`.

`art_v08.py` authors sprites and levels; `street_design.py` defines the streets.
`make_facade.py`, `make_street.py`, `make_title.py` and `make_position.py`
generate beam-timed display code. `src/engine.asm` and `src/features.asm`
implement the rules. `tv.py` generates `src/tv.inc`. All generated assembly
is included.

## Verification

The `validation/` reports identify the exact PAL ROM SHA-256. Tests use native
Stella 7.0_pre/libretro at commit
`ba52c43b9eda950eb0c0eec69cda9b17dee8c39b`, with the supplied observation patch.

```sh
python3 -m pip install numpy pillow
python3 tests/build_stella.py
python3 build.py --tv pal
python3 tests/verify_pal.py
python3 tests/expert_player.py
python3 tests/replay.py
python3 package.py
```

`STELLA_CORE` may identify an existing patched core. Run each script in its
own process. The PAL fixtures write RAM to isolate mechanics. They measure
countdown, movement, refill, fire growth, resident patience, catches and
collapse phases in PAL frames; compare window pixels against ROM data;
check six player writes on each of the 64 window rows; inspect all 1,464
resident-height/layout/column combinations; and stress double-tick paths
while guarding the stack. All 101 checks passed at 312 scanlines.

The campaign and independent replay use joystick input only, with no game
state writes, saves or rewinds. Both completed all 20 calls with three lives
remaining. Every measured campaign and replay frame was 312 scanlines. This
establishes a winning route, not a measure of human difficulty.

The older `verify_core.py`, `verify_features.py`, `verify_streets.py`,
`verify_escalation.py`, `individual_calls.py` and `record_movie.py` are NTSC
regression tools containing NTSC frame counts and viewport coordinates.
Use them after building `--tv ntsc`. Rebuild PAL before PAL validation and
packaging. Physical PAL-console testing remains outstanding.

Hardware references:
- Atari Stella Programmer's Guide, PAL/SECAM conversions:
  https://www.atariage.com/2600/programming/2600_101/docs/stella.html
- Stella's pinned `src/common/PaletteHandler.cxx` and native TIA traces for
  color and display verification.

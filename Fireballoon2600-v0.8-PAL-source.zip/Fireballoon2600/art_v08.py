from tv import color_name
from pathlib import Path
import math,json
from street_design import STREETS, present
ROOT=Path(__file__).resolve().parent
S=ROOT/'src'
def emit(name,a,align=0,colors=False):
 t=('    align '+str(align)+'\n') if align else ''
 t+=name+':\n'
 for i in range(0,len(a),16):t+='    byte '+','.join((color_name(v) if colors else f'${v&255:02x}') for v in a[i:i+16])+'\n'
 return t

def generate():
 art=[];out=''
 for stage in range(9):
  for phase in range(4):
   p=[[0]*16 for _ in range(20)]
   if stage==0:
    # Quiet windows: recessed top glint, otherwise an unobstructed blue aperture.
    for x in range(2,14):p[0][x]=1
    for x in range(4,12):p[1][x]=1
   elif stage<=4:
    h=[0,8,12,16,19][stage]
    # Three broad, curling tongues: coherent silhouettes, not pixel noise.
    for k,(cx,scale) in enumerate([(3,.72),(8,1.0),(12,.8)]):
     ht=max(3,round(h*scale)+[0,1,0,-1][(phase+k)%4])
     for y in range(19-ht,20):
      t=(19-y)/ht
      lean=round(math.sin(t*3+phase*1.57+k)*t*1.8)
      width=max(0,round((1-t)*2.3))
      for x in range(cx+lean-width,cx+lean+width+1):
       if 0<x<15:p[y][x]=1
    for x in range(2,14):p[18][x]=1
    for x in range(1,15):p[19][x]=1
    # A single clean dark curl opens inside the tallest flame.
    if stage>=3:
     xx=7+(phase&1)
     for yy in range(12,16):p[yy][xx]=0
   elif stage==5:
    rows=[0,0,0,0x0180,0x03c0,0x03c0,0x0180,0x0180,0x03c0,0x07e0,0x0bd0,0x13c8,0x03c0,0x03c0,0x0240,0x0240,0x0660,0,0,0]
    arms=[[0x43c0,0x27e0,0x1bd0,0x03c8],[0x03c2,0x07e4,0x0bd8,0x13c0],[0x43c2,0x27e4,0x1bd8,0x03c0],[0x23c0,0x17e0,0x0bd0,0x03c8]]
    rows[8:12]=arms[phase];p=[[(v>>(15-x))&1 for x in range(16)] for v in rows]
   elif stage==7:
    pass  # Empty sky, also used for missing windows.
   elif stage==8:
    # Critical inferno: nearly the entire aperture burns, with a separate
    # 12-scanline flame crown above it in the floor-gap kernel.
    rows=([0x4102,0x6386,0x678e,0xef9e,0xefdc,0xfffc,0xfdfc,0xf9fe,
           0xf93e,0xfb3e,0xff3e,0xffbe,0xfffe,0xfffc,0xfffe,0xffff,
           0xffff,0xfffe,0xffff,0xffff] if not phase&1 else
          [0x0220,0x0632,0x8e76,0xce7e,0xfefe,0xfeff,0xfe7e,0xfc7e,
           0xfc7f,0xfcff,0xfcfe,0xfefe,0xfffe,0xffff,0xfffe,0xffff,
           0xffff,0xffff,0xffff,0xffff])
    p=[[(v>>(15-x))&1 for x in range(16)] for v in rows]
   else:
    rad=[7,5,3,1][phase]
    for dx,dy in [(1,0),(-1,0),(0,1),(0,-1),(1,1),(1,-1),(-1,1),(-1,-1)]:
     x=7+dx*rad;y=10+dy*rad
     if 0<=x<16 and 0<=y<20:
      p[y][x]=1
      if x+1<16:p[y][x+1]=1
    if phase>=2:
     for y in range(9,12):
      for x in range(6,10):p[y][x]=1
   for half in range(2):
    rows=[sum(p[y][x+half*8]<<(7-x) for x in range(8)) for y in range(20)]
    name=f'Art{stage}_{phase}_{half}';art.append(name)
    if stage in (0,7) and phase:out+=f'{name} = Art{stage}_0_{half}\n'
    elif stage==8 and phase>=2:out+=f'{name} = Art8_{phase&1}_{half}\n'
    else:out+=('    IF (>*) != (>(*+31))\n    align 256\n    ENDIF\n' if half==0 else '')+emit(name,list(reversed([rows[round(y*19/15)] for y in range(16)])))
 for name,expr in [('ArtLeftLo','<'),('ArtRightLo','<'),('ArtPage','>')]:
  ns=art[1::2] if name=='ArtRightLo' else art[::2]
  out+='    align 64\n'+name+'\n    byte '+','.join(expr+n for n in ns)+'\n'
 out += emit('ArtCap',[0]*32+[16,32,16,32])
 # A separate pointer entry for empty sky above shorter buildings.
 for label,half in [('SkyLeftLo',0),('SkyRightLo',1)]:
  out += label+' = <Art7_0_'+str(half)+'\n'
 (S/'flames.inc').write_text(out)
 # Readable red hat, white brim, striped shirt, blue trousers, animated hands/feet.
 stand=[0,0x18,0x3c,0x7e,0x3e,0x3c,0x18,0x1c,0x18,0x3c,0x7e,0x5c,0x58,0x3c,0x3c,0x3c,0x3c,0x24,0x24,0x24,0x24,0x24,0x66,0x66,0,0,0,0]
 poses=[stand,stand[:17]+[0x24,0x42,0x42,0x81,0x81,0xc3,0xc3,0,0,0,0],
 [0,0,0,0,0x18,0x3c,0x7e,0x3e,0x3c,0x18,0x3c,0x3e,0x3f,0x3f,0x3d,0x3d,0x25,0x24,0x24,0x24,0x24,0x24,0x66,0x66,0,0,0,0],
 [0x03,0x1b,0x3d,0x7d,0x3d,0x39,0x1b,0x1e,0x1c,0x3c,0x7c,0x5c,0x58,0x3c,0x3c,0x3c,0x3c,0x24,0x24,0x24,0x24,0x24,0x66,0x66,0,0,0,0],
 stand[:17]+[0x3c,0x18,0x18,0x18,0x24,0x66,0x66,0,0,0,0],
 stand[:17]+[0x24,0x42,0x42,0x24,0x18,0x3c,0x3c,0,0,0,0]]
 colors=[0,0x46,0x46,0x0e,0x3e,0x3e,0x3e,0x3e,0x0e,0x0e,0x46,0x46,0x0e,0x0e,0x46,0x46,0x0e,0x96,0x96,0x96,0x96,0x96,0x0e,0x0e,0,0,0,0]
 reachcolors=[0,0,0,0,0x46,0x46,0x0e,0x3e,0x3e,0x3e,0x0e,0x46,0x3e,0x3e,0x0e,0x46,0x0e,0x96,0x96,0x96,0x96,0x96,0x0e,0x0e,0,0,0,0]
 out=''
 for i,a in enumerate(poses[:4]):out+=emit('Man'+str(i),list(reversed(a))+[0]*4,256 if i==0 else 32)
 # Double-width P0: crouched catcher, raised hands, a broad cyan blanket.
 catch=[0]*4+[0x08,0x1c,0x1e,0x0c,0x0c,0x08,0x0c,0x1e,0x3f,0x7f,0x81,0xff,0x7e,0x3c,0x3c,0x24,0x24,0x24,0x66,0x66,0,0,0,0]
 catchcolors=[0]*4+[0x46,0x46,0x0e,0x3e,0x3e,0x3e,0x3e,0x0e,0x46,0x46,0x3e,0x9e,0x9c,0x9a,0x96,0x96,0x96,0x96,0x0e,0x0e,0,0,0,0]
 out+=emit('ManCatch',list(reversed(catch))+[0]*4,32)+emit('CatchColors',list(reversed(catchcolors))+[0]*4,32,colors=True)
 out+=emit('ManColors',list(reversed(colors))+[0]*4,32,colors=True)+emit('ReachColors',list(reversed(reachcolors))+[0]*4,32,colors=True)
 bucket=[0]*15+[0x3c,0x42,0x42,0x7e,0x66,0x66,0x66,0x66,0x3c,0,0,0,0]
 held=bucket[:];held[0:6]=[0xc0,0xe0,0xf0,0xf0,0xe0,0x40]
 out+=emit('Bucket',list(reversed(bucket))+[0]*4,32)+emit('BucketThrow',list(reversed(held))+[0]*4,32)
 digits=[[14,17,19,21,25,17,14],[4,12,4,4,4,4,14],[14,17,1,2,4,8,31],[30,1,1,14,1,1,30],[2,6,10,18,31,2,2],[31,16,16,30,1,1,30],[14,16,16,30,17,17,14],[31,1,2,4,8,8,8],[14,17,17,14,17,17,14],[14,17,17,15,1,1,14]]
 for i,a in enumerate(digits):out+=emit('Digit'+str(i),list(reversed([v<<2 for v in a]+[0])),128 if i==0 else 8)
 (S/'sprites.inc').write_text(out)
 # Collision maps avoid scanning 12 targets for each projectile.
 hitrow=[255]*256
 for y,row in [(47,0),(75,3),(103,6),(131,9)]:
  for yy in range(y,y+5):hitrow[yy]=row
 hitcol=[255]*256
 for x,col in [(48,0),(80,1),(112,2)]:
  for xx in range(x-8,x+9):hitcol[xx]=col
 (S/'collisions.inc').write_text(emit('HitRow',hitrow,256)+emit('HitColumn',hitcol,256)+emit('HeatArt',[0 if v==0 else 28 if v==128 else 20 if v>=128 else 32 if v>=113 else 4*((v-1)//32+1) for v in range(256)],256))
 # Every street has separate silhouettes; inactive windows are $80 sentinels.
 levels=[]; manifest=[]
 for i in range(20):
  street=STREETS[i%4]
  valid=[j for j in range(12) if present(street,j)]
  # Threat positions vary across calls, with no impossible fire in the sky.
  openings=[
   [1,6,8,10], [0,5,10,9], [4,6,11,7], [2,6,10,5],
   [3,8,10,1], [2,9,7,3], [1,8,9,10], [0,8,10,3],
  ][i%8]
  assert all(j in valid for j in openings)
  seconds=30 if i==0 else 32+i
  if i>=4:seconds+=6
  if i>=7:seconds+=4
  if i==17:seconds+=4
  waves=10+i//2
  period=[88,96,92,104][i] if i<4 else 114-i
  growth=5
  wind=[0,0,1,255,2,0,1,255,2,1,255,2,0,2,1,255,2,1,255,2][i]
  bricks=max(90,165-i*4)
  residents=0 if i==0 else 1 if i<10 else 2
  # 16-byte records retain the bank loader's inexpensive lookup.
  levels += [seconds//10*16+seconds%10,waves,period,growth,wind,bricks,
             residents,street['bank'],*openings,
             (3 if i<6 else 4 if i<12 else 5)-residents if i>=2 else 0,0,0,0]
  manifest.append(dict(call=i+1,street=street['name'],bank=street['bank'],
                       heights=street['heights'],windows=len(valid),seconds=seconds,
                       outbreaks=waves,outbreak_frames=period,growth_tick_frames=growth,
                       growth_stage_seconds=32*growth/60,wind=wind,
                       masonry_interval_frames=bricks,residents=residents,openings=openings,
                       jumping_residents=i>=2,resident_jump_delay_frames=384 if i>=2 else None,
                       resident_total=(3 if i<6 else 4 if i<12 else 5) if i>=2 else residents,
                       catch_requires_down=True,catch_locks_horizontal_movement=True))
 flags=[]
 for bank in range(8):
  street=next((v for v in STREETS if v['bank']==bank),None)
  flags += [0 if street and present(street,j) else 128 for j in range(12)]+[128]*4
 (S/'levels.inc').write_text(emit('Levels',levels,256)+emit('WindowFlags',flags,128))
 (ROOT/'design.json').write_text(json.dumps(manifest,indent=2)+'\n')
 # All title lettering is generated as sprite bits, never playfield text.
 tiny=dict(zip('0123456789',['111101101101111','010110010010111','111001111100111','111001111001111','101101111001001','111100111001111','111100111101111','111001010010010','111101111101111','111101111001111']))
 tiny.update(dict(zip('ABCDEFGHIJKLMNOPQRSTUVWXYZ',['010101111101101','110101110101110','011100100100011','110101101101110','111100110100111','111100110100100','011100101101011','101101111101101','111010010010111','001001001101010','101101110101101','100100100100111','101111111101101','101111111111101','010101101101010','110101110100100','010101101111011','110101110101101','011100010001110','111010010010010','101101101101111','101101101101010','101101111111101','101101010101101','101101010010010','111001010100111'])))
 tiny[' ']='0'*15
 titleframes=[]
 for kind,hh in [(0,120),(1,96),(2,96),(3,96),(4,80)]:
  pp=[[0]*48 for _ in range(hh)]
  def box(x,y,w,h):
   for yy in range(max(0,y),min(hh,y+h)):
    for xx in range(max(0,x),min(48,x+w)):pp[yy][xx]=1
  def text(t,y,sx=1,sy=2):
   x=(48-(len(t)*4-1)*sx)//2
   for ch in t:
    for yy in range(5):
     for xx in range(3):
      if tiny[ch][yy*3+xx]=='1':box(x+xx*sx,y+yy*sy,sx,sy)
    x+=4*sx
  if kind==0:
   text('FIRE',2,3,4)
   titlefont={'B':[30,17,17,30,17,17,30],'A':[14,17,17,31,17,17,17],
              'L':[16,16,16,16,16,16,31],'O':[14,17,17,17,17,17,14],
              'N':[17,25,25,21,19,19,17]}
   for ci,ch in enumerate('BALLOON'):
    for yy,v in enumerate(titlefont[ch]):
     for xx in range(5):
      if v&(16>>xx):box(3+ci*6+xx,27+yy*2,1,2)
   # Pixel-authored scene: masonry outline, four apertures, thrower, airborne balloon.
   for x,y,h in [(19,61,21),(29,49,33),(39,56,26)]:
    box(x,y,8,h);box(x-1,y,10,2)
    for wy in range(y+5,78,9):
     for yy in range(wy,wy+5):
      for xx in range(x+2,x+6):pp[yy][xx]=0
   box(18,82,30,2)
   for yy,v in enumerate(stand):
    for xx in range(8):
     if v&(128>>xx):box(7+xx,59+yy,1,1)
   for yy,v in enumerate([0x18,0x3c,0x7e,0x7e,0x3c,0x18,0x08]):
    for xx in range(8):
     if v&(128>>xx):box(8+xx,43+yy,1,1)
   box(1,88,46,1)
   text('CREATED BY',94,1,1);text('MARK2006',101,1,1);text('PRESS FIRE',111,1,1)
  elif kind==1:
   text('GAME',2,2,4);text('OVER',24,2,4);text('TRY AGAIN',55,1,3);text('PRESS FIRE',80,1,2)
  elif kind==2:
   text('ALL 20',3,1,4);text('CALLS CLEAR',28,1,3);text('CITY SAVED',52,1,3);text('MARK2006',78,1,2)
  elif kind==3:
   text('PAUSED',12,2,4);text('SELECT',55,1,3);text('TO RESUME',78,1,2)
  else:
   text('CALL',5,2,4);text('CLEAR',29,2,4);text('TIME BONUS',61,1,2)
  cs=[0x0e]*hh
  if kind==0:
   for yy in range(2,22):cs[yy]=[0x46,0x48,0x2a,0x2c,0x1e][(yy-2)//4]
   for yy in range(27,41):cs[yy]=[0x96,0x98,0x9a,0x9c,0x9e,0x0e,0x9c][(yy-27)//2]
   for yy in range(43,50):cs[yy]=0x9c
   for yy in range(49,85):cs[yy]=0x08 if yy%3==0 else 0x0a
   for yy in range(111,116):cs[yy]=0x1e
  elif kind==4:
   for yy in range(5,49):cs[yy]=0xca if yy<29 else 0xce
  titleframes.append({'bits':pp,'colors':cs})
 (S/'title_frames.json').write_text(json.dumps(titleframes))
if __name__=='__main__':generate()

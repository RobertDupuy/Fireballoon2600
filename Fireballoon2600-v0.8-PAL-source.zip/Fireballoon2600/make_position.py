"""Cycle-balanced positioning while P0 keeps drawing a foreground resident."""
from pathlib import Path
R=Path(__file__).resolve().parent
def packed(x):
    a=max(0,x-3); n=a//15+1
    a=(a-15*n)&255
    return (((a^7)<<4)&240)|(n-1)
def emit(name,vals):
    return name+'\n'+''.join('    byte '+','.join(f'${v:02X}' for v in vals[i:i+16])+'\n' for i in range(0,len(vals),16))
(R/'src/position_data.inc').write_text(emit('PackedPosition',[packed(i) for i in range(256)]))

# The standard Position routine strobes at CPU cycle 24+5*(n-1).
# A coarse reset can occur anywhere; GRP0 deadlines stay before all 3 copies.
def padding(cycles):
    assert cycles!=1 and cycles>=0,cycles
    s=''
    if cycles%2:s+='    bit frame\n';cycles-=3
    return s+'    nop\n'*(cycles//2)
s=''
for n in range(11):
    reset=24+5*n
    # Only positions through x=152 are used: the final coarse reset may
    # wrap to the following line. The final variant is unused by gameplay.
    if reset>71:reset=69
    # Find three nonoverlapping write slots, including the 4-cycle indexed reset.
    choices=[]
    for a in range(16,36):
     for b in range(40,47):
      for c in range(51,58):
       for load in range(a+3,c-2):
        events=[(a-3,a,'sta GRP0'),(b-3,b,'sty GRP0'),(load-3,load,'lda warn'),(c-3,c,'sta GRP0'),(reset-4,reset,'sta RESP0,x')]
        events.sort();t=6;ok=True
        for start,end,op in events:
            if start<t or start-t==1:ok=False;break
            t=end
        if ok and t<=69 and 69-t!=1:choices.append(events)
    assert choices,n
    events=choices[0]
    s+=f'GapPos{n}\n    lda row\n    ldy anim\n';t=6
    for start,end,op in events:
        s+=padding(start-t)+'    '+op+'\n';t=end
    s+=padding(69-t)+'    jmp FromGapPosition\n'
s+= 'GapPosLo byte '+','.join('<GapPos'+str(i) for i in range(11))+'\n'
s+= 'GapPosHi byte '+','.join('>GapPos'+str(i) for i in range(11))+'\n'
(R/'src/gap_positions.inc').write_text(s)

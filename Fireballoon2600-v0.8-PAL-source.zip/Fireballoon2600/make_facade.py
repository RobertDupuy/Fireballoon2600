from tv import color_loads, color_name
"""Native foreground resident: every scanline, including roof and floor bands."""
from pathlib import Path
from street_design import STREETS,playfield,roof_playfield
R=Path(__file__).resolve().parent
s='''    ORG $1000
    RORG $F000
FloorsKernel
    SUBROUTINE
    lda mode
    cmp #3
    bne .normal
    lda lossCause
    cmp #3
    bcs .normal
    lda transition
    cmp #151
    bcs .normal
    jmp CollapseFacadeKernel
.normal
    lda #>BrickMask
    sta ballPtr+1
    sta colorPtr+1
    sta spritePtr+1
    ldx artIndex
    lda ArtCap,x
    sta ballPtr
    ldx artIndex+1
    lda ArtCap,x
    sta colorPtr
    ldx artIndex+2
    lda ArtCap,x
    sta spritePtr
    lda #$2E
    sta COLUP0
    lda #0
    sta floor
    sta GRP1
    sta ENABL
    sta ENAM1
    ldy #11
    sta WSYNC
    REPEAT 8
    nop
    REPEND
    lda (ballPtr),y
    sta GRP0
    REPEAT 3
    nop
    REPEND
    lda (colorPtr),y
    sta GRP0
    REPEAT 3
    nop
    REPEND
    lda (spritePtr),y
    sta GRP0
    ldx #0
    jmp Gap0Finish
NextFloor
    inx
    stx floor
    lda hud,x
    sta ballPtr
    ldy #11
    lda (ballPtr),y
    sta GRP0
    lda hud+4,x
    sta colorPtr
    lda (colorPtr),y
    sta GRP0
    lda hud+8,x
    sta spritePtr
    lda (spritePtr),y
    sta GRP0
Gap0Finish
    lda SkyPF1,x
    sta PF1
    lda SkyPF2,x
    sta PF2
    sta WSYNC
'''
for col in range(3):
 s+=f'''    ; Gap {col+1}: next window's pointers; foreground writes at 25/40/55.
    ldx floor
    lda FloorFirst{col},x
    tax
    lda artIndex,x
    tax
    ldy #{10-col}
    lda (ballPtr),y
    sta GRP0
    lda ArtLeftLo,x
    sta p{2*col}
    lda (colorPtr),y
    sta GRP0
    lda ArtRightLo,x
    sta p{2*col+1}
    lda (spritePtr),y
    sta GRP0
    lda ArtPage,x
    sta p{2*col}+1
    sta p{2*col+1}+1
'''
 if col==0:s+='    lda #0\n    sta ENABL\n    sta ENAM1\n    sta HMCLR\n'
 if col==1:s+='    lda #$2E\n    sta COLUP0\n'
 if col!=0:s+='    sta WSYNC\n'
s+='''    ; Gap 4: pointer offset, folded into the zero-padded half-page.
    ldy floor
    lda brickY
    sec
    sbc KJumpOffset,y
    tax
    lda KJumpClamp,x
    sta waterMask
    ldy #7
    lda (ballPtr),y
    sta GRP0
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    lda eventType
    beq .noJumpOverlay
    lda waterMask
    beq .noJumpOverlay
    ldx brickWarn
    sta p0,x
    lda #>BrickMask
    sta p0+1,x
.noJumpOverlay
    sta WSYNC
    ; Gap 5: masonry membership, separate from the resident overlay.
    ldx brickY
    lda KBrickBand,x
    eor floor
    ora eventType
    sta waterMask
    ldy #6
    lda (ballPtr),y
    sta GRP0
    nop
    nop
    nop
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    ldx waterMask
    beq .masonryMask
    lda #0
    sta waterMask
    beq .maskDone
.masonryMask
    ldy floor
    lda brickY
    sec
    sbc KMasonryOffset,y
    sta waterMask
.maskDone
    sta WSYNC
    ; Gap 6: select a cycle-balanced horizontal positioning scanline.
    ldy floor
    lda ballBandX,y
    pha
    and #15
    tax
    lda KGapPosLo,x
    sta tmp
    ldy #5
    lda (ballPtr),y
    sta GRP0
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    lda KGapPosHi,x
    sta tmp2
    pla
    and #$F0
    sta HMBL
    ldy floor
    lda SolidPF1,y
    sta PF1
    ; Gap 7: keep all three foreground bytes for the positioning row.
    ldy #1
    lda (ballPtr),y
    sta row
    lda (colorPtr),y
    sta anim
    ldy #4
    lda (ballPtr),y
    sta GRP0
    bit frame
    lda (colorPtr),y
    sta GRP0
    bit frame
    lda (spritePtr),y
    sta GRP0
    ldy #1
    lda (spritePtr),y
    sta warn
    ldy floor
    lda SolidPF2,y
    sta PF2
    sta WSYNC
    ; Gap 8 begins at c0 without WSYNC; roof coping now crosses all buildings.
    ldy floor
    lda ballBandLo,y
    sta ballPtr
    lda #>BallMask
    sta ballPtr+1
    ldx hud,y
    lda BrickMask+3,x
    sta GRP0
    lda waterMask
    sta colorPtr
    ldx hud+4,y
    lda BrickMask+3,x
    sta GRP0
    ldx hud+8,y
    lda BrickMask+3,x
    sta GRP0
    lda #>BallMask
    sta colorPtr+1
    lda #$08
    sta COLUPF
    sta WSYNC
    ; Gap 9: fixed timing into the banked positioning routine.
    ldy floor
    REPEAT 5
    nop
    REPEND
    ldx hud,y
    lda BrickMask+2,x
    sta GRP0
    nop
    nop
    ldx hud+4,y
    lda BrickMask+2,x
    sta GRP0
    ldx hud+8,y
    lda BrickMask+2,x
    sta GRP0
    ldx #4
    REPEAT 5
    nop
    REPEND
    jmp ToGapPosition
GapAfterPosition
    ; Gap 11: return at c14, apply fine positioning, then enter the facade.
    ldy floor
    bit frame
    nop
    ldx hud,y
    lda BrickMask,x
    sta GRP0
    ldx hud+4,y
    lda BrickMask,x
    sta GRP0
    ldx hud+8,y
    lda BrickMask,x
    sta GRP0
    lda #$06
    sta COLUP0
    sta COLUP1
    ldy #15
    lda (p5),y
    tax
    lda #$88
    sta COLUPF
    nop
'''
# Body geometry is changed at the end of the last gap row with a dedicated
# preceding row. This preserves the original 28-line floor pitch.
# Gap 9 has spare cycles before its first GRP0 write: use them for PF1/PF2.
s=s.replace('''    ldy floor
    REPEAT 5
    nop
    REPEND
    ldx hud,y
    lda BrickMask+2,x''','''    ldy floor
    lda BodyPF1,y
    sta PF1
    lda BodyPF2,y
    sta PF2
    ldx hud,y
    lda BrickMask+2,x''')
# Gap 9: 17+11+4+11+11=54, ldx2+4*nop=10, gate path12 => next line c0.
s=s.replace('    ldx #4\n    REPEAT 5\n','    ldx #4\n    REPEAT 4\n')
colors=[0x06,0x04,0x36,0x36,0x38,0x38,0x2a,0x2a,0x2c,0x2c,0x2e,0x2e,0x1a,0x1a,0x1c,0x1c,0x1e,0x1e,0x0e,0x1a]
colors=[colors[round(i*19/15)] for i in range(16)]
for i in range(16):
 s+=('    nop\n    nop\n' if i%2==0 else '    sta COLUP0\n    sta COLUP1\n')
 s+='''    lda (p0),y
    sta GRP0
    lda (p1),y
    sta GRP1
'''
 s+=('''    lda (ballPtr),y
    sta ENABL
    and #$FD
    sta CTRLPF
''' if i%2==0 else '''    lda (colorPtr),y
    sta ENAM1
    bit frame
''')
 s+='''    lda (p2),y
    sta GRP0
    lda (p3),y
    sta GRP1
    lda (p4),y
    sta GRP0
    stx GRP1
'''
 if i<15:
  val=0x80+[8,8,6,8,8,4][i%6]
  s+=f'''    dey
    lda (p5),y
    tax
    lda #${val:02X}
    sta COLUPF
    lda #{color_name(colors[i+1])}
'''
 else:s+='''    lda #0
    sta GRP1
    lda #>BrickMask
    sta ballPtr+1
    sta colorPtr+1
    ldx floor
    cpx #3
    beq .street
    jmp NextFloor
.street
    jmp ToStreet
'''
s+='''CollapseFacadeKernel
    SUBROUTINE
    lda #0
    sta GRP0
    sta GRP1
    sta ENABL
    sta ENAM1
    sta PF0
    sta floor
    lda #1
    sta CTRLPF
.floor
    ; Two preparation rows plus 10 solid and 16 window rows = 28 lines.
    sta WSYNC
    lda #0
    sta PF1
    sta PF2
    ldx floor
    lda SolidPF1,x
    sta p0
    sta p1
    lda SolidPF2,x
    sta p0+1
    sta p1+1
    ldy lossCause
    lda transition
    cmp CollapseTimeK,x
    bcs .leftReady
    lda p0
    and CollapseLeft1,y
    sta p0
    lda p0+1
    and CollapseLeft2,y
    sta p0+1
.leftReady
    sta WSYNC
    bcs .rightReady
    lda p1
    and CollapseRight1,y
    sta p1
    lda p1+1
    and CollapseRight2,y
    sta p1+1
.rightReady
    lda p0
    and #$0C
    sta p2
    lda p0+1
    and #$2C
    sta p2+1
    lda p1
    and #$0C
    sta p3
    lda p1+1
    and #$2C
    sta p3+1
    ldy #10
.solid
    sta WSYNC
    lda p0
    sta PF1
    lda p0+1
    sta PF2
    lda #$88
    sta COLUPF
    REPEAT 9
    nop
    REPEND
    lda p1
    sta PF1
    lda p1+1
    nop
    sta PF2
    dey
    bne .solid
    ldy #16
.windows
    sta WSYNC
    lda p2
    sta PF1
    lda p2+1
    sta PF2
    lda #$86
    sta COLUPF
    REPEAT 9
    nop
    REPEND
    lda p3
    sta PF1
    lda p3+1
    nop
    sta PF2
    dey
    bne .windows
    inc floor
    lda floor
    cmp #4
    bcs .finished
    jmp .floor
.finished
    jmp ToStreet
CollapseLeft1 byte $F0,$FF,$FF
CollapseLeft2 byte $F0,$1F,$FF
CollapseRight1 byte $FF,$FF,$F0
CollapseRight2 byte $FF,$1F,$F0
@GEOMETRY@
FloorFirst0 byte 0,3,6,9
FloorFirst1 byte 1,4,7,10
FloorFirst2 byte 2,5,8,11
KJumpOffset byte 249,21,49,77
KMasonryOffset byte 153,181,209,237
CollapseTimeK byte 120,90,60,30
KGapPosLo byte '''+','.join('<GapPos'+str(i) for i in range(11))+'''
KGapPosHi byte '''+','.join('>GapPos'+str(i) for i in range(11))+'''
KBrickBand
'''
vals=[next((f for f in range(4) if 38+28*f<=y<64+28*f),255) for y in range(256)]
for i in range(0,256,16):s+='    byte '+','.join(str(x) for x in vals[i:i+16])+'\n'
s+='KJumpClamp\n'
for i in range(0,256,16):s+='    byte '+','.join(str(v if 49<=v<=75 else 0) for v in range(i,i+16))+'\n'
s+='''    include "src/flames.inc"
    echo "Facade code/art:",(*-$F000)
    ORG $1D00
    RORG $FD00
BallMask
    ds 64,1
    byte $03,$13,$33,$33,$33,$13,$03,$01
    ds 56,1
    byte $03,$13,$23,$23,$13,$03
    ds 26,1
    byte 2,2,2,2
    ds 92,1
BrickMask
    ds 16,0
    byte $FF,$FF,$FF,$FE,$FC,$FE,$7E,$5E,$7C,$78,$38,$10
    ds 4,0
    byte $FF,$FF,$FE,$FC,$FE,$7E,$7C,$7C,$3C,$1C,$18,$08
    ds 20,0
    byte $66,$24,$24,$3C,$3C,$7E,$DB,$99,$18,$3C,$3C,$18
    ds 180,0
    ORG $1FA0
    GAPGATES GapAfterPosition
    ORG $1FB0
    GATES
    ORG $1FFA
    RORG $FFFA
    word ResetGate,ResetGate,ResetGate
'''
parts=[]
for street in STREETS:
 bank=street['bank'];t=s
 for off in (0,0xd00,0xfa0,0xfb0,0xffa):t=t.replace(f'ORG ${4096+off:04X}',f'ORG ${4096*bank+off:04X}')
 g=''
 for name,typ,part in [('SkyPF1','sky',0),('SkyPF2','sky',1),('SolidPF1','solid',0),('SolidPF2','solid',1),('BodyPF1','body',0),('BodyPF2','body',1)]:
  g+=name+' byte '+','.join(f'${(roof_playfield(street,f) if typ=="sky" else playfield(street,f,typ=="solid"))[part]:02X}' for f in range(4))+'\n'
 t=t.replace('@GEOMETRY@',g)
 for lum in [4,6,8]:t=t.replace(f'lda #${0x80+lum:02X}\n    sta COLUPF',f'lda #${street["hue"]+lum:02X}\n    sta COLUPF')
 parts.append(color_loads(t))
(R/'src/facade.asm').write_text(parts[0]);(R/'src/facade_extra.asm').write_text('\n'.join(parts[1:]))

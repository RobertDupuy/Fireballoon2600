"""Build either original NTSC or PAL from the same editable source."""
from pathlib import Path
import argparse, json, os, shutil, subprocess, sys
from art_v08 import generate
import tv

ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--tv', choices=('ntsc', 'pal'), default='pal')
args = parser.parse_args()
tv.generate()
generate()
for name in ('make_position.py', 'make_facade.py', 'make_street.py', 'make_title.py'):
    subprocess.run([sys.executable, str(ROOT / name)], check=True)
out = ROOT / 'build'
out.mkdir(exist_ok=True)
dasm = os.environ.get('DASM') or shutil.which('dasm')
if not dasm:
    sys.exit('DASM is required. Install it or set DASM to its executable.')
rom = f'Fireballoon2600-{args.tv.upper()}.bin'
subprocess.run([dasm, 'src/main.asm', '-f3', f'-DPAL={int(args.tv == "pal")}',
                f'-obuild/{rom}', '-lbuild/Fireballoon2600.lst',
                '-sbuild/Fireballoon2600.sym'], cwd=ROOT, check=True)
assert (out / rom).stat().st_size == 32768
(out / 'config.json').write_text(json.dumps(dict(tv=args.tv, rom=rom,
    scanlines=312 if args.tv == 'pal' else 262, fps=50 if args.tv == 'pal' else 60,
    logic_hz=60, ram_bytes=119 if args.tv == 'pal' else 118), indent=2) + '\n')
print(out / rom)
